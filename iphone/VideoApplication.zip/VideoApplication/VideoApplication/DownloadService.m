//
//  DownloadService.m
//  VideoApplication
//
//  Created by Cuong Tran on 1/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DownloadService.h"
#import "Util.h"
#import "VideoData.h"
#import "LoadingMaskView.h"
@interface DownloadService()
- (void) download;
- (void) processError:(NSError *) error;
- (void) stopTimerIfNeed;
- (void) setPathWithCurrentType:(DownloadType) type;
- (void) checkFileExist;
- (void) showLoading;
- (void) hideLoading;
@end

@implementation DownloadService
@synthesize path = _path;
@synthesize localPath = _localPath;
@synthesize connecting = _connecting;
@synthesize delegate;
@synthesize timer = _timer;
@synthesize timeout = _timeout;

- (id) initWithVideoData:(VideoData *)data andType:(DownloadType)type {
    self = [super init];
    if (self) {
        _videoData = [data retain];
        _currentType = type;
        [self setPathWithCurrentType:_currentType];
        self.timeout = 60;
    }
    return self;
}

- (void) setPathWithCurrentType:(DownloadType)type {
    NSString *hashStr = [Util calcMD5:_videoData.title];
    if (type == DownloadTypeVideo) {
        self.path = _videoData.url;
        NSString *videoDir = [Util getVideoDir];
        _localPath = [videoDir stringByAppendingString:[NSString stringWithFormat:@"/%@", hashStr]];
    } else if (type == DownloadTypeSub) {
        self.path = _videoData.subUrl;
        NSString *subDir = [Util getSubDir];
        _localPath = [subDir stringByAppendingString:[NSString stringWithFormat:@"/%@", hashStr]];
    } else if (type == DownloadTypeTimeLine) {
        self.path = _videoData.timelineUrl;
        NSString *timelineDir = [Util getTimeLineDir];
        _localPath = [timelineDir stringByAppendingString:[NSString stringWithFormat:@"/%@", hashStr]];
    }
}

- (void) showLoading {
    if(_alert == nil) {
        _alert = [[LoadingMaskView alloc] initWithCancelButton:@"" alert:YES titleButton:@"Cancel"];
    }
    _alert.delegate = self;
    if (!_alert.visibled) {
        [_alert show];
    }
}

- (void) hideLoading {
    [_alert hide];
}

- (void) checkFileExist {
    BOOL isExits = [Util checkFileExits:_localPath];
    if (isExits) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:LocStr(@"MsgExistFile") delegate:nil cancelButtonTitle:LocStr(@"Cancel") otherButtonTitles:LocStr(@"OK"), nil];
        alertView.delegate = self;
        [alertView show];
        [alertView release];
    } else {
        [self download];
    }
}

- (void) checkFileExistAndDownload {
    [self checkFileExist];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        
    } else if (buttonIndex == 1) {
        [self download];
    }
}


- (void) stopTimerIfNeed {
    if (_timer) {
        [_timer invalidate];
        [_timer release];
        _timer = nil;
    }
}

- (void) startTimer {
    _timer = [[NSTimer timerWithTimeInterval:self.timeout target:self selector:@selector(didTimeOut) userInfo:nil repeats:NO] retain];
    
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSDefaultRunLoopMode];
}

- (void) didTimeOut {
    if (self.connecting) {
        [self processError:nil];
    }
}
#pragma download processing

- (void) download {
    if (self.connecting) {
        return;
    }
    [self stopTimerIfNeed];
    NSURL *url = [NSURL URLWithString:self.path];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url cachePolicy:NO timeoutInterval:self.timeout];
    NSLog(@"URL:%@", self.path);
    _buffer = [[NSMutableData alloc] init];
    _connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    if (_connection) {
        [self startTimer];
        self.connecting = TRUE;
        [[UIApplication sharedApplication] showNetworkActivityIndicatorVisible:TRUE];
    }
}


- (void) processError:(NSError *)error {
    [delegate downloadServiceFailed:self];
    [self stop];
    NSLog(@"URL not found : %@" ,self.path);
}

- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response {
    return request;
}


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSHTTPURLResponse *)response { 
    [self stopTimerIfNeed];
    [_buffer setLength:0];
    int code = [response statusCode];
    if (code != 200) {
        NSLog(@"status code : %@", code);
        [self processError:nil];
    }
}


- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"Request failed! Eror : (%d) %@", error.code, [error localizedDescription]);
    [self processError:error];
    
}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [_buffer appendData:data];
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    if (_buffer) {
        [Util deleteDir:_localPath];
        [Util createDirectoryAtPath:_localPath];
        NSURL *url = [NSURL URLWithString:_localPath];
        [_buffer writeToURL:url atomically:YES];
        [delegate downloadService:self didReceiveStatus:@"success" filePath:_localPath];
    }
    [self stop];
}


- (void)stop {
    [self stopTimerIfNeed];
    if (self.connecting) {
        [[UIApplication sharedApplication] showNetworkActivityIndicatorVisible:FALSE];
    }

    self.connecting = FALSE;
    if (_buffer) {
        [_buffer release];
        _buffer = nil;
    }
    if (_connection) {
        [_connection cancel];
        [_connection release];
        _connection = nil;
    }    
    _currentType = DownloadTypeNone;
}

- (void) dealloc {
    [self stop];
    self.path = nil;
    self.localPath = nil;
    [super dealloc];
}


@end
