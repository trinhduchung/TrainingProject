  //
  //  PolicyDetailsViewController.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/5/11.
  //  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
  //

#import "PolicyDetailsViewController.h"
#import "PolicyDetailsCustomCell.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "qPeriorMobInsuranceDemo_PolicyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "SUPObjectList.h"
#import "PolicyProductCustomCell.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "CustomerDetailsViewController.h"
#import "PoliciesEditViewController.h"
#import "PoliciesViewController.h"
#import "Utils.h"
#import "SUPAbstractEntity.h"
#import "PoliciesUtils.h"
#import "MGSplitViewController.h"

@implementation PolicyDetailsViewController

@synthesize data;
@synthesize arrContents;
@synthesize table;
@synthesize isPushed;
@synthesize isPolicy;

#pragma mark - View Lifecycle
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

  // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
  [self initData];
  self.title = @"Policy details";
  [table reloadData];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
  return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
  
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewWillAppear:(BOOL)animated {
  [Utils stopWaiting];
  UIToolbar *toolbar;
  if (isPushed) {
    toolbar = [Utils getLeftButtons:self withMode:kToggleCancel];
  } else {
    toolbar = [Utils getLeftButtons:self withMode:kToggleOnly];
  }
  self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:toolbar];
  PoliciesViewController *policyView = APP_IPAD.policiesView;
  policyView.view.userInteractionEnabled = YES;
  [super viewWillAppear:YES];
}

- (void)viewWillDisappear:(BOOL)animated {  
  [super viewWillDisappear:YES];
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
  [super dealloc];
}

#pragma mark - Actions
- (IBAction)cancel:(id)sender {
  [self.navigationController popViewControllerAnimated:YES];
}

  // push edit view
- (IBAction)edit:(id)sender {
  PoliciesEditViewController* editView = APP_IPAD.policyEdit;
  editView.data = self.data;
  editView.dataStored = self.data;
  editView.editMode = YES;    
  editView.isPolicy = self.isPolicy;
  APP_IPAD.policiesView.view.userInteractionEnabled = NO;
  [self.navigationController pushViewController:editView animated:YES];
}

#pragma mark - Load Data

- (void)initData {
  policiesUtils = [[PoliciesUtils alloc]init];
  table.backgroundView.hidden = YES;    
  if (dictType == nil) {
    dictType = [Utils getProcessTypeIDDictionary];
    dictCurrency = [Utils getCurrencyIDDictionary];
    dictPayment = [Utils getPaymentIDDictionary];
    dictCustomers = [Utils getCustomers];
  }    
}

  // setup TextField and Values
- (void)loadData {
  if (arrContents == nil) {
    arrContents = [[NSMutableArray alloc]init];
  } else {
    [arrContents removeAllObjects];
  }
  
  isPolicy = [data isKindOfClass:[qPeriorMobInsuranceDemo_PolicyHeader class]]?YES:NO;
  self.title = isPolicy?@"Policy details":@"3rd Contract Details";   
  
  UIBarButtonItem *editButton = 
  [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit 
                                               target:self 
                                               action:@selector(edit:)];
  self.navigationItem.rightBarButtonItem = editButton;
  [editButton release];
  
  [arrContents addObject:[self getBasicInfo:isPolicy]];
  [arrContents addObject:[self getProductsInfo:isPolicy]];
  [arrContents addObject:[self getRolesInfo:isPolicy]];
  [table reloadData];
}

  // get basic header infomation
- (NSMutableArray *)getBasicInfo:(BOOL)isPolicyHeader {
  NSMutableArray *arrBasic = [[NSMutableArray alloc]init];
  [arrBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy ID", kFieldKey,
                       [data pId], kValueKey,
                       nil]];
  [arrBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy Type", kFieldKey,
                       [dictType valueForKey:[data pType]], kValueKey,
                       nil]];
  [arrBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Status", kFieldKey,
                       [data pStatus], kValueKey,
                       nil]];
  NSString *dateOrName = @"";
  if (isPolicy) {
    dateOrName = [Utils convertDateToStringAndDisplay:[[data pDateStart]stringValue] 
                                           withFormat:@"yyyyMMddHHmmss"];
  } else {
    dateOrName = [data pCompetitorName];
  }
  [arrBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       isPolicy?@"Start Date":@"Competitor Name", kFieldKey,
                       dateOrName, kValueKey,
                       nil]];
  NSString *date = @"";
  if (isPolicy) {
    date = [Utils convertDateToStringAndDisplay:[[data pDateEnd] stringValue]
                                     withFormat:@"yyyyMMddHHmmss"];
  } else {
    date = [Utils convertDateToStringAndDisplay:[[data p3rdDateRenewal] stringValue]
                                     withFormat:@"yyyyMMddHHmmss"];
  }
  [arrBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       isPolicy?@"End Date":@"Renewal Date", kFieldKey,
                       date, kValueKey,
                       nil]];
  [arrBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Currency", kFieldKey,
                       [dictCurrency valueForKey:[data pHeaderCurrency]], kValueKey,
                       nil]];
  return arrBasic;
}

  // get products infomation
- (NSMutableDictionary *)getProductsInfo:(BOOL)isPolicyHeader {
  NSMutableDictionary *dictProducts = [[NSMutableDictionary alloc]init];
  NSMutableArray *arrTemp = [[NSMutableArray alloc]init];
  [arrTemp addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                      @"Product", kFieldKey,
                      @"Product", kValueKey,
                      nil]];
  [arrTemp addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                      @"Rate", kFieldKey,
                      @"Rate", kValueKey,
                      nil]];
  [arrTemp addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                      @"Payment", kFieldKey,
                      @"Payment", kValueKey,
                      nil]];    
  [dictProducts setValue:arrTemp forKey:[[NSNumber numberWithInt:0]stringValue]];
  
  SUPObjectList *listItems;
  if (isPolicyHeader) {
    listItems = [data PolicyHeaderPolicyItem];
  } else {
    listItems = [data ThirdPartyHeaderThirdPartyItem];
  }
  
  NSMutableArray *arrToRemoveFromList = [[NSMutableArray alloc]init];
  for (int i = 0; i < [listItems size]; i++) {
    if ([[listItems item:i] pItemProductDescr] == nil 
          || [[listItems item:i] pItemRate] == nil 
          || [[[listItems item:i] pItemProductDescr] isEqualToString:@""] 
          || [[listItems item:i] pItemRate] == 0) {
      [arrToRemoveFromList addObject:[listItems item:i]];
    }
  }
  
  if ([arrToRemoveFromList count] > 0) {
    for (int i = 0; i < [arrToRemoveFromList count]; i++) {
      [listItems removeObject:[arrToRemoveFromList objectAtIndex:i]];
    }
  }
  
  for (int i = 0; i < [listItems size]; i++) {
    NSMutableArray *arrItem = [[NSMutableArray alloc]init];
    [arrItem addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                        @"Product", kFieldKey,
                        [[listItems item:i] pItemProductDescr], kValueKey,
                        nil]];
    NSString *stringRate = [[[listItems item:i] pItemRate]stringValue];
    [arrItem addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                        @"Rate", kFieldKey,
                        [policiesUtils convertRateDatabaseToDisplay:stringRate], kValueKey,
                        nil]];
    if ([dictPayment valueForKey:[[listItems item:i] pItemPaymentType]] != nil) {
      [arrItem addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                          @"Payment", kFieldKey,
                          [dictPayment valueForKey:[[listItems item:i] pItemPaymentType]], kValueKey,
                          nil]];
    } else {
      [arrItem addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                          @"Payment", kFieldKey,
                          @"", kValueKey,
                          nil]];
    }    
    
    [dictProducts setValue:arrItem forKey:[[NSNumber numberWithInt:i+1]stringValue]];
  }
  return dictProducts;
}

  //get roles infomation
- (NSMutableArray *)getRolesInfo:(BOOL)isPolicyHeader {
  NSMutableArray *arrRoles = [[NSMutableArray alloc]init];
  NSString *strHolder = @"";
  NSString *strInsured = @"";
  NSString *strOwner = @"";
  SUPObjectList *listPartners;
  if (isPolicyHeader) {
    listPartners = [data PolicyHeaderPolicyPartner];
  } else {
    listPartners = [data ThirdPartyHeaderThirdPartyPartner];
  }
  for (int i = 0; i < [listPartners size]; i++) {
    qPeriorMobInsuranceDemo_ThirdPartyPartner *aPartner = [listPartners item:i];
    if ([aPartner.bpAssignedPFDescr isEqualToString:kPolicyHolder]) {
      strHolder = [Utils getPartnerInfoByAssignedNumber:aPartner.bpAssignedNumber];
      holder = aPartner;
    } else if ([aPartner.bpAssignedPFDescr isEqualToString:kInsuredPerson]) {
      strInsured = [Utils getPartnerInfoByAssignedNumber:aPartner.bpAssignedNumber];
      insured = aPartner;
    } else if ([aPartner.bpAssignedPFDescr isEqualToString:kOwner]) {
      strOwner = [Utils getPartnerInfoByAssignedNumber:aPartner.bpAssignedNumber];
      employee = aPartner;
    }
  }
  [arrRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       kPolicyHolder, kFieldKey,
                       strHolder, kValueKey,
                       nil]];
  if (isPolicyHeader) {
    [arrRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         kInsuredPerson, kFieldKey,
                         strInsured, kValueKey,
                         nil]];
  }
  [arrRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Emp. Responsible", kFieldKey,
                       strOwner, kValueKey,
                       nil]];
  return arrRoles;
}

#pragma mark - Table Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return [arrContents count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  if (section != 1) {
    return [[arrContents objectAtIndex:section]count];
  } else {
    NSMutableArray *arrTmp = [NSMutableArray arrayWithArray:[[arrContents objectAtIndex:1]allKeys]];
    return [arrTmp count];        
  }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
  NSMutableArray *titles = [[NSMutableArray alloc]init];
  [titles addObject:@"Basic Information"];
  [titles addObject:@"Product Information"];
  [titles addObject:@"Roles"];
	return [titles objectAtIndex:section];
}

  // draw cell content
- (UITableViewCell *)tableView:(UITableView *)tableView 
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //CustomCell
  static NSString *CellIdentifier = @"Cell"; 
  
  if (indexPath.section != 1) {        
    PolicyDetailsCustomCell *cell = 
      (PolicyDetailsCustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
      NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PolicyDetailsCustomCell" 
                                                   owner:self 
                                                 options:nil];
      for (id oneObject in nib)
        if ([oneObject isKindOfClass:[PolicyDetailsCustomCell class]])
          cell = (PolicyDetailsCustomCell *)oneObject;
    } else {
      UIView *view = nil;
      view = [cell.contentView viewWithTag:1];
      if (!view) {
        [view removeFromSuperview];
      }
    }
    NSMutableArray *section = [self.arrContents objectAtIndex:indexPath.section];
    NSMutableArray *row = [section objectAtIndex:indexPath.row];
    cell.txtKey.text = [row valueForKey:kFieldKey];
    cell.txtValue.text = [NSString stringWithFormat:@"%@", [row valueForKey:kValueKey]];
    return cell;
  } else {    
    PolicyProductCustomCell *cell = 
        (PolicyProductCustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
      NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PolicyProductCustomCell" 
                                                   owner:self 
                                                 options:nil];
      for (id oneObject in nib)
        if ([oneObject isKindOfClass:[PolicyProductCustomCell class]])
          cell = (PolicyProductCustomCell *)oneObject;
    } else {
      UIView *view = nil;
      view = [cell.contentView viewWithTag:1];
      if (!view) {
        [view removeFromSuperview];
      }
    }
    
    if (indexPath.row != 0) {
      cell.txtCate.textColor = [UIColor darkTextColor];
      cell.txtRate.textColor = [UIColor darkTextColor];
      cell.txtPayment.textColor = [UIColor darkTextColor];
      
      [cell.txtCate setFont:[UIFont systemFontOfSize:17]];
      [cell.txtRate setFont:[UIFont systemFontOfSize:17]];
      [cell.txtPayment setFont:[UIFont systemFontOfSize:17]];
    }
    
    NSMutableDictionary *dictTmp = [self.arrContents objectAtIndex:1];
    NSString *indexRow = [[NSNumber numberWithInt:indexPath.row]stringValue];
    NSMutableArray *array = [dictTmp objectForKey:indexRow];
    
    cell.txtCate.text = [NSString stringWithFormat:@"%@",
                            [[array objectAtIndex:0] valueForKey:kValueKey]];
    cell.txtRate.text = [NSString stringWithFormat:@"%@",
                            [[array objectAtIndex:1] valueForKey:kValueKey]];
    cell.txtPayment.text = [NSString stringWithFormat:@"%@", 
                                [[array objectAtIndex:2] valueForKey:kValueKey]];
    cell.userInteractionEnabled = NO;
    return cell;
  }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section == 2) {
    NSString *number;
    if (indexPath.row ==0) {
      number = holder.bpAssignedNumber;
    } else if (indexPath.row == 1) {
      number = isPolicy?insured.bpAssignedNumber:employee.bpAssignedNumber;
    } else if (indexPath.row == 2) {
      number = employee.bpAssignedNumber;
    }
    if ([dictCustomers valueForKey:number] != nil) {
      CustomerDetailsViewController *customerDetails = APP_IPAD.customerDetail;
      customerDetails.customer = [dictCustomers valueForKey:number];
      [customerDetails loadData];            
      @try {
        customerDetails.isPushed = YES;
        [self.navigationController pushViewController:customerDetails animated:YES];
      }
      @catch (NSException *exception) {
        customerDetails.isPushed = NO;
        [self.navigationController popToViewController:customerDetails animated:YES];
      }
      @finally {
        
      }
    } 
  }
}

- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section 
{
    UIView *headerView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)] autorelease];
    UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(45,10, tableView.bounds.size.width - 10, 18)] autorelease];
   
    if ( section == 0 ) {
            label.text = @"Basic Information";
        }
        else if ( section == 1 )
        {
            label.text = @"Product Information";

        }
        else if ( section == 2 )
        {
            label.text = @"Roles";
        }  
    
    label.textColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.75];
    label.backgroundColor = [UIColor clearColor];
    [headerView addSubview:label];
    return headerView;
}


@end
