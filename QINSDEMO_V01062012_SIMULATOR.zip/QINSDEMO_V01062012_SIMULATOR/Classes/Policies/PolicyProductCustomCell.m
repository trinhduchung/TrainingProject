  //
  //  PolicyProductCustomCell.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/21/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "PolicyProductCustomCell.h"


@implementation PolicyProductCustomCell

@synthesize txtCate;
@synthesize txtRate;
@synthesize txtPayment;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
    
  }
  return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
  [super setSelected:selected animated:animated];
}

- (void)dealloc {
  [super dealloc];
}

@end
