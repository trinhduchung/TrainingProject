  //
  //  PoliciesEditViewController.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/21/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "PoliciesEditViewController.h"
#import "SUPObjectList.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_PolicyItem.h"
#import "qPeriorMobInsuranceDemo_PolicyPartner.h"
#import "Utils.h"
#import "PoliciesEditCustomCell.h"
#import "PolicyProductCustomCell.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "qPeriorMobInsuranceDemo_CustomizingProcessType.h"
#import "CustomerUtils.h"
#import "PoliciesViewController.h"
#import "PolicyDetailsViewController.h"
#import "MGSplitViewController.h"
#import "qPeriorMobInsuranceDemo_KeyGenerator.h"
#import "qPeriorMobInsuranceDemo_LocalKeyGenerator.h"
#import "qPeriorMobInsuranceDemo_CustomizingPaymentType.h"
#import "qPeriorMobInsuranceDemo_InterviewResult.h"

@implementation PoliciesEditViewController

@synthesize contractPartner;
@synthesize data;
@synthesize dataStored;
@synthesize arrId;
@synthesize arrContents;
@synthesize arrCategory; 
@synthesize arrRate;
@synthesize arrPayment;
@synthesize table;
@synthesize uiTextField;
@synthesize txtID;
@synthesize txtType;
@synthesize txtStatus;
@synthesize txtCompetitor, txtStartDate;
@synthesize txtRenewalDate, txtEndDate;
@synthesize txtCategory;
@synthesize txtRate;
@synthesize txtCurrency;
@synthesize txtPayment;
@synthesize txtHolder;
@synthesize txtInsured;
@synthesize txtEmployee;
@synthesize popController;
@synthesize popOver;
@synthesize editMode;
@synthesize visible;
@synthesize roleOver;
@synthesize dateOver;
@synthesize popRoleController;
@synthesize popDateController;
@synthesize viewMoved;
@synthesize isPushed;
@synthesize isPolicy;
@synthesize holder;
@synthesize lockHolder;

#pragma mark - View lifecycle

/*- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
 {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization
 }
 return self;
 }*/

- (void)viewDidLoad {
  viewMoved = NO;
  keyboardShown = NO;
  indexOfTextField = 0;
  table.backgroundView.hidden = YES;
  popOver = [[CustomerEditPopOver alloc]init];
	popController = [[UIPopoverController alloc] initWithContentViewController:popOver];
	popController.popoverContentSize = CGSizeMake(250,300);
  roleOver = [[PolicyRolesPopOver alloc]init];
  roleOver.delegate = self;
  popRoleController = [[UIPopoverController alloc] initWithContentViewController:roleOver];
  popRoleController.popoverContentSize = CGSizeMake(300,800);
  dateOver = [[DatePickerPopOver alloc] init];
  popDateController = [[UIPopoverController alloc] initWithContentViewController:dateOver];
  
  popDateController.popoverContentSize =  CGSizeMake(350, 250);
  dateOver.sender = self;    
  
  policiesUtils = [[PoliciesUtils alloc]init];
  
    // get common Pickup data list
  dictType = [Utils getProcessTypeIDDictionary];
  dictTypeDesc = [Utils getProcessTypeDescDictionary];
  dictCurrency = [Utils getCurrencyIDDictionary];
  dictCurrencyDesc = [Utils getCurrencyDescDictionary];
  dictProduct = [Utils getProductIDDictionary];
  dictProductDesc = [Utils getProductDescDictionary];
  dictPayment = [Utils getPaymentIDDictionary];
  dictPaymentDesc = [Utils getPaymentDescDictionary];
  
  UIBarButtonItem *saveButton = 
    [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave 
                                                 target:self 
                                                 action:@selector(saveData:)];
	self.navigationItem.rightBarButtonItem = saveButton;
  
	[saveButton release];
  
  table.editing = YES;
  
  [super viewDidLoad];   
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	return YES;
}

- (void)viewWillAppear:(BOOL)animated {
  visible = YES;
  if (holder != nil) {
    UITableViewCell *cell = [table cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:kRolesInfoSection]];
    cell.userInteractionEnabled = NO;
  }
  [self loadData];
  UIToolbar *toolbar = [Utils getLeftButtons:self withMode:kToggleCancel];
  self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:toolbar];
  [super viewWillAppear:YES];	
}

- (void)viewWillDisappear:(BOOL)animated {
  holder = nil;
  insured = nil;
  employee = nil;
	visible = NO;
  data = nil;
  dataStored = nil;
  lockHolder = NO;
	[super viewWillDisappear:animated];	
}

- (void)dealloc {
  [super dealloc];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];    
    // Release any cached data, images, etc that aren't in use.
}


#pragma mark - Table methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView {
	return [arrContents count];
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	if (section != 1) {
    return [[arrContents objectAtIndex:section]count];
  } else {
    return countRows+2;        
  }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
  NSMutableArray *titles = [[NSMutableArray alloc]init];
  [titles addObject:@"Basic Information"];
  [titles addObject:@"Product Information"];
  [titles addObject:@"Roles"];
	return [titles objectAtIndex:section];
}

  // draw cell item 
- (UITableViewCell *)tableView:(UITableView *)tableView 
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"Cell"; 
  int section = indexPath.section;
  int row = indexPath.row;
  if (section != kProductsInfoSection) {
    PoliciesEditCustomCell *cell = 
        (PoliciesEditCustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];	
    if (cell == nil) {
      NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PoliciesEditCustomCell" 
                                                   owner:self 
                                                 options:nil];
      for (id oneObject in nib)
        if ([oneObject isKindOfClass:[UITableViewCell class]])
          cell = (PoliciesEditCustomCell *)oneObject;
    } else {
      UIView *view = nil;
      view = [cell.contentView viewWithTag:1];
      if (!view) {
        [view removeFromSuperview];
      }
    }
    NSMutableArray *arraySection = [arrContents objectAtIndex:section];
    NSMutableDictionary *arrayRow = [arraySection objectAtIndex:row];
    cell.txtFieldName.text = [arrayRow valueForKey:kFieldKey];
    
    UITextField *textField = (UITextField*)[arrayRow valueForKey:kTextFieldKey];
    [cell.contentView addSubview:textField];
      //[textField release];
      //if (section == kBasicInfoSection && row == kRowID && editMode) {
      //  cell.userInteractionEnabled = NO;
      //}
    return cell;
  } else {
    PolicyProductCustomCell *cell = 
        (PolicyProductCustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];	
    if (cell == nil) {
      NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PolicyProductCustomCell" 
                                                   owner:self 
                                                 options:nil];
      for (id oneObject in nib)
        if ([oneObject isKindOfClass:[UITableViewCell class]])
          cell = (PolicyProductCustomCell *)oneObject;
    } else {
      UIView *view = nil;
      view = [cell.contentView viewWithTag:1];
      if (!view) {
        [view removeFromSuperview];
      }
    }
    
    if (row == 0) {
      cell.txtCate.text = @"Category";
      cell.txtRate.text = @"Rate";
      cell.txtPayment.text = @"Payment";
    } else if (row <= countRows){
      for (UIView * view in cell.contentView.subviews) {
        [view removeFromSuperview];                
      }                        
      [cell.contentView addSubview:[arrCategory objectAtIndex:row-1]];
      [cell.contentView addSubview:[arrRate objectAtIndex:row-1]];
      [cell.contentView addSubview:[arrPayment objectAtIndex:row-1]];
    } else {
      cell.txtCate.text = @"<- Add product.";
      cell.txtCate.textColor = [UIColor greenColor];
      [cell.txtCate setFont:[UIFont systemFontOfSize:17]];
      [cell.txtRate removeFromSuperview];
      [cell.txtPayment removeFromSuperview];
    }            
    return cell;
  }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)aTableView 
           editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section != 1) {
    return UITableViewCellEditingStyleNone;
  } else {
    if (indexPath.row == 0) {
      return UITableViewCellEditingStyleNone;
    } else if (indexPath.row > countRows) {
      return UITableViewCellEditingStyleInsert;
    } else {
      return UITableViewCellEditingStyleDelete;
    }
  }
}

- (void)tableView:(UITableView *)aTableView 
      commitEditingStyle:(UITableViewCellEditingStyle)editingStyle 
      forRowAtIndexPath:(NSIndexPath *)indexPath {
	if (editingStyle == UITableViewCellEditingStyleInsert) {
    NSArray *paths = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:[arrCategory count]+1 inSection:1]];
    countRows++;
    [self txtCategory:[arrCategory count]];
    [self txtRate:[arrRate count]];
    [self txtPayment:[arrPayment count]];
    [arrInputRate addObject:@""];
    [table beginUpdates];
    [table setEditing:YES animated:YES];
    [table insertRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationTop];
    [table endUpdates];
  } else if (editingStyle == UITableViewCellEditingStyleDelete) {
    NSArray *paths = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexPath.row inSection:1]];
    countRows--;
    [arrCategory removeObjectAtIndex:indexPath.row-1];
    [arrRate removeObjectAtIndex:indexPath.row-1];
    [arrPayment removeObjectAtIndex:indexPath.row-1];
    [arrInputRate removeObjectAtIndex:indexPath.row-1];
    if (indexPath.row-1 < [arrId count]) {
      [arrId removeObjectAtIndex:indexPath.row-1];
    }        
    [table beginUpdates];
    [table setEditing:YES animated:YES];
    [table deleteRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationTop];
    [table endUpdates];
  }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  int section = indexPath.section;
  int row = indexPath.row;
  float diff =  table.frame.origin.y - table.contentOffset.y;
  UITableViewCell *newCell = [self.table cellForRowAtIndexPath:indexPath];
  CGRect frame = CGRectMake(newCell.frame.origin.x+newCell.bounds.size.width-45, 
                            newCell.frame.origin.y-5+diff, 
                            newCell.frame.size.width, 
                            newCell.frame.size.height);
  if (isPolicy) {
    if (section == kBasicInfoSection) {
      if (editMode) {
        if (row == kRowEditPolicyStatus){
          uiTextField = txtStatus;
          SUPObjectList *listContents = [[SUPObjectList alloc]init];
          [listContents addObject:kActive];
          [listContents addObject:kInActive];        
          [self presentPopOver:listContents frame:frame];
        } else if (row == kRowEditPolicyEndDate) {
          uiTextField = txtEndDate;
          [popDateController presentPopoverFromRect:frame 
                                             inView:self.view 
                           permittedArrowDirections:UIPopoverArrowDirectionRight 
                                           animated:YES];
        } else if (row == kRowEditPolicyCurrency) {
          uiTextField = txtCurrency;
          SUPObjectList *lstContent = [[SUPObjectList alloc]init];
          NSMutableArray *arrCurr = [NSMutableArray arrayWithArray:[dictCurrencyDesc allKeys]];
          arrCurr = (NSMutableArray *)[arrCurr sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
          for (int i = 0; i < [arrCurr count]; i++) {
            [lstContent add:[arrCurr objectAtIndex:i]];
          }
          [self presentPopOver:lstContent frame:frame];
        }
      } else {
        if (row == kRowCreatePolicyEndDate) {
          uiTextField = txtEndDate;
          [popDateController presentPopoverFromRect:frame 
                                             inView:self.view 
                           permittedArrowDirections:UIPopoverArrowDirectionRight 
                                           animated:YES];
        } else if (row == kRowCreatePolicyCurrency) {
          uiTextField = txtCurrency;
          SUPObjectList *lstContent = [[SUPObjectList alloc]init];
          NSMutableArray *arrCurr = [NSMutableArray arrayWithArray:[dictCurrencyDesc allKeys]];
          arrCurr = (NSMutableArray *)[arrCurr sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
          for (int i = 0; i < [arrCurr count]; i++) {
            [lstContent add:[arrCurr objectAtIndex:i]];
          }
          [self presentPopOver:lstContent frame:frame];
        }
      }
    } else if (section == kRolesInfoSection) {
      if (row == kRowPolicyHolder) {
        uiTextField = txtHolder;
      } else if (row == kRowPolicyInsured) {
        uiTextField = txtInsured;
      } else if (row == kRowPolicyOwner) {
        uiTextField = txtEmployee;
      }
      if (!(lockHolder && uiTextField == txtHolder)) {
        roleOver.sender = self;
        [self.popRoleController presentPopoverFromRect:frame 
                                                inView:self.view 
                              permittedArrowDirections:UIPopoverArrowDirectionRight 
                                              animated:YES];
      }
    }
  } else {
    if (section == kBasicInfoSection) {
      if (editMode) {
        if (row == kRowEdit3rdStatus) {
          uiTextField = txtStatus;
          SUPObjectList *listContents = [[SUPObjectList alloc]init];
          [listContents addObject:kActive];
          [listContents addObject:kInActive];        
          [self presentPopOver:listContents frame:frame];
        } else if (row == kRowEdit3rdRenewalDate) {
          uiTextField = txtRenewalDate;
          [popDateController presentPopoverFromRect:frame 
                                             inView:self.view 
                           permittedArrowDirections:UIPopoverArrowDirectionRight 
                                           animated:YES];
        } else if (row == kRowEdit3rdCurrency) {
          uiTextField = txtCurrency;
          SUPObjectList *lstContent = [[SUPObjectList alloc]init];
          NSMutableArray *arrCurr = [NSMutableArray arrayWithArray:[dictCurrencyDesc allKeys]];
          arrCurr = (NSMutableArray *)[arrCurr sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
          for (int i = 0; i < [arrCurr count]; i++) {
            [lstContent add:[arrCurr objectAtIndex:i]];
          }
          [self presentPopOver:lstContent frame:frame];
        }
      } else {
        if (row == kRowCreate3rdRenewalDate) {
          uiTextField = txtRenewalDate;
          [popDateController presentPopoverFromRect:frame 
                                             inView:self.view 
                           permittedArrowDirections:UIPopoverArrowDirectionRight 
                                           animated:YES];
        } else if (row == kRowCreate3rdCurrency) {
          uiTextField = txtCurrency;
          SUPObjectList *lstContent = [[SUPObjectList alloc]init];
          NSMutableArray *arrCurr = [NSMutableArray arrayWithArray:[dictCurrencyDesc allKeys]];
          arrCurr = (NSMutableArray *)[arrCurr sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
          for (int i = 0; i < [arrCurr count]; i++) {
            [lstContent add:[arrCurr objectAtIndex:i]];
          }
          [self presentPopOver:lstContent frame:frame];
        }
      }   
    } else if (section == kRolesInfoSection) {
      if (row == kRow3rdHolder) {
        uiTextField = txtHolder;
      } else if (row == kRow3rdOwner) {
        uiTextField = txtEmployee;
      }
      if (!(lockHolder && uiTextField == txtHolder)) {
        roleOver.sender = self;
        [self.popRoleController presentPopoverFromRect:frame 
                                                inView:self.view 
                              permittedArrowDirections:UIPopoverArrowDirectionRight 
                                              animated:YES];
      }
    }
  }
  
  if (section == kProductsInfoSection && row > [arrCategory count]) {
    NSArray *paths = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:[arrCategory count]+1 inSection:1]];
    countRows++;
    [self txtCategory:[arrCategory count]];
    [self txtRate:[arrRate count]];
    [self txtPayment:[arrPayment count]];
    [arrInputRate addObject:@""];
    [table beginUpdates];
    [table setEditing:YES animated:YES];
    [table insertRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationTop];
    [table endUpdates];
  }
}

  // edit text fields action
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
  uiTextField = textField;
  float diff =  table.frame.origin.y - table.contentOffset.y;
  float xDiff = 0.0;
  if (APP_IPAD.policiesSplit.visible) {
    xDiff = APP_IPAD.policiesSplit.detailViewController.view.frame.origin.x
            - APP_IPAD.policiesSplit.masterViewController.view.frame.size.width;
  } else {
    xDiff = APP_IPAD.splitView.detailViewController.view.frame.origin.x
            - APP_IPAD.splitView.masterViewController.view.frame.size.width;
  }
  
  if ([arrCategory containsObject:uiTextField]) {    
    int row = [arrCategory indexOfObject:uiTextField]+1;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row
                                                inSection:kProductsInfoSection];
    UITableViewCell *newCell = [self.table cellForRowAtIndexPath:indexPath];
    CGRect frame = CGRectMake(newCell.frame.origin.x-370+xDiff, 
                              newCell.frame.origin.y+diff, 
                              newCell.bounds.size.width, 
                              newCell.bounds.size.height);
    SUPObjectList *lstContent = [[SUPObjectList alloc]init];
    NSMutableArray *arrCont = [NSMutableArray arrayWithArray:[dictProductDesc allKeys]];
    arrCont = (NSMutableArray *)[arrCont sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
    for (int i = 0; i < [arrCont count]; i++) {
      [lstContent add:[arrCont objectAtIndex:i]];
    }
    
    popOver.arrContent = lstContent;
    popOver.sender = self;
    int size = [popOver.arrContent size];
    int height = 550;
    if (size <= 10) {
      height = size*40+80;
    }
    [popOver loadData];
    popController.popoverContentSize = CGSizeMake(300,height);
    [self.popController presentPopoverFromRect:frame 
                                        inView:self.view 
                      permittedArrowDirections:UIPopoverArrowDirectionLeft
                                      animated:YES];
  } else if ([arrRate containsObject:uiTextField]) {
    if (keyboardShown) {
      return YES;	
    }
    indexOfTextField = [arrRate indexOfObject:uiTextField];
    CGRect frame = self.view.frame;
    if ((indexOfTextField+3)*kCellHeight+diff >= 0) {
      frame.origin.y -= (indexOfTextField+3)*kCellHeight+diff;
    }    
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:0.3];
    self.view.frame = frame;
    [UIView commitAnimations];		
    viewMoved = YES;	
    keyboardShown = YES;
    return YES;
  } else if ([arrPayment containsObject:uiTextField]) {
    int row = [arrPayment indexOfObject:uiTextField]+1;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row
                                                inSection:kProductsInfoSection];
    UITableViewCell *newCell = [self.table cellForRowAtIndexPath:indexPath];    
    CGRect frame = CGRectMake(newCell.frame.origin.x+490, 
                              newCell.frame.origin.y+diff, 
                              newCell.frame.size.width, 
                              newCell.frame.size.height);
    SUPObjectList *lstContent = [[qPeriorMobInsuranceDemo_CustomizingPaymentType findAll]retain];        
    popOver.arrContent = lstContent;
    popOver.sender = self;
    int size = [popOver.arrContent size];
    int height = 550;
    if (size <= 10) {
      height = size*40+80;
    }
    [popOver loadData];
    popController.popoverContentSize = CGSizeMake(300,height);
    [self.popController presentPopoverFromRect:frame 
                                        inView:self.view 
                      permittedArrowDirections:UIPopoverArrowDirectionRight
                                      animated:YES];
  } else if (uiTextField == txtCompetitor) {
    return YES;
  }
  return NO;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
	uiTextField = nil;
  float diff =  table.frame.origin.y - table.contentOffset.y;
	if (viewMoved) {
		CGRect frame = self.view.frame;
    if ((indexOfTextField+3)*kCellHeight+diff >= 0) {
      frame.origin.y += (indexOfTextField+3)*kCellHeight+diff;
    }
		[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
		[UIView setAnimationDuration:0.3];
		self.view.frame = frame;
		[UIView commitAnimations];		
		viewMoved = NO;
	}
  keyboardShown = NO;
}

- (BOOL)textField:(UITextField *)textField 
      shouldChangeCharactersInRange:(NSRange)range 
      replacementString:(NSString *)string {
  if ([arrRate containsObject:textField]) {
    if (string.length > 0) {
      NSString *digits = @"[\\d]";
      NSPredicate *formatTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", digits];
      if ([formatTest evaluateWithObject:string]) {
        NSString *input = [arrInputRate objectAtIndex:[arrRate indexOfObject:textField]];
        input = [input stringByAppendingString:string];  
        NSString *tmp = [policiesUtils convertRateRawToDisplay:input];
        textField.text = tmp;
        int index = [arrRate indexOfObject:textField];
        NSString *stringReplace = @"";
        if ([tmp isEqualToString:@"0,00"]) {
          stringReplace = @"";
        } else {
          stringReplace = input;
        }
        [arrInputRate replaceObjectAtIndex:index withObject:stringReplace];
      }
    } else {
      NSString *input = [arrInputRate objectAtIndex:[arrRate indexOfObject:textField]];
      if (input.length <= 1) {
        input = @"";
      } else {
        input = [input substringToIndex:input.length-1];
      }        
      textField.text = [policiesUtils convertRateRawToDisplay:input];
      int index = [arrRate indexOfObject:textField];
      [arrInputRate replaceObjectAtIndex:index withObject:input];
    }
    return NO;
  } else {
    return YES;
  }    
}

#pragma mark - Load data 

  // init Field Name, TextField in Basic and Roles Section of table
- (void)loadData {
  if (arrContents == nil) {
    arrContents = [[NSMutableArray alloc]init];
    arrId = [[NSMutableArray alloc]init];
    arrInputRate = [[NSMutableArray alloc]init];
  } else {
    [arrId removeAllObjects];
    [arrContents removeAllObjects];
    [arrCategory removeAllObjects];
    [arrRate removeAllObjects];
    [arrPayment removeAllObjects];
    [arrInputRate removeAllObjects];
  }
  
  if (isPolicy) {
    if (editMode) {
      self.title = @"Policy Details";
      [arrContents addObject:[self getEditPolicyBasicInfo:data]];
      [arrContents addObject:[self getPolicyItemsInfo:data]];
      [arrContents addObject:[self getEditPolicyRolesInfo:data]];      
    } else {
      self.title = @"New Policy";
      [arrContents addObject:[self getCreatePolicyBasicInfo]];
      [arrContents addObject:@""];
      [arrContents addObject:[self getCreatePolicyRolesInfo]];
    }
  } else {
    if (editMode) {
      self.title = @"3rd-Party Contract Detaisl";
      [arrContents addObject:[self getEditThirdPartyBasicInfo:data]];
      [arrContents addObject:[self getThirdPartyItemsInfo:data]];
      [arrContents addObject:[self getEditThirdPartyRolesInfo:data]];
    } else {
      self.title = @"New 3rd-Party Contract";
      [arrContents addObject:[self getCreateThirdPartyBasicInfo]];
      [arrContents addObject:@""];
      [arrContents addObject:[self getCreateThirdPartyRolesInfo]];
    }
  }
  
  countRows = [arrCategory count];
  [table reloadData];   
}

#pragma mark Get Basic Information

- (NSMutableArray *)getCreatePolicyBasicInfo {
  NSMutableArray *arrayBasic = [[NSMutableArray alloc]init];
  
  self.txtType.text = @"Policy";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy Type", kFieldKey,
                       txtType, kTextFieldKey,
                       nil]];
  
  self.txtStartDate.text = [Utils getCurrentDateTime:@"dd.MM.yyyy"];
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                      @"Start Date", kFieldKey,
                      txtStartDate, kTextFieldKey,
                      nil]];
  self.txtEndDate.text = @"";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"End Date", kFieldKey,
                       txtEndDate, kTextFieldKey,
                       nil]];  
  
  self.txtCurrency.text = @"";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Currency", kFieldKey,
                       txtCurrency, kTextFieldKey,
                       nil]];
  return arrayBasic;
}

- (NSMutableArray *)getCreateThirdPartyBasicInfo {
  NSMutableArray *arrayBasic = [[NSMutableArray alloc]init];
  
  self.txtType.text = @"Competitor Contract";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Policy Type", kFieldKey,
                         txtType, kTextFieldKey,
                         nil]];
  
  self.txtCompetitor.text = @"";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Competitor Name", kFieldKey,
                         self.txtCompetitor, kTextFieldKey,
                         nil]];
  
  self.txtRenewalDate.text = @"";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Renewal Date", kFieldKey,
                         txtRenewalDate, kTextFieldKey,
                         nil]];  
  
  self.txtCurrency.text = @"";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Currency", kFieldKey,
                         self.txtCurrency, kTextFieldKey,
                         nil]];
  return arrayBasic;
}

- (NSMutableArray *)getEditPolicyBasicInfo:(qPeriorMobInsuranceDemo_PolicyHeader *)header {
  NSMutableArray *arrayBasic = [[NSMutableArray alloc]init];
  
  NSString *startDate = [Utils convertDateToStringAndDisplay:[header.pDateStart stringValue] 
                                        withFormat:@"yyyyMMddHHmmss"];
  NSString *endDate = [Utils convertDateToStringAndDisplay:[header.pDateEnd stringValue] 
                                      withFormat:@"yyyyMMddHHmmss"];
  NSString *currency = [dictCurrency valueForKey:header.pHeaderCurrency];
  
  self.txtID.text = header.pId;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy ID", kFieldKey,
                       txtID, kTextFieldKey,
                       nil]];
  
  self.txtType.text = @"Policy";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy Type", kFieldKey,
                       txtType, kTextFieldKey,
                       nil]];
  
  self.txtStatus.text = header.pStatus;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Status", kFieldKey,
                       txtStatus, kTextFieldKey,
                       nil]];
  
  self.txtStartDate.text = startDate;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Start Date", kFieldKey,
                       txtStartDate, kTextFieldKey,
                       nil]];
  
  self.txtEndDate.text = endDate;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"End Date", kFieldKey,
                       txtEndDate, kTextFieldKey,
                       nil]];    
  
  self.txtCurrency.text = currency;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Currency", kFieldKey,
                       txtCurrency, kTextFieldKey,
                       nil]];
  return arrayBasic;
}

- (NSMutableArray *)getEditThirdPartyBasicInfo:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header {
  NSMutableArray *arrayBasic = [[NSMutableArray alloc]init];
  
  NSString *renewalDate = [Utils convertDateToStringAndDisplay:[header.p3rdDateRenewal stringValue]
                                          withFormat:@"yyyyMMddHHmmss"];
  NSString *currency =  [dictCurrency valueForKey:header.pHeaderCurrency];
  
  self.txtID.text = header.pId;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy ID", kFieldKey,
                       txtID, kTextFieldKey,
                       nil]];
  
  self.txtType.text = @"Competitor Contract";
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy Type", kFieldKey,
                       txtType, kTextFieldKey,
                       nil]];
  
  self.txtStatus.text = header.pStatus;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Status", kFieldKey,
                       txtStatus, kTextFieldKey,
                       nil]];
  
  self.txtCompetitor.text = header.pCompetitorName;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Competitor name", kFieldKey,
                       txtCompetitor, kTextFieldKey,
                       nil]];
  
  self.txtRenewalDate.text = renewalDate;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Renewal Date", kFieldKey,
                       txtRenewalDate, kTextFieldKey,
                       nil]];    
  
  self.txtCurrency.text = currency;
  [arrayBasic addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Currency", kFieldKey,
                       txtCurrency, kTextFieldKey,
                       nil]];
  return arrayBasic;
}

#pragma mark Get Items Information

- (NSMutableDictionary *)getPolicyItemsInfo:(qPeriorMobInsuranceDemo_PolicyHeader *)header {
  NSMutableDictionary *itemsDictionary = [[NSMutableDictionary alloc]init];
  SUPObjectList *listItems = header.PolicyHeaderPolicyItem;
  
  NSMutableArray *arrayToRemove = [[NSMutableArray alloc]init];
  for (qPeriorMobInsuranceDemo_PolicyItem *item in listItems) {
    if (item.pItemProductDescr == nil
        || [item.pItemProductDescr isEqualToString:@""]
        || item.pItemRate == nil) {
      [arrayToRemove addObject:item];
    }
  }
  
  for (int i = arrayToRemove.count - 1 ; i >= 0; i--) {
    qPeriorMobInsuranceDemo_PolicyItem *item = [[arrayToRemove objectAtIndex:i] retain];
    [listItems removeObject:item];
    [item delete];
  }
  
  for (int i = 0; i < [listItems size]; i++) {
    qPeriorMobInsuranceDemo_PolicyItem *item = [listItems item:i];
    [arrId addObject:item.pItemGuid];
  
    NSMutableArray *product = [self getProductRow:i withItem:[listItems item:i]];
    NSString *key = [[NSNumber numberWithInt:i+1]stringValue];
    [itemsDictionary setValue:product forKey:key];
  }
  
  return itemsDictionary;
}

- (NSMutableDictionary *)getThirdPartyItemsInfo:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header {
  NSMutableDictionary *itemsDictionary = [[NSMutableDictionary alloc]init];
  SUPObjectList *listItems = header.ThirdPartyHeaderThirdPartyItem;
  
  NSMutableArray *arrayToRemove = [[NSMutableArray alloc]init];
  for (qPeriorMobInsuranceDemo_ThirdPartyItem *item in listItems) {
    if (item.pItemProductDescr == nil
        || [item.pItemProductDescr isEqualToString:@""]
        || item.pItemRate == nil) {
      [arrayToRemove addObject:item];
    }
  }
  
  for (int i = arrayToRemove.count - 1 ; i >= 0; i--) {
    qPeriorMobInsuranceDemo_ThirdPartyItem *item = [[arrayToRemove objectAtIndex:i] retain];
    [listItems removeObject:item];
    [item delete];
  }
  
  for (int i = 0; i < [listItems size]; i++) {
    qPeriorMobInsuranceDemo_ThirdPartyItem *item = [listItems item:i];
    [arrId addObject:item.pItemGuid];
   
    NSMutableArray *product = [self getProductRow:i withItem:[listItems item:i]];
    NSString *key = [[NSNumber numberWithInt:i+1]stringValue];
    [itemsDictionary setValue:product forKey:key];
  }
  
  return itemsDictionary;
}

- (NSMutableArray *)getProductRow:(int)row withItem:(id)item {
  NSMutableArray *arrItems = [[NSMutableArray alloc]init];
  
  [[self txtCategory:row]setText:[item pItemProductDescr]];
  [arrItems addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Product", kFieldKey,
                       [self txtCategory:row], kTextFieldKey,
                       nil]];
  
  NSString *rate = [[item pItemRate]stringValue];
  [arrInputRate addObject:[policiesUtils convertRateDatabaseToRaw:rate]];
  rate = [policiesUtils convertRateDatabaseToDisplay:rate];
  [[self txtRate:row]setText:rate];
  [arrItems addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Rate", kFieldKey,
                       [self txtRate:row], kTextFieldKey,
                       nil]];
  
  NSString *payment = @"";
  if ([dictPayment valueForKey:[item pItemPaymentType]] != nil) {
    payment = [dictPayment valueForKey:[item pItemPaymentType]];
  }
  [[self txtPayment:row]setText:payment];
  [arrItems addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Payment", kFieldKey,
                       [self txtPayment:row], kTextFieldKey,
                       nil]];  
  return arrItems;
}

#pragma mark Get Roles Information

- (NSMutableArray *)getCreatePolicyRolesInfo {
  NSMutableArray *arrayRoles = [[NSMutableArray alloc]init];
  
  NSString *policyHolder = @"";
  if (holder != nil) {
    policyHolder = [Utils getPartnerInfoByAssignedNumber:[holder bpNumber]];
  }
  
  self.txtHolder.text = policyHolder;
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                      @"Policy Holder", kFieldKey,
                      txtHolder, kTextFieldKey,
                      nil]];
  
  self.txtInsured.text = @"";
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Insured Person", kFieldKey,
                       txtInsured, kTextFieldKey,
                       nil]];
  
  self.txtEmployee.text = @"";
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Emp. Responsible", kFieldKey,
                       self.txtEmployee, kTextFieldKey,
                       nil]];  
  return arrayRoles;
}

- (NSMutableArray *)getCreateThirdPartyRolesInfo {
  NSMutableArray *arrayRoles = [[NSMutableArray alloc]init];
  
  NSString *policyHolder = @"";
  if (holder != nil) {
    policyHolder = [Utils getPartnerInfoByAssignedNumber:[holder bpNumber]];
  }
  
  self.txtHolder.text = policyHolder;
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Policy Holder", kFieldKey,
                         self.txtHolder, kTextFieldKey,
                         nil]];
  
  self.txtEmployee.text = @"";
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Emp. Responsible", kFieldKey,
                         self.txtEmployee, kTextFieldKey,
                         nil]]; 
  return arrayRoles;
}

- (NSMutableArray *)getEditPolicyRolesInfo:(qPeriorMobInsuranceDemo_PolicyHeader *)header {
  NSMutableArray *arrayRoles = [[NSMutableArray alloc]init];
  
  SUPObjectList *listPartners = header.PolicyHeaderPolicyPartner;
  
  NSString *policyHolder = @"";
  NSString *insuredPerson = @"";
  NSString *owner = @"";
  
  for (qPeriorMobInsuranceDemo_PolicyPartner *partner in listPartners) {
    if ([partner.bpAssignedPFDescr isEqualToString:kPolicyHolder]) {
      policyHolder = [Utils getPartnerInfoByAssignedNumber:partner.bpAssignedNumber];
    } else if ([partner.bpAssignedPFDescr isEqualToString:kInsuredPerson]) {
      insuredPerson = [Utils getPartnerInfoByAssignedNumber:partner.bpAssignedNumber];
    } else if ([partner.bpAssignedPFDescr isEqualToString:kOwner]) {
      owner = [Utils getPartnerInfoByAssignedNumber:partner.bpAssignedNumber];
    }
  }
  
  self.txtHolder.text = policyHolder;
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Policy Holder", kFieldKey,
                       txtHolder, kTextFieldKey,
                       nil]];
  
  self.txtInsured.text = insuredPerson;
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Insured Person", kFieldKey,
                       txtInsured, kTextFieldKey,
                       nil]];
  
  self.txtEmployee.text = owner;
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                       @"Emp. Responsible", kFieldKey,
                       txtEmployee, kTextFieldKey,
                       nil]];  
  return arrayRoles;
}

- (NSMutableArray *)getEditThirdPartyRolesInfo:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header {
  NSMutableArray *arrayRoles = [[NSMutableArray alloc]init];
  
  SUPObjectList *listPartners = header.ThirdPartyHeaderThirdPartyPartner;
  
  NSString *policyHolder = @"";
  NSString *owner = @"";
  
  for (qPeriorMobInsuranceDemo_ThirdPartyPartner *partner in listPartners) {
    if ([partner.bpAssignedPFDescr isEqualToString:kPolicyHolder]) {
      policyHolder = [Utils getPartnerInfoByAssignedNumber:partner.bpAssignedNumber];
    } else if ([partner.bpAssignedPFDescr isEqualToString:kOwner]) {
      owner = [Utils getPartnerInfoByAssignedNumber:partner.bpAssignedNumber];
    }
  }
  
  self.txtHolder.text = policyHolder;
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Policy Holder", kFieldKey,
                         txtHolder, kTextFieldKey,
                         nil]];
  
  self.txtEmployee.text = owner;
  [arrayRoles addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Emp. Responsible", kFieldKey,
                         txtEmployee, kTextFieldKey,
                         nil]];  
  return arrayRoles;
}

#pragma mark - Save data

  // save action
- (IBAction)saveData:(id)sender {
    
   Utils* utils = [[Utils alloc]init]; 
    
  if ([self validate]) {
    PolicyDetailsViewController *detailsView = APP_IPAD.policiesDetail;
    if (editMode) {
      if (isPolicy) {
         detailsView.data = [self updatePolicyHeader];
      } else {
        detailsView.data = [self updateThirdParty];
      }
    } else {
      if (isPolicy) {
        detailsView.data = [self createPolicyHeader];
      } else {
        detailsView.data = [self createThirdPartyHeader];
      }
        
       
    } 
    [ utils createInterviewResultFromPolicy:detailsView.data];  
    PoliciesViewController *policiesView = APP_IPAD.policiesView;
    policiesView.data = [policiesUtils getPolicies];
    policiesView.policyNewID = [detailsView.data pId];
    [policiesView loadData];
    [detailsView loadData];
    [self.navigationController popViewControllerAnimated:YES];  
  }
}

- (IBAction)cancel:(id)sender {
  [uiTextField resignFirstResponder];
    // if in edit mode, return to previous view
  if (editMode) {
		data = nil;
		visible = NO;
		[self.navigationController popViewControllerAnimated:YES];
	} else {
      // in create mode, if switched from edit mode, re-display policy info,
      // if not, return to previous view
		if (!data && dataStored) {
      data = dataStored;
      editMode = YES;
			[self loadData];			
			self.title = @"Customer Details";
		} else {
			visible = NO;
			[self.navigationController popViewControllerAnimated:YES];
		}		
	}    
}


  //display Error Alert
- (BOOL)validateError:(NSString*)error {
  UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" 
                                                 message:error 
                                                delegate:self 
                                       cancelButtonTitle:@"OK" 
                                       otherButtonTitles:nil];
  [alert show];
  [alert release];
  return NO;
}

  //validate form input data
- (BOOL)validate {
  if ([txtStatus.text isEqualToString:@""]) {
    return [self validateError:@"Status can't be blank."];
  }
  if ([txtCurrency.text isEqualToString:@""]) {
    return [self validateError:@"Currency can't be blank."];
  }
  if (arrCategory.count == 0) {
    return [self validateError:@"You must create at least 1 product."];
  }
  for (UITextField *textfield in arrCategory) {
    if ([textfield.text isEqualToString:@""]) {
      return [self validateError:@"Product can't be blank."];
    }
  }
  for (UITextField *textfield in arrPayment) {
    if ([textfield.text isEqualToString:@""]) {
      return [self validateError:@"Payment type can't be blank."];
    }
  }
  if ([txtHolder.text isEqualToString:@""]) {
    return [self validateError:@"Policy holder cant't be blank."];
  }
  if ([txtEmployee.text isEqualToString:@""]) {
    return [self validateError:@"Employee responsible can't be blank."];
  }
  if (isPolicy) {    
    if ([txtEndDate.text isEqualToString:@""]) {
      return [self validateError:@"End date can't be blank."];
    }    
    if ([txtInsured.text isEqualToString:@""]) {
      return [self validateError:@"Insured person cant't be blank."];
    } 
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:kDateDisplayFormat];
    NSDate *startDate = [dateFormat dateFromString:[Utils convertStringToDateAndSave:txtStartDate.text 
                                                                          withFormat:kDateDisplayFormat]];
    NSDate *endDate = [dateFormat dateFromString:[Utils convertStringToDateAndSave:txtEndDate.text 
                                                                        withFormat:kDateDisplayFormat]];
    if ([startDate compare:endDate] != NSOrderedAscending) {
      return [self validateError:@"End Date must be after Start Date."];
    }
  } else {
    if ([txtCompetitor.text isEqualToString:@""]) {
      return [self validateError:@"Competitor Name can't be blank."];
    }
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:kDateDisplayFormat];
    NSDate *currentDate = [dateFormat dateFromString:[Utils getCurrentDateTime:kDateDisplayFormat]];
    NSDate *renewalDate = [dateFormat dateFromString:[Utils convertStringToDateAndSave:txtRenewalDate.text 
                                                                        withFormat:kDateDisplayFormat]];
    if ([currentDate compare:renewalDate] != NSOrderedAscending) {
      return [self validateError:@"Renewal Date must be after current Date."];
    }
  }
  return YES;
}

#pragma mark Create/Update Header
- (qPeriorMobInsuranceDemo_PolicyHeader *)createPolicyHeader {

  qPeriorMobInsuranceDemo_PolicyHeader *header = [[qPeriorMobInsuranceDemo_PolicyHeader alloc]init];
  header.pId = [NSString stringWithFormat:@"%ld", [qPeriorMobInsuranceDemo_LocalKeyGenerator generateId]];
  header.pGuid = [NSString stringWithFormat:@"%@", [qPeriorMobInsuranceDemo_LocalKeyGenerator generateGuid]];
  header.pStatus = kActive;
  header.pType = [dictTypeDesc valueForKey:txtType.text];
  NSString *startDate = [Utils convertStringToDateAndSave:txtStartDate.text
                                               withFormat:@"yyyyMMddHHmmss"];  
  header.pDateStart = [NSNumber numberWithLongLong:[startDate longLongValue]];
  NSString *endDate = [Utils convertStringToDateAndSave:txtEndDate.text
                                             withFormat:@"yyyyMMddHHmmss"];  
  header.pDateEnd = [NSNumber numberWithLongLong:[endDate longLongValue]];
  header.pHeaderCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
  header.PolicyHeaderPolicyItem    = [self createPolicyItems:header];
  header.PolicyHeaderPolicyPartner = [self createPolicyPartners:header];
  [header create];
  
       
  return header;
}

- (qPeriorMobInsuranceDemo_ThirdPartyHeader *)createThirdPartyHeader {
  qPeriorMobInsuranceDemo_ThirdPartyHeader *header = 
      [[qPeriorMobInsuranceDemo_ThirdPartyHeader alloc]init];
  header.pId = [NSString stringWithFormat:@"%ld", 
                [qPeriorMobInsuranceDemo_LocalKeyGenerator generateId]];
  header.pGuid = [NSString stringWithFormat:@"%@", 
                  [qPeriorMobInsuranceDemo_LocalKeyGenerator generateGuid]];
  header.pStatus = kActive;
  header.pType = [dictTypeDesc valueForKey:txtType.text];
  NSString *renewalDate = [Utils convertStringToDateAndSave:txtRenewalDate.text
                                                 withFormat:@"yyyyMMddHHmmss"];  
  [header setP3rdDateRenewal:[NSNumber numberWithLongLong:[renewalDate longLongValue]]];
  header.pHeaderCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
  header.pCompetitorName = txtCompetitor.text;  
  header.ThirdPartyHeaderThirdPartyItem = [self createThirdPartyItems:header];
  header.ThirdPartyHeaderThirdPartyPartner = [self createThirdPartyPartners:header];
  [header create];
  return header;
}

- (qPeriorMobInsuranceDemo_PolicyHeader *)updatePolicyHeader {
  qPeriorMobInsuranceDemo_PolicyHeader *header = (qPeriorMobInsuranceDemo_PolicyHeader *)data;
  header.pStatus = txtStatus.text;
  NSString *startDate = [Utils convertStringToDateAndSave:txtStartDate.text
                                               withFormat:@"yyyyMMddHHmmss"];  
  header.pDateStart = [NSNumber numberWithLongLong:[startDate longLongValue]];
  NSString *endDate = [Utils convertStringToDateAndSave:txtEndDate.text
                                             withFormat:@"yyyyMMddHHmmss"];  
  header.pDateEnd = [NSNumber numberWithLongLong:[endDate longLongValue]];
  header.pHeaderCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
  header.PolicyHeaderPolicyItem = [self updatePolicyItems:header];
  header.PolicyHeaderPolicyPartner = [self updatePolicyPatners:header];
  [header update];
  return header;
}

- (qPeriorMobInsuranceDemo_ThirdPartyHeader *)updateThirdParty {
  qPeriorMobInsuranceDemo_ThirdPartyHeader *header = (qPeriorMobInsuranceDemo_ThirdPartyHeader *)data;
  header.pStatus = txtStatus.text;
  header.pCompetitorName = txtCompetitor.text;
  NSString *renewalDate = [Utils convertStringToDateAndSave:txtRenewalDate.text
                                             withFormat:@"yyyyMMddHHmmss"];  
  header.p3rdDateRenewal = [NSNumber numberWithLongLong:[renewalDate longLongValue]];
  header.pHeaderCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
  header.ThirdPartyHeaderThirdPartyItem = [self updateThirdPartyItems:header];
  header.ThirdPartyHeaderThirdPartyPartner = [self updateThirdPartyPartners:header];
  [header update];
  return header;
}

#pragma mark Create/Update Items
- (SUPObjectList *)createPolicyItems:(qPeriorMobInsuranceDemo_PolicyHeader *)header {
  SUPObjectList *listItems = [[SUPObjectList alloc]init];
  for (int i = 0; i < arrCategory.count; i++) {
    qPeriorMobInsuranceDemo_PolicyItem *item = [[qPeriorMobInsuranceDemo_PolicyItem alloc]init];
    item.pId = header.pId;
    item.pGuid = header.pGuid;
    item.pItemGuid = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateGuid];
    item.pItemProductDescr = [[arrCategory objectAtIndex:i]text];
    item.pItemProductId = [dictProductDesc valueForKey:item.pItemProductDescr];
    NSString *strRate = [policiesUtils convertRateDisplayToDatabase:[[arrRate objectAtIndex:i] text]];
    item.pItemRate = [NSNumber numberWithDouble:[strRate doubleValue]];
    item.pItemCurrency = header.pHeaderCurrency;
    item.pItemPaymentType = [dictPaymentDesc valueForKey:[[arrPayment objectAtIndex:i]text]];
    item.policyHeader = header;
    [item create];
    [listItems addObject:item];
  }
  return listItems;
}
  
- (SUPObjectList *)createThirdPartyItems:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header {
  SUPObjectList *listItems = [[SUPObjectList alloc]init];
  for (int i = 0; i < [arrCategory count]; i++) {
    qPeriorMobInsuranceDemo_ThirdPartyItem *item = [[qPeriorMobInsuranceDemo_ThirdPartyItem alloc]init];
    item.pId = header.pId;
    item.pGuid = header.pGuid;
    item.pItemGuid = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateGuid];
    item.pItemProductDescr = [[arrCategory objectAtIndex:i] text];
    item.pItemProductId = [dictProductDesc valueForKey:item.pItemProductDescr];
    NSString *strRate = [policiesUtils convertRateDisplayToDatabase:[[arrRate objectAtIndex:i] text]];
    item.pItemRate = [NSNumber numberWithDouble:[strRate doubleValue]];
    item.pItemCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
    item.pItemPaymentType = [dictPaymentDesc valueForKey:[[arrPayment objectAtIndex:i]text]];
    item.thirdPartyHeader = header;
    [item create];
    [listItems addObject:item];
  }
  return listItems;
}

- (SUPObjectList *)updatePolicyItems:(qPeriorMobInsuranceDemo_PolicyHeader *)header {
  SUPObjectList *listItems = header.PolicyHeaderPolicyItem;
   Utils* utils = [[Utils alloc]init];   
  
  NSMutableArray *arrayToDelete = [[NSMutableArray alloc]init];
  for (qPeriorMobInsuranceDemo_PolicyItem *item in listItems) {
    if (![arrId containsObject:item.pItemGuid]) {
      [arrayToDelete addObject:item];
    }
  }
  
  for (int i = arrayToDelete.count -1; i >= 0; i--) {
    qPeriorMobInsuranceDemo_PolicyItem *item = [arrayToDelete objectAtIndex:i];
    [listItems removeObject:item];
    [utils deleteInterviewResultFromPolicy:header withItem:item]; 
    [item delete];
  }
  
  for (int i = 0; i < listItems.size; i++) {
    qPeriorMobInsuranceDemo_PolicyItem *item = [listItems item:i];
    item.pItemProductDescr = [[arrCategory objectAtIndex:i] text];
    NSString *productID = item.pItemProductId;
    if ([dictProductDesc valueForKey:item.pItemProductDescr] != nil) {
      productID = [dictProductDesc valueForKey:item.pItemProductDescr];
    }
    item.pItemProductId = productID;                
    NSString *strRate = [policiesUtils convertRateDisplayToDatabase:[[arrRate objectAtIndex:i] text]];
    item.pItemRate = [NSNumber numberWithDouble:[strRate doubleValue]];
    item.pItemCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
    item.pItemPaymentType = [dictPaymentDesc valueForKey:[[arrPayment objectAtIndex:i]text]];
    [item update];
  }
  
  for (int i = listItems.size; i < arrCategory.count; i++) {
    qPeriorMobInsuranceDemo_PolicyItem *item = [[qPeriorMobInsuranceDemo_PolicyItem alloc]init];
    item.pId = header.pId;
    item.pGuid = header.pGuid;
    item.pItemGuid = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateGuid];
    item.pItemProductDescr = [[arrCategory objectAtIndex:i] text];
    item.pItemProductId = [dictProductDesc valueForKey:item.pItemProductDescr];
    NSString *strRate = [policiesUtils convertRateDisplayToDatabase:[[arrRate objectAtIndex:i] text]];
    item.pItemRate = [NSNumber numberWithDouble:[strRate doubleValue]];
    item.pItemCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
    item.pItemPaymentType = [dictPaymentDesc valueForKey:[[arrPayment objectAtIndex:i]text]];
    item.policyHeader = header;
    [item create];
    [listItems addObject:item];
  }
  
  return listItems;
}

- (SUPObjectList *)updateThirdPartyItems:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header {
  
   Utils* utils = [[Utils alloc]init];   
   SUPObjectList *listItems = header.ThirdPartyHeaderThirdPartyItem;
  
  
  NSMutableArray *arrayToDelete = [[NSMutableArray alloc]init];
  for (qPeriorMobInsuranceDemo_ThirdPartyItem *item in listItems) {
    if (![arrId containsObject:item.pItemGuid]) {
      [arrayToDelete addObject:item];
    }
  }
  
  for (int i = arrayToDelete.count -1; i >= 0; i--) {
    qPeriorMobInsuranceDemo_ThirdPartyItem *item = [arrayToDelete objectAtIndex:i];
    [listItems removeObject:item];
    [utils deleteInterviewResultFromPolicy:header withItem:item]; 
    [item delete];
      
  }
  
  for (int i = 0; i < listItems.size; i++) {
    qPeriorMobInsuranceDemo_ThirdPartyItem *item = [listItems item:i];
    item.pItemProductDescr = [[arrCategory objectAtIndex:i] text];
    NSString *productID = item.pItemProductId;
    if ([dictProductDesc valueForKey:item.pItemProductDescr] != nil) {
      productID = [dictProductDesc valueForKey:item.pItemProductDescr];
    }
    item.pItemProductId = productID;                
    NSString *strRate = [policiesUtils convertRateDisplayToDatabase:[[arrRate objectAtIndex:i] text]];
    item.pItemRate = [NSNumber numberWithDouble:[strRate doubleValue]];
    item.pItemCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
    item.pItemPaymentType = [dictPaymentDesc valueForKey:[[arrPayment objectAtIndex:i]text]];
    [item update];
  }
  
  for (int i = listItems.size; i < arrCategory.count; i++) {
    qPeriorMobInsuranceDemo_ThirdPartyItem *item = [[qPeriorMobInsuranceDemo_ThirdPartyItem alloc]init];
    item.pId = header.pId;
    item.pGuid = header.pGuid;
    item.pItemGuid = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateGuid];
    item.pItemProductDescr = [[arrCategory objectAtIndex:i] text];
    item.pItemProductId = [dictProductDesc valueForKey:item.pItemProductDescr];
    NSString *strRate = [policiesUtils convertRateDisplayToDatabase:[[arrRate objectAtIndex:i] text]];
    item.pItemRate = [NSNumber numberWithDouble:[strRate doubleValue]];
    item.pItemCurrency = [dictCurrencyDesc valueForKey:txtCurrency.text];
    item.pItemPaymentType = [dictPaymentDesc valueForKey:[[arrPayment objectAtIndex:i]text]];
    item.thirdPartyHeader = header;
    [item create];
    [listItems addObject:item];
  }
  
  return listItems;
}

#pragma mark Create/Update Parters

- (SUPObjectList *)createPolicyPartners:(qPeriorMobInsuranceDemo_PolicyHeader *)header {
  SUPObjectList *listPartners = [[SUPObjectList alloc]init];
  [listPartners addObject:[self createPolicyPartnerFromCustomer:holder 
                                                         policy:header 
                                                           role:kPolicyHolder]];
  [listPartners addObject:[self createPolicyPartnerFromCustomer:insured 
                                                         policy:header 
                                                           role:kInsuredPerson]];
  [listPartners addObject:[self createPolicyPartnerFromCustomer:employee 
                                                         policy:header 
                                                           role:kOwner]];
    
    
  return listPartners;
}

- (SUPObjectList *)createThirdPartyPartners:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header {
  SUPObjectList *listPartners = [[SUPObjectList alloc]init];
  [listPartners addObject:[self createThirdPartyPartnerFromCustomer:holder 
                                                         thirdParty:header 
                                                               role:kPolicyHolder]];
  [listPartners addObject:[self createThirdPartyPartnerFromCustomer:employee 
                                                         thirdParty:header 
                                                               role:kOwner]];
  return listPartners;
}

- (SUPObjectList *)updatePolicyPatners:(qPeriorMobInsuranceDemo_PolicyHeader *)header {
  SUPObjectList *listPartners = header.PolicyHeaderPolicyPartner;
  if (holder != nil) {
    for (qPeriorMobInsuranceDemo_PolicyPartner *partner in listPartners) {
      if ([partner.bpAssignedPFDescr isEqualToString:kPolicyHolder]) {
        [listPartners removeObject:partner];
        [partner delete];
      }
    }
    [listPartners addObject:[self createPolicyPartnerFromCustomer:holder policy:header role:kPolicyHolder]];
  }
  if (insured != nil) {
    for (qPeriorMobInsuranceDemo_PolicyPartner *partner in listPartners) {
      if ([partner.bpAssignedPFDescr isEqualToString:kInsuredPerson]) {
        [listPartners removeObject:partner];
        [partner delete];
      }
    }
    [listPartners addObject:[self createPolicyPartnerFromCustomer:insured policy:header role:kInsuredPerson]];
  }
  if (employee != nil) {
    for (qPeriorMobInsuranceDemo_PolicyPartner *partner in listPartners) {
      if ([partner.bpAssignedPFDescr isEqualToString:kOwner]) {
        [listPartners removeObject:partner];
        [partner delete];
      }
    }
    [listPartners addObject:[self createPolicyPartnerFromCustomer:employee policy:header role:kOwner]];
  }
  return listPartners;
}

- (SUPObjectList *)updateThirdPartyPartners:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header {
  SUPObjectList *listPartners = header.ThirdPartyHeaderThirdPartyPartner;
  if (holder != nil) {
    for (qPeriorMobInsuranceDemo_ThirdPartyPartner *partner in listPartners) {
      if ([partner.bpAssignedPFDescr isEqualToString:kPolicyHolder]) {
        [listPartners removeObject:partner];
        [partner delete];
      }
    }
    [listPartners addObject:[self createThirdPartyPartnerFromCustomer:holder thirdParty:header role:kPolicyHolder]];
  }
  if (employee != nil) {
    for (qPeriorMobInsuranceDemo_ThirdPartyPartner *partner in listPartners) {
      if ([partner.bpAssignedPFDescr isEqualToString:kOwner]) {
        [listPartners removeObject:partner];
        [partner delete];
      }
    }
    [listPartners addObject:[self createThirdPartyPartnerFromCustomer:employee thirdParty:header role:kOwner]];
  }
  return listPartners;
}

- (qPeriorMobInsuranceDemo_PolicyPartner *)createPolicyPartnerFromCustomer:(id)customer 
      policy:(qPeriorMobInsuranceDemo_PolicyHeader *)header 
      role:(NSString *)role {
  qPeriorMobInsuranceDemo_PolicyPartner *partner = 
      [[qPeriorMobInsuranceDemo_PolicyPartner alloc]init];
  partner.policyHeader = header;
  partner.pId = header.pId;
  partner.pGuid = header.pGuid;
  partner.bpEmployeeResponsible = [customer bpEmployeeResponsible];
  partner.pType = @"ZIP1";
  partner.bpAssignedPFDescr = role;
  partner.bpAssignedNumber = [customer bpNumber];
  partner.bpAssignedAddrHousNo = [customer bpAddrHouseNo];
  partner.bpAssignedAddrStreet = [customer bpAddrStreet];
  partner.bpAssignedAddrPostalCode = [customer bpAddrPostalCode];
  partner.bpAssignedAddreCity = [customer bpAddrCity];
  if ([role isEqualToString:kPolicyHolder]) {
    partner.bpAssignedPF = kZipPolicyHolder;
  }
  if ([role isEqualToString:kOwner]) {
    partner.bpAssignedPF = kZipOwner;
  }
  if ([role isEqualToString:kInsuredPerson]) {
    partner.bpAssignedPF = kZipInsuredPerson;
  }
  if ([customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
    partner.bpAssignedFirstName = [customer bpCorpName];
    partner.bpAssignedLastName = @"";
  }
  if ([customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
    partner.bpAssignedFirstName = [customer bpIndFirstName];
    partner.bpAssignedLastName = [customer bpIndLastName];
  }
  NSLog(@"\nName=%@\n",  partner.bpAssignedPF);
  [partner create];
  return partner;
}

- (qPeriorMobInsuranceDemo_ThirdPartyPartner *)createThirdPartyPartnerFromCustomer:(id)customer
     thirdParty:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header
     role:(NSString *)role {
  qPeriorMobInsuranceDemo_ThirdPartyPartner *partner = 
  [[qPeriorMobInsuranceDemo_ThirdPartyPartner alloc]init];
  partner.thirdPartyHeader = header;
  partner.pId = header.pId;
  partner.pGuid = header.pGuid;
  partner.bpEmployeeResponsible = [customer bpEmployeeResponsible];
  partner.pType = @"ZIP1";
  partner.bpAssignedPFDescr = role;
  partner.bpAssignedNumber = [customer bpNumber];
  partner.bpAssignedAddrHousNo = [customer bpAddrHouseNo];
  partner.bpAssignedAddrStreet = [customer bpAddrStreet];
  partner.bpAssignedAddrPostalCode = [customer bpAddrPostalCode];
  partner.bpAssignedAddreCity = [customer bpAddrCity];
  if ([role isEqualToString:kPolicyHolder]) {
    partner.bpAssignedPF = kZipPolicyHolder;
  }
  if ([role isEqualToString:kOwner]) {
    partner.bpAssignedPF = kZipOwner;
  }
  if ([role isEqualToString:kInsuredPerson]) {
    partner.bpAssignedPF = kZipInsuredPerson;
  }
  if ([customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
    partner.bpAssignedFirstName = [customer bpCorpName];
    partner.bpAssignedLastName = @"";
  }
  if ([customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
    partner.bpAssignedFirstName = [customer bpIndFirstName];
    partner.bpAssignedLastName = [customer bpIndLastName];
  }
  [partner create];
  return partner;
}

#pragma mark - PopOver

  // present popOver
- (void)presentPopOver:(SUPObjectList *)lstContent frame:(CGRect)frame  {
  popOver.arrContent = lstContent;
  popOver.sender = self;
  int size = [popOver.arrContent size];
  int height = 550;
  if (size <= 10) {
    height = size*40+80;
  }
  [popOver loadData];
  popController.popoverContentSize = CGSizeMake(300,height);
  [self.popController presentPopoverFromRect:frame 
                                      inView:self.view 
                    permittedArrowDirections:UIPopoverArrowDirectionRight
                                    animated:YES];    
}

- (void)dismissPopover {
  [self.popController dismissPopoverAnimated:YES];
  [self.popRoleController dismissPopoverAnimated:YES];
  [self.popDateController dismissPopoverAnimated:YES];
}

- (void)getDataFromPopOver:(id)sender {
  if ([sender isKindOfClass:[PolicyRolesPopOver class]]) {
    if ([roleOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
      qPeriorMobInsuranceDemo_CustomerIndividual *individual = roleOver.returnData;
      uiTextField.text = [NSString stringWithFormat:@"%@ %@, %@ %@, %@", 
                                                      individual.bpIndFirstName,     
                                                      individual.bpIndLastName, 
                                                      individual.bpAddrHouseNo, 
                                                      individual.bpAddrStreet, 
                                                      individual.bpAddrCity];        
    } else if ([roleOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
      qPeriorMobInsuranceDemo_CustomerCorporate *corporate = roleOver.returnData;
      uiTextField.text = [NSString stringWithFormat:@"%@, %@ %@, %@",
                                                      corporate.bpCorpName,
                                                      corporate.bpAddrHouseNo, 
                                                      corporate.bpAddrStreet, 
                                                      corporate.bpAddrCity];
    }
  } else if ([sender isKindOfClass:[DatePickerPopOver class]]) {
    DatePickerPopOver* picker = (DatePickerPopOver*)sender;
    uiTextField.text = [NSString stringWithFormat:@"%@", picker.returnData];
  } else if ([sender isKindOfClass:[CustomerEditPopOver class]]) {
    if ([popOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingPaymentType class]]) {
      qPeriorMobInsuranceDemo_CustomizingPaymentType *payment = popOver.returnData;
      uiTextField.text = payment.customizePamentTypeDescr;
    } else {
      uiTextField.text = [NSString stringWithFormat:@"%@", popOver.returnData];
    }
  } 
  if (uiTextField == txtHolder) {
    holder = [roleOver.returnData retain];
  } else if (uiTextField == txtInsured) {
    insured = [roleOver.returnData retain];
  } else if (uiTextField == txtEmployee) {
    employee = [roleOver.returnData retain];
  }
  [self dismissPopover];
}


#pragma mark - TextField

- (UITextField *)txtID {
	if (txtID == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtID = [[UITextField alloc] initWithFrame:frame];
		txtID.borderStyle = UITextBorderStyleNone;
		txtID.font = [UIFont systemFontOfSize:17];
		txtID.backgroundColor = [UIColor clearColor];
		txtID.keyboardType = UIKeyboardTypeDefault;
		txtID.returnKeyType = UIReturnKeyDone;	
		txtID.tag = 1;
		txtID.delegate = self;
    txtID.userInteractionEnabled = NO;
	}
	return txtID;
}

- (UITextField *)txtType {
	if (txtType == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtType = [[UITextField alloc] initWithFrame:frame];
		txtType.borderStyle = UITextBorderStyleNone;
		txtType.font = [UIFont systemFontOfSize:17];
		txtType.backgroundColor = [UIColor clearColor];
		txtType.keyboardType = UIKeyboardTypeDefault;
		txtType.returnKeyType = UIReturnKeyDone;	
		txtType.tag = 1;
		txtType.delegate = self;
    txtType.userInteractionEnabled = NO;
	}
	return txtType;
}

- (UITextField *)txtStatus {
	if (txtStatus == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtStatus = [[UITextField alloc] initWithFrame:frame];
		txtStatus.borderStyle = UITextBorderStyleNone;
		txtStatus.font = [UIFont systemFontOfSize:17];
		txtStatus.backgroundColor = [UIColor clearColor];
		txtStatus.keyboardType = UIKeyboardTypeDefault;
		txtStatus.returnKeyType = UIReturnKeyDone;	
		txtStatus.tag = 1;
		txtStatus.delegate = self;
    txtStatus.userInteractionEnabled = NO;
	}
	return txtStatus;
}

- (UITextField *)txtCompetitor {
	if (txtCompetitor == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtCompetitor = [[UITextField alloc] initWithFrame:frame];
		txtCompetitor.borderStyle = UITextBorderStyleNone;
		txtCompetitor.font = [UIFont systemFontOfSize:17];
		txtCompetitor.backgroundColor = [UIColor clearColor];
		txtCompetitor.keyboardType = UIKeyboardTypeDefault;
		txtCompetitor.returnKeyType = UIReturnKeyDone;	
		txtCompetitor.tag = 1;
		txtCompetitor.delegate = self;
	}
	return txtCompetitor;
}
- (UITextField *)txtStartDate {
  if (txtStartDate == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtStartDate = [[UITextField alloc] initWithFrame:frame];
		txtStartDate.borderStyle = UITextBorderStyleNone;
		txtStartDate.font = [UIFont systemFontOfSize:17];
		txtStartDate.backgroundColor = [UIColor clearColor];
		txtStartDate.keyboardType = UIKeyboardTypeDefault;
		txtStartDate.returnKeyType = UIReturnKeyDone;	
		txtStartDate.tag = 1;
		txtStartDate.delegate = self;
	}
	return txtStartDate;
}

- (UITextField *)txtRenewalDate {
	if (txtRenewalDate == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtRenewalDate = [[UITextField alloc] initWithFrame:frame];
		txtRenewalDate.borderStyle = UITextBorderStyleNone;
		txtRenewalDate.font = [UIFont systemFontOfSize:17];
		txtRenewalDate.backgroundColor = [UIColor clearColor];
		txtRenewalDate.keyboardType = UIKeyboardTypeDefault;
		txtRenewalDate.returnKeyType = UIReturnKeyDone;	
		txtRenewalDate.tag = 1;
		txtRenewalDate.delegate = self;	
    txtRenewalDate.userInteractionEnabled = NO;
	}
	return txtRenewalDate;
}

- (UITextField *)txtEndDate {
  if (txtEndDate == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtEndDate = [[UITextField alloc] initWithFrame:frame];
		txtEndDate.borderStyle = UITextBorderStyleNone;
		txtEndDate.font = [UIFont systemFontOfSize:17];
		txtEndDate.backgroundColor = [UIColor clearColor];
		txtEndDate.keyboardType = UIKeyboardTypeDefault;
		txtEndDate.returnKeyType = UIReturnKeyDone;	
		txtEndDate.tag = 1;
		txtEndDate.delegate = self;	
    txtEndDate.userInteractionEnabled = NO;
	}
	return txtEndDate;
}

- (UITextField *)txtCurrency {
  if (txtCurrency == nil) {
    CGRect frame = CGRectMake(175,11,365,30);
		txtCurrency = [[UITextField alloc] initWithFrame:frame];
		txtCurrency.borderStyle = UITextBorderStyleNone;
		txtCurrency.font = [UIFont systemFontOfSize:17];
		txtCurrency.backgroundColor = [UIColor clearColor];
		txtCurrency.keyboardType = UIKeyboardTypeDefault;
		txtCurrency.returnKeyType = UIReturnKeyDone;	
		txtCurrency.tag = 1;
		txtCurrency.delegate = self;
    txtCurrency.userInteractionEnabled = NO;
  }
	return txtCurrency;
}

- (UITextField *)txtHolder {
	if (txtHolder == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtHolder = [[UITextField alloc] initWithFrame:frame];
		txtHolder.borderStyle = UITextBorderStyleNone;
		txtHolder.font = [UIFont systemFontOfSize:17];
		txtHolder.backgroundColor = [UIColor clearColor];
		txtHolder.keyboardType = UIKeyboardTypeDefault;
		txtHolder.returnKeyType = UIReturnKeyDone;	
		txtHolder.tag = 1;
		txtHolder.delegate = self;
    txtHolder.userInteractionEnabled = NO;
	}
	return txtHolder;
}

- (UITextField *)txtInsured {
  if (txtInsured == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtInsured = [[UITextField alloc] initWithFrame:frame];
		txtInsured.borderStyle = UITextBorderStyleNone;
		txtInsured.font = [UIFont systemFontOfSize:17];
		txtInsured.backgroundColor = [UIColor clearColor];
		txtInsured.keyboardType = UIKeyboardTypeDefault;
		txtInsured.returnKeyType = UIReturnKeyDone;	
		txtInsured.tag = 1;
		txtInsured.delegate = self;
    txtInsured.userInteractionEnabled = NO;
	}
	return txtInsured;
}

- (UITextField *)txtEmployee {
	if (txtEmployee == nil) {
		CGRect frame = CGRectMake(175,11,365,30);
		txtEmployee = [[UITextField alloc] initWithFrame:frame];
		txtEmployee.borderStyle = UITextBorderStyleNone;
		txtEmployee.font = [UIFont systemFontOfSize:17];
		txtEmployee.backgroundColor = [UIColor clearColor];
		txtEmployee.keyboardType = UIKeyboardTypeDefault;
		txtEmployee.returnKeyType = UIReturnKeyDone;	
		txtEmployee.tag = 1;
		txtEmployee.delegate = self;		
    txtEmployee.userInteractionEnabled = NO;
	}
	return txtEmployee;
}

- (UITextField *)txtCategory:(int)indexRow {
  if (arrCategory == nil) {
    arrCategory = [[NSMutableArray alloc]init];
  }
	if ([arrCategory count] > indexRow) {
    txtCategory = [arrCategory objectAtIndex:indexRow];
	} else {        
		CGRect frame = CGRectMake(20,10,255,30);
		txtCategory = [[UITextField alloc] initWithFrame:frame];
		txtCategory.borderStyle = UITextBorderStyleNone;
		txtCategory.font = [UIFont systemFontOfSize:17];
		txtCategory.backgroundColor = [UIColor clearColor];
		txtCategory.keyboardType = UIKeyboardTypeDefault;
		txtCategory.returnKeyType = UIReturnKeyDone;	
		txtCategory.tag = 1;
		txtCategory.delegate = self;
    txtCategory.textAlignment = UITextAlignmentLeft;
    [arrCategory addObject:txtCategory];
  }
	return txtCategory;
}

- (UITextField *)txtRate:(int)indexRow {
  if (arrRate == nil) {
    arrRate = [[NSMutableArray alloc]init];
  }
	if ([arrRate count] > indexRow) {
    txtRate = [arrRate objectAtIndex:indexRow];
	} else {
    CGRect frame = CGRectMake(290,10,110,30);
		txtRate = [[UITextField alloc] initWithFrame:frame];
		txtRate.borderStyle = UITextBorderStyleNone;
		txtRate.font = [UIFont systemFontOfSize:17];
		txtRate.backgroundColor = [UIColor clearColor];
		txtRate.keyboardType = UIKeyboardTypeDefault;
		txtRate.returnKeyType = UIReturnKeyDone;	
		txtRate.tag = 1;
		txtRate.delegate = self;	
    txtRate.textAlignment = UITextAlignmentRight;
    txtRate.keyboardType = UIKeyboardTypeNumberPad;
    txtRate.text = kCurrencyFormat;
    [arrRate addObject:txtRate];
  }
	return txtRate;
}

- (UITextField *)txtPayment:(int)indexRow {
  if (arrPayment == nil) {
    arrPayment = [[NSMutableArray alloc]init];
  }
	if ([arrPayment count] > indexRow) {
    txtPayment = [arrPayment objectAtIndex:indexRow];
	} else {
		CGRect frame = CGRectMake(415,10,130,30);
		txtPayment = [[UITextField alloc] initWithFrame:frame];
		txtPayment.borderStyle = UITextBorderStyleNone;
		txtPayment.font = [UIFont systemFontOfSize:17];
		txtPayment.backgroundColor = [UIColor clearColor];		
		txtPayment.keyboardType = UIKeyboardTypeDefault;
		txtPayment.returnKeyType = UIReturnKeyDone;		
		txtPayment.tag = 1;
		txtPayment.delegate = self;
    txtPayment.textAlignment = UITextAlignmentLeft;
    [arrPayment addObject:txtPayment];
  }
	return txtPayment;
}


#pragma mark -
#pragma mark DatePickerDelegate
-(void)datePickerAlert:(DatePickerAlert *)datePickerAlert didPickDate:(NSString *)pickDate {
    //transaction.date = pickDate;
    //NSString* m_dateString = [[NSString alloc] initWithString:pickDate];
}
#define kDatePickerTag 100
- (void) changeDate:(id)sender {
  CGRect frame = CGRectMake(uiTextField.frame.origin.x, 
                            uiTextField.frame.origin.y+180, 
                            uiTextField.frame.size.width, 
                            uiTextField.frame.size.height);
  [popDateController presentPopoverFromRect:frame 
                                     inView:self.view 
                   permittedArrowDirections:(UIPopoverArrowDirection)nil 
                                   animated:YES];
}

- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section 
{
    UIView *headerView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)] autorelease];
    UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(75,10, tableView.bounds.size.width - 10, 18)] autorelease];
    
    if ( section == 0 ) {
        label.text = @"Basic Information";
    }
    else if ( section == 1 )
    {
        label.text = @"Product Information";
        
    }
    else if ( section == 2 )
    {
        label.text = @"Roles";
    }  
    
    label.textColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.75];
    label.backgroundColor = [UIColor clearColor];
    [headerView addSubview:label];
    return headerView;
}

@end
