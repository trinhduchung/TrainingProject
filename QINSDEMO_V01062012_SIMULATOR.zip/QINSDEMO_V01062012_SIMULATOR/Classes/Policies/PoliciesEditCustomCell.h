//
//  PoliciesEditCustomCell.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PoliciesEditCustomCell : UITableViewCell {
  IBOutlet UILabel *txtFieldName;
}

@property (nonatomic, retain) IBOutlet UILabel *txtFieldName;

@end
