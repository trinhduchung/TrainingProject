  //
  //  PolicyRolesPopOver.h
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/26/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import <UIKit/UIKit.h>
#import "SUPObjectList.h"
#import "CustomerUtils.h"
#import "Utils.h"

@interface PolicyRolesPopOver : UIViewController {
  id delegate;
  id sender;
  IBOutlet UITableView *table;
  IBOutlet UIBarButtonItem *button;
  IBOutlet UISearchBar *searchBar;
  NSMutableArray *data;
  NSMutableArray *arrData;
  id returnData;
  CustomerUtils *customerUtils;
}

@property (nonatomic, retain) id delegate;
@property (nonatomic, retain) id sender;
@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *button;
@property (nonatomic, retain) IBOutlet UISearchBar *searchBar;
@property (nonatomic, retain) NSMutableArray *data;
@property (nonatomic, retain) NSMutableArray *arrData;
@property (nonatomic, retain) id returnData;

- (IBAction)cancel:(id)send;
- (void)cancelSearch;

@end
