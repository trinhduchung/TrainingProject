  //
  //  PolicyRolesPopOver.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/26/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "PolicyRolesPopOver.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "PoliciesEditViewController.h"
#import "Utils.h"

@implementation PolicyRolesPopOver

@synthesize table;
@synthesize data;
@synthesize arrData;
@synthesize delegate;
@synthesize button;
@synthesize sender;
@synthesize returnData;
@synthesize searchBar;

-(IBAction)cancel:(id)sender {
  [self.sender dismissPopover];
}

#pragma mark - View Lifecycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
      // Custom initialization
  }
  return self;
}

- (void)dealloc {
  [super dealloc];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidLoad {
  [super viewDidLoad];
  
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:YES];  
  self.title = @"Customers";
  customerUtils = APP_IPAD.customerUtils;
  data = [customerUtils getAllCustomer];
  arrData = [customerUtils getAllCustomer];
  [table reloadData];
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	return YES;
}

#pragma mark - Table Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView {
	return [data count];
}

  // table number of rows in a section
- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	NSMutableArray *arrGroup = [data objectAtIndex:section];
	return [arrGroup count];
}

  //section content
-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	NSMutableArray *characters = [[NSMutableArray alloc]initWithObjects:@"A",@"B",@"C",@"D",@"E",
                                                                      @"F",@"G",@"H",@"I",@"J",
                                                                      @"K",@"L",@"M",@"N",@"O",
                                                                      @"P",@"Q",@"R",@"S",@"T",
                                                                      @"U",@"V",@"W",@"X",@"Y",
                                                                      @"Z",nil];
	return [characters objectAtIndex:section];
}

  // draw cell content
- (UITableViewCell *)tableView:(UITableView *)tableView 
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {	
	static NSString *CellIdentifier = @"CellIdentifier";  
    // Dequeue or create a cell of the appropriate type.
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle 
                                   reuseIdentifier:CellIdentifier] 
              autorelease];
		cell.accessoryType = UITableViewCellAccessoryNone;
	}
	
	NSMutableArray *section = [data objectAtIndex:indexPath.section];
  NSMutableArray *row = [section objectAtIndex:indexPath.row];
	cell.textLabel.text = [row objectAtIndex:kStringCustomerName];
	cell.textLabel.font = [UIFont boldSystemFontOfSize:16];
	cell.detailTextLabel.text = [row objectAtIndex:kStringCustomerStreet];
	cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
	cell.imageView.image = [UIImage imageNamed:@"money.png"];
	
	UILabel *label;
	CGRect Label1Frame = CGRectMake(180, 25, 150, 14);
	label = [[UILabel alloc]initWithFrame:Label1Frame];	
	label.text = [row objectAtIndex:kStringCustomerCity];
	label.tag = 1;
	label.font = [UIFont systemFontOfSize:12];
	label.textColor = [UIColor grayColor];
	label.highlightedTextColor = [UIColor whiteColor];
	for (UIView *view in cell.contentView.subviews) {
		[view removeFromSuperview];
	}
	[cell.contentView addSubview:label];
	[label release];	
	return cell;
}

- (void)tableView:(UITableView *)tableView 
    didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  NSMutableArray *section = [data objectAtIndex:indexPath.section];
  NSMutableArray *row = [section objectAtIndex:indexPath.row];
  NSString *number = [row objectAtIndex:kStringCustomerNumber];
  if ([qPeriorMobInsuranceDemo_CustomerCorporate findByPrimaryKey:number] != nil) {
    returnData = [qPeriorMobInsuranceDemo_CustomerCorporate findByPrimaryKey:number];
    [sender getDataFromPopOver:self];
  } else if ([qPeriorMobInsuranceDemo_CustomerIndividual findByPrimaryKey:number] != nil) {
    returnData = [qPeriorMobInsuranceDemo_CustomerIndividual findByPrimaryKey:number];
    [sender getDataFromPopOver:self];
  }
  [self.sender dismissPopover];
}

#pragma mark - Search
  // search bar text change action
- (void)searchBar:(UISearchBar *)searchbar textDidChange:(NSString *)searchText {
    //
	if ([searchText isEqualToString:@""] || searchText==nil) {
		[self.table reloadData];
		return;
	}
	data = [[NSMutableArray alloc]init];
	for (int i=0; i<26; i++) {
		NSMutableArray *arr = [[NSMutableArray alloc]init];
		[data addObject:arr];
	}
  
    // Filter customer by search text
	for (int i=0; i < [arrData count]; i++) {		
		NSMutableArray *section = [arrData objectAtIndex:i];
    for (int j = 0; j < [section count]; j++) {
      NSMutableArray *row = [section objectAtIndex:j];
      NSString *name = [row objectAtIndex:kStringCustomerName];
      name = [name uppercaseString];
      searchText = [searchText uppercaseString];
      NSRange r = [name rangeOfString:searchText];
      if(r.location != NSNotFound) {
        [[data objectAtIndex:i] addObject:[section objectAtIndex:j]];
      }
		}
	}
	[table reloadData];
}

  // search bar cancel action
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchbar {	
	[self cancelSearch];  
}
  //search bar search action
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchbar {
	[searchBar resignFirstResponder];
}

- (void)cancelSearch {
  data = [arrData copy];
	[table reloadData];
  self.searchBar.text = @"";
  [self.searchDisplayController setActive:NO animated:YES];
}

@end
