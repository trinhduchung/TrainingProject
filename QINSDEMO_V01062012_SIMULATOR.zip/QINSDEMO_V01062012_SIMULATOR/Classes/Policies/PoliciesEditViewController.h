  //
  //  PoliciesEditViewController.h
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/21/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import <UIKit/UIKit.h>
#import "CustomerEditPopOver.h"
#import "PolicyRolesPopOver.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_PolicyPartner.h"
#import "DatePickerPopOver.h"
#import "DatePickerAlert.h"
#import "Utils.h"
#import "PoliciesUtils.h"
#import "qPeriorMobInsuranceDemo_InterviewResult.h"

#define kFieldKey                   @"FieldKey"
#define kTextFieldKey               @"TextFieldKey"

#define kBasicInfoSection           0
#define kProductsInfoSection        1
#define kRolesInfoSection           2

#define kRowCreatePolicyType        0
#define kRowCreatePolicyStartDate   1
#define kRowCreatePolicyEndDate     2
#define kRowCreatePolicyCurrency    3

#define kRowCreate3rdType           0
#define kRowCreate3rdCompetitor     1
#define kRowCreate3rdRenewalDate    2
#define kRowCreate3rdCurrency       3

#define kRowEditPolicyID            0
#define kRowEditPolicyType          1
#define kRowEditPolicyStatus        2
#define kRowEditPolicyStartDate     3
#define kRowEditPolicyEndDate       4
#define kRowEditPolicyCurrency      5

#define kRowEdit3rdID               0
#define kRowEdit3rdType             1
#define kRowEdit3rdStatus           2
#define kRowEdit3rdCompetitor       3
#define kRowEdit3rdRenewalDate      4
#define kRowEdit3rdCurrency         5

#define kRowPolicyHolder            0
#define kRowPolicyInsured           1
#define kRowPolicyOwner             2

#define kRow3rdHolder               0
#define kRow3rdOwner                1

@interface PoliciesEditViewController : UIViewController<UITableViewDataSource, 
                                                          UITableViewDelegate,
                                                          UITextFieldDelegate,
                                                          UIPopoverControllerDelegate> {
  
  PoliciesUtils *policiesUtils;
  NSMutableArray *allowedString;
  
  id data;
  id dataStored;
  NSMutableArray *arrId;
  NSMutableArray *arrContents;
  NSMutableArray *arrCategory;
  NSMutableArray *arrRate;
  NSMutableArray *arrPayment;
  NSMutableArray *arrInputRate;
  IBOutlet UITableView *table;    
  
  UITextField *uiTextField;
  
  UITextField *txtID;
  UITextField *txtType;
  UITextField *txtStatus;
  UITextField *txtCompetitor, *txtStartDate;
  UITextField *txtRenewalDate, *txtEndDate;
  
  UITextField *txtCategory;
  UITextField *txtRate;
  UITextField *txtCurrency;
  UITextField *txtPayment;
  
  UITextField *txtHolder;
  UITextField *txtInsured;
  UITextField *txtEmployee;
  
  UIPopoverController *popController;
  UIPopoverController *popRoleController;
  UIPopoverController *popDateController;
  CustomerEditPopOver *popOver;
  PolicyRolesPopOver *roleOver;
  DatePickerPopOver *dateOver;
  
  BOOL keyboardShown;
  BOOL viewMoved;
  BOOL editMode;
  BOOL visible;
  BOOL lockHolder;
  
  int indexOfTextField;
  
  id contractPartner;
  
  NSMutableDictionary *dictType;
  NSMutableDictionary *dictTypeDesc;
  NSMutableDictionary *dictCurrency;
  NSMutableDictionary *dictCurrencyDesc;
  NSMutableDictionary *dictProduct;
  NSMutableDictionary *dictProductDesc;
  NSMutableDictionary *dictPayment;
  NSMutableDictionary *dictPaymentDesc;
  NSMutableArray *arrCustomers;
  
  id holder;
  id insured;
  id employee;
  int countRows;
  
  BOOL isPushed;
  BOOL isPolicy;
}

@property (nonatomic, retain) id contractPartner;

@property (nonatomic) BOOL lockHolder;
@property (nonatomic) BOOL editMode;
@property (nonatomic) BOOL visible;
@property (nonatomic) BOOL viewMoved;

@property (nonatomic, retain) id holder;
@property (nonatomic, retain) id data;
@property (nonatomic, retain) id dataStored;
@property (nonatomic, retain) NSMutableArray *arrId;
@property (nonatomic, retain) NSMutableArray *arrContents;
@property (nonatomic, retain) NSMutableArray *arrCategory;
@property (nonatomic, retain) NSMutableArray *arrRate;
@property (nonatomic, retain) NSMutableArray *arrPayment;
@property (nonatomic, retain) IBOutlet UITableView *table;

@property (nonatomic, retain) UITextField *uiTextField;
@property (nonatomic, retain) UITextField *txtID;
@property (nonatomic, retain) UITextField *txtType;
@property (nonatomic, retain) UITextField *txtStatus;
@property (nonatomic, retain) UITextField *txtCompetitor, *txtStartDate;
@property (nonatomic, retain) UITextField *txtRenewalDate, *txtEndDate;
@property (nonatomic, retain) UITextField *txtCurrency;

@property (nonatomic, retain) UITextField *txtCategory;
@property (nonatomic, retain) UITextField *txtRate;
@property (nonatomic, retain) UITextField *txtPayment;

@property (nonatomic, retain) UITextField *txtHolder;
@property (nonatomic, retain) UITextField *txtInsured;
@property (nonatomic, retain) UITextField *txtEmployee;

@property (nonatomic, retain) UIPopoverController *popController;
@property (nonatomic, retain) UIPopoverController *popRoleController;
@property (nonatomic, retain) UIPopoverController *popDateController;
@property (nonatomic, retain) CustomerEditPopOver *popOver;
@property (nonatomic, retain) PolicyRolesPopOver *roleOver;
@property (nonatomic, retain) DatePickerPopOver *dateOver;

@property (nonatomic) BOOL isPushed;
@property (nonatomic) BOOL isPolicy;

- (UITextField *)txtCategory:(int)indexRow;
- (UITextField *)txtRate:(int)indexRow;
- (UITextField *)txtPayment:(int)indexRow;

- (void)loadData;

- (void)presentPopOver:(SUPObjectList *)lstContent frame:(CGRect)frame;
- (void)getDataFromPopOver:(id)sender;
- (void)dismissPopover;

- (IBAction)saveData:(id)sender;
- (IBAction)cancel:(id)sender;
- (BOOL)validate;

- (void) changeDate:(id)sender;

- (NSMutableArray *)getCreatePolicyBasicInfo;
- (NSMutableArray *)getCreateThirdPartyBasicInfo;
- (NSMutableArray *)getEditPolicyBasicInfo:(qPeriorMobInsuranceDemo_PolicyHeader *)header;
- (NSMutableArray *)getEditThirdPartyBasicInfo:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header;

- (NSMutableDictionary *)getPolicyItemsInfo:(qPeriorMobInsuranceDemo_PolicyHeader *)header;
- (NSMutableDictionary *)getThirdPartyItemsInfo:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header;
- (NSMutableArray *)getProductRow:(int)row withItem:(id)item;

- (NSMutableArray *)getCreatePolicyRolesInfo;
- (NSMutableArray *)getCreateThirdPartyRolesInfo;
- (NSMutableArray *)getEditPolicyRolesInfo:(qPeriorMobInsuranceDemo_PolicyHeader *)header;
- (NSMutableArray *)getEditThirdPartyRolesInfo:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header;

- (qPeriorMobInsuranceDemo_PolicyHeader *)createPolicyHeader;
- (qPeriorMobInsuranceDemo_ThirdPartyHeader *)createThirdPartyHeader;
- (qPeriorMobInsuranceDemo_PolicyHeader *)updatePolicyHeader;
- (qPeriorMobInsuranceDemo_ThirdPartyHeader *)updateThirdParty;


- (SUPObjectList *)createPolicyItems:(qPeriorMobInsuranceDemo_PolicyHeader *)header;
- (SUPObjectList *)createThirdPartyItems:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header;
- (SUPObjectList *)updatePolicyItems:(qPeriorMobInsuranceDemo_PolicyHeader *)header;
- (SUPObjectList *)updateThirdPartyItems:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header;

- (SUPObjectList *)createPolicyPartners:(qPeriorMobInsuranceDemo_PolicyHeader *)header;
- (SUPObjectList *)createThirdPartyPartners:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header;
- (SUPObjectList *)updatePolicyPatners:(qPeriorMobInsuranceDemo_PolicyHeader *)header;
- (SUPObjectList *)updateThirdPartyPartners:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header;

- (qPeriorMobInsuranceDemo_PolicyPartner *)createPolicyPartnerFromCustomer:(id)customer 
                                                                    policy:(qPeriorMobInsuranceDemo_PolicyHeader *)header 
                                                                      role:(NSString *)role;
- (qPeriorMobInsuranceDemo_ThirdPartyPartner *)createThirdPartyPartnerFromCustomer:(id)customer
                                                                        thirdParty:(qPeriorMobInsuranceDemo_ThirdPartyHeader *)header
                                                                              role:(NSString *)role;

@end
