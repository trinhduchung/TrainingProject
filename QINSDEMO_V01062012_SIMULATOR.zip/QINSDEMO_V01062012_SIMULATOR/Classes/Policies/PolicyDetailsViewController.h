  //
  //  PolicyDetailsViewController.h
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/5/11.
  //  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
  //

#import <UIKit/UIKit.h>
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "PoliciesUtils.h"

#define kFieldKey @"FieldKey"
#define kValueKey @"ValueKey"

@interface PolicyDetailsViewController : UIViewController {
  
  PoliciesUtils *policiesUtils;
  id data;
  NSMutableArray *arrContents;
  IBOutlet UITableView *table;
  NSMutableDictionary *dictType;
  NSMutableDictionary *dictCurrency;
  NSMutableDictionary *dictPayment;
  NSMutableDictionary *dictCustomers;
  qPeriorMobInsuranceDemo_ThirdPartyPartner *holder;
  qPeriorMobInsuranceDemo_ThirdPartyPartner *insured;
  qPeriorMobInsuranceDemo_ThirdPartyPartner *employee;
  BOOL isPushed;
  BOOL isPolicy;
}

@property (nonatomic, retain) id data;
@property (nonatomic, retain) NSMutableArray *arrContents;
@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic) BOOL isPushed;
@property (nonatomic) BOOL isPolicy;

- (void)loadData;
- (IBAction)edit:(id)sender;

- (NSMutableArray *)getBasicInfo:(BOOL)isPolicyHeader;
- (NSMutableDictionary *)getProductsInfo:(BOOL)isPolicyHeader;
- (NSMutableArray *)getRolesInfo:(BOOL)isPolicyHeader;
- (void)initData;

@end
