  //
  //  PolicyCustomCell.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/5/11.
  //  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
  //

#import "PolicyCustomCell.h"


@implementation PolicyCustomCell

@synthesize lblID;
@synthesize lblName;
@synthesize lblType;
@synthesize lblCate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
    
  }
  return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
  [super setSelected:selected animated:animated];
}

- (void)dealloc {
  [super dealloc];
}

@end
