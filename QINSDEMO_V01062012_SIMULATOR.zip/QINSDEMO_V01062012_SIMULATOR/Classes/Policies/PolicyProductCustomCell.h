  //
  //  PolicyProductCustomCell.h
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/21/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import <UIKit/UIKit.h>


@interface PolicyProductCustomCell : UITableViewCell {
  IBOutlet UILabel *txtCate;
  IBOutlet UILabel *txtRate;
  IBOutlet UILabel *txtPayment;
}

@property (nonatomic, retain) IBOutlet UILabel *txtCate;
@property (nonatomic, retain) IBOutlet UILabel *txtRate;
@property (nonatomic, retain) IBOutlet UILabel *txtPayment;

@end
