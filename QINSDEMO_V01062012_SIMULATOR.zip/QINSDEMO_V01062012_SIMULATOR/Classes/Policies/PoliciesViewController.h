  //
  //  PoliciesViewController.h
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/5/11.
  //  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
  //

#import <UIKit/UIKit.h>
#import "PoliciesUtils.h"
#import "PopOver.h"

@interface PoliciesViewController : UIViewController<UISearchDisplayDelegate, 
                                                      UITableViewDataSource, 
                                                      UITableViewDelegate,
                                                      UIPopoverControllerDelegate> {
	IBOutlet UITableView *table;
	IBOutlet UISearchBar *search;
	NSMutableArray *data;
	NSMutableArray *arrData;
	PoliciesUtils *policiesUtils;
  UIPopoverController *popController;
  PopOver *popOver;
  NSMutableDictionary *dictRoles;
  NSMutableDictionary *dictType;  
  BOOL visible;
  NSString *policyNewID;
}

@property (nonatomic,retain) NSString *policyNewID;
@property (nonatomic,retain) IBOutlet UITableView *table;
@property (nonatomic,retain) IBOutlet UISearchBar *search;
@property (nonatomic,retain) NSMutableArray *data;
@property (nonatomic,retain) NSMutableArray *arrData;
@property (nonatomic,retain) PoliciesUtils *policiesUtils;
@property (nonatomic,retain) UIPopoverController *popController;
@property (nonatomic,retain) PopOver *popOver;
@property (nonatomic) BOOL visible;

- (void)dismissPopOver;
- (IBAction)addPolicy:(id)sender;
- (void)loadData;
- (void)waiting;
- (void)refreshData;
- (void)cancelSearch;

- (NSIndexPath *)getIndexPathOfCustomer:(NSString *)policyID;

@end
