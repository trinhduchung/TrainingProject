//
//  PolicyCustomCell.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/5/11.
//  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PolicyCustomCell : UITableViewCell {
	IBOutlet UILabel *lblID;
	IBOutlet UILabel *lblName;
	IBOutlet UILabel *lblType;
	IBOutlet UILabel *lblCate;
}

@property (nonatomic,retain) IBOutlet UILabel *lblID;
@property (nonatomic,retain) IBOutlet UILabel *lblName;
@property (nonatomic,retain) IBOutlet UILabel *lblType;
@property (nonatomic,retain) IBOutlet UILabel *lblCate;

@end
