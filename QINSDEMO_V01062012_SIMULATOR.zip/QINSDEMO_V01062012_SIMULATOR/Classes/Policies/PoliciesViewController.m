  //
  //  PoliciesViewController.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/5/11.
  //  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
  //

#import "PoliciesViewController.h"
#import "Utils.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "PoliciesUtils.h"
#import "PolicyCustomCell.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "qPeriorMobInsuranceDemo_PolicyPartner.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_PolicyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyItem.h"
#import "PolicyDetailsViewController.h"
#import "PopOver.h"
#import "HomeScreenViewController.h"
#import "MGSplitViewController.h"

@implementation PoliciesViewController

@synthesize policyNewID;
@synthesize table;
@synthesize search;
@synthesize data;
@synthesize arrData;
@synthesize policiesUtils;
@synthesize popController;
@synthesize popOver;
@synthesize visible;

#pragma mark - View Lifecycle
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

  // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
  [super viewDidLoad];
  self.title = @"Policies";
  [self loadData];
  dictRoles = [Utils getPartner];
  dictType = [Utils getProcessTypeIDDictionary];
  
  UIBarButtonItem *refreshButton = 
      [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh 
                                                   target:self 
                                                   action:@selector(synchronize:)];
	UIBarButtonItem *addButton = 
      [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd 
                                                   target:self 
                                                   action:@selector(addPolicy:)];
	self.navigationItem.leftBarButtonItem = refreshButton;
	self.navigationItem.rightBarButtonItem = addButton;
	[refreshButton release];
	[addButton release];
  
  popOver = [[PopOver alloc]init];
  popOver.arrContent = [[NSMutableArray alloc]initWithObjects:@"Policy",@"3rd-Party Contract",nil];
  popOver.sender = self;
  popController = [[UIPopoverController alloc]initWithContentViewController:popOver];
  popController.popoverContentSize = CGSizeMake(260,160);
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
  return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
  
    // Release any cached data, images, etc that aren't in use.
}

-(void)viewWillAppear:(BOOL)animated {
  [APP_IPAD.homeScreenViewController setButtonHighlighted:kButtonPolicies];
  visible = YES;
  [super viewWillAppear:YES];
}

-(void)viewWillDisappear:(BOOL)animated {
  visible = NO;
  [super viewWillDisappear:YES];
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
  [super dealloc];
}

#pragma mark - Table Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView {
	return [data count];
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	NSMutableArray *arrGroup = [data objectAtIndex:section];
	return [arrGroup count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	NSMutableArray *characters = [[NSMutableArray alloc]initWithObjects:@"A",@"B",@"C",@"D",@"E",
                                                                      @"F",@"G",@"H",@"I",@"J",
                                                                      @"K",@"L",@"M",@"N",@"O",
                                                                      @"P",@"Q",@"R",@"S",@"T",
                                                                      @"U",@"V",@"W",@"X",@"Y",
                                                                      @"Z",nil];
	return [characters objectAtIndex:section];
}

  // draw cell content
- (UITableViewCell *)tableView:(UITableView *)tableView 
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"Cell"; 
	PolicyCustomCell *cell = (PolicyCustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];	
	if (cell == nil) {
		NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PolicyCustomCell" owner:self options:nil];
		for (id oneObject in nib)
			if ([oneObject isKindOfClass:[PolicyCustomCell class]])
				cell = (PolicyCustomCell *)oneObject;
	} else {
		UIView *view = nil;
		view = [cell.contentView viewWithTag:1];
		if (!view) {
			[view removeFromSuperview];
		}
	}
	
  NSMutableArray *arrGroup = [data objectAtIndex:indexPath.section];
  if ([arrGroup count]!= 0) {
    cell.lblID.text = [[arrGroup objectAtIndex:indexPath.row] objectAtIndex:kStringHeaderID];
    cell.lblName.text = [[arrGroup objectAtIndex:indexPath.row] objectAtIndex:kStringName];
    cell.lblCate.text = [[arrGroup objectAtIndex:indexPath.row] objectAtIndex:kStringProduct];
    cell.lblType.text = [[arrGroup objectAtIndex:indexPath.row] objectAtIndex:kStringType]; 
  }   
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  NSMutableArray *section = [data objectAtIndex:indexPath.section];
  NSMutableArray *row = [section objectAtIndex:indexPath.row];
  NSString *ID = [row objectAtIndex:kStringGUID];
  if ([qPeriorMobInsuranceDemo_ThirdPartyHeader findByPrimaryKey:ID] != nil) {
    PolicyDetailsViewController *policyDetails = APP_IPAD.policiesDetail;
    policyDetails.data = [qPeriorMobInsuranceDemo_ThirdPartyHeader findByPrimaryKey:ID];
    [policyDetails loadData];
  } else if ([qPeriorMobInsuranceDemo_PolicyHeader findByPrimaryKey:ID] != nil) {
    PolicyDetailsViewController *policyDetails = APP_IPAD.policiesDetail;
    policyDetails.data = [qPeriorMobInsuranceDemo_PolicyHeader findByPrimaryKey:ID];
    [policyDetails loadData];
  }   
}

#pragma mark - Actions
- (void)loadData {
  policiesUtils = [[PoliciesUtils alloc]init];
	data = [policiesUtils getPolicies];
	arrData = [data copy];//[policiesUtils getPolicies];
	table.delegate = self;
	[table reloadData];
  if (policyNewID != nil) {
    [table scrollToRowAtIndexPath:[self getIndexPathOfCustomer:policyNewID] atScrollPosition:UITableViewScrollPositionTop animated:YES];
    [table selectRowAtIndexPath:[self getIndexPathOfCustomer:policyNewID] animated:YES scrollPosition:UITableViewScrollPositionTop];
  }
}

- (NSIndexPath *)getIndexPathOfCustomer:(NSString *)policyID {
  NSIndexPath *index;
  BOOL found = NO;
  int section = 0;
  while (!found && section < data.count) {
    NSMutableArray *array = [data objectAtIndex:section];
    int row = 0;
    while (!found && row < array.count) {
      NSMutableArray *arrayRow = [array objectAtIndex:row];
      if ([[arrayRow objectAtIndex:kStringHeaderID]isEqualToString:policyID]) {
        index = [NSIndexPath indexPathForRow:row inSection:section];
        found = YES;
      }
      row++;
    }
    section++;
  }
  return index;
}

- (void)refreshData {
  data = [policiesUtils getPolicies];
  arrData = [data copy];
  [table reloadData];
}

  // synchronize action
- (void)waiting {
  NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
  [Utils startWaiting:self.view withContent:nil];
  [pool drain];
}

- (IBAction)synchronize:(id)sender {
  [Utils synchronizeToServer];
}

- (IBAction)addPolicy:(id)sender {
  if ([popController isPopoverVisible]) {
		[popController dismissPopoverAnimated:YES];
	} else {
		[popController presentPopoverFromBarButtonItem:sender 
                          permittedArrowDirections:UIPopoverArrowDirectionAny 
                                          animated:NO];        
	}
}

-(void)dismissPopOver {
  [popController dismissPopoverAnimated:YES];
}


#pragma mark - Search
  // Search Bar action
- (void)searchBar:(UISearchBar *)searchbar textDidChange:(NSString *)searchText {
	if ([searchText isEqualToString:@""] || searchText==nil) {
		[self.table reloadData];
		return;
	}
	data = [[NSMutableArray alloc]init];
	for (int i=0; i<26; i++) {
		NSMutableArray *arr = [[NSMutableArray alloc]init];
		[data addObject:arr];
	}	
	
    // Filter Invidual and Corporate
	for (int i=0;i<[arrData count];i++) {		
		NSMutableArray *arrGroup = [arrData objectAtIndex:i];
		for (int j=0; j<[arrGroup count]; j++) {
      NSString *name = [[[arrGroup objectAtIndex:j] objectAtIndex:1] uppercaseString];
      searchText = [searchText uppercaseString];
      NSRange r = [name rangeOfString:searchText];
      if(r.location != NSNotFound) {
        [[data objectAtIndex:i] addObject:[arrGroup objectAtIndex:j]];
      }
		}
	}
	[table reloadData];
}

  // search Bar Cancel Action
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchbar {	
  [self cancelSearch];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchbar {
	[searchbar resignFirstResponder];
}

- (void)cancelSearch {
  data = [arrData copy];
	[table reloadData];
  self.search.text = @"";
  [self.searchDisplayController setActive:NO animated:YES];
}

@end

@implementation UISearchDisplayController (DoNotHideBar)

- (void)setActive:(BOOL)visible animated:(BOOL)animated {
  if (visible) {
    [self.searchContentsController.navigationController setNavigationBarHidden:YES animated:YES];
    [self.searchBar setShowsCancelButton:YES animated:YES];
    [self.searchBar becomeFirstResponder];
  } else {
    [self.searchContentsController.navigationController setNavigationBarHidden:NO animated:YES];
    [self.searchBar setShowsCancelButton:NO animated:YES];
    [self.searchBar resignFirstResponder];
  }
}

@end
