  //
  //  DatePickerPopOver.h
  //  QINS3
  //
  //  Created by mac osd on 9/27/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import <UIKit/UIKit.h>
#import "Utils.h"
@interface DatePickerPopOver : UIViewController {
  IBOutlet UIDatePicker *datePicker;
  IBOutlet UIBarButtonItem * doneButton;
  IBOutlet UIToolbar * toolbar;
  id sender;
  id returnData;
}
@property(nonatomic, retain) IBOutlet UIDatePicker *datePicker;
@property(nonatomic, retain) IBOutlet UIBarButtonItem *doneButton;
@property(nonatomic, retain) IBOutlet UIToolbar *toolbar;
@property(nonatomic, retain) id sender;
@property(nonatomic, retain) id returnData;

- (IBAction)dateSelected:(id)sender;
- (IBAction)dateCancel:(id)sender;
@end
