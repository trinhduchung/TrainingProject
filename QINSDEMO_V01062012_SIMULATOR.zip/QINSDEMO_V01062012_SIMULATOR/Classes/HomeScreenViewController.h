  //
  //  HomeScreenViewController.h
  //  QINS3
  //
  //  Created by Binh Ho on 8/15/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import <UIKit/UIKit.h>

@interface HomeScreenViewController : UIViewController {
	UIToolbar *toolbar;
  BOOL visible;
  
  UIBarButtonItem *infoButton;
  UIBarButtonItem *cusButton;
  UIBarButtonItem *poliButton;
  UIBarButtonItem *profileButton;
}

@property (nonatomic) BOOL visible;
@property (nonatomic, retain) UIBarButtonItem *infoButton;
@property (nonatomic, retain) UIBarButtonItem *cusButton;
@property (nonatomic, retain) UIBarButtonItem *poliButton;
@property (nonatomic, retain) UIBarButtonItem *profileButton;

- (IBAction)customerAction:(id)sender;
- (IBAction)policiesAction:(id)sender;
- (UIViewController *)createSplitView:(UIViewController *)rootView1 
                           DetailView:(UIViewController *)detailView1;
- (void)initTooolbar;
- (void)home_clicked:(id)sender;
- (IBAction)customerAction:(id)sender;
- (IBAction)policiesAction:(id)sender;
- (IBAction)setting_clicked:(id)sender;
- (IBAction)interview_clicked:(id)sender;
- (IBAction)profiles_clicked:(id)sender;
- (void)createSplitViews;
- (void)releaseAndReCreateSplitViews;
- (void)setToolbarBack:(NSString*)bgFilename 
               toolbar:(UIToolbar*)bottombar;
- (void)setButtonHighlighted:(int)button;

@end
