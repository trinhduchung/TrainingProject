//
//  RelatedPolicies.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RelatedPolicies.h"
#import "RelatedPolicyCustomCell.h"
//#import "qPeriorMobInsuranceDemo_PolicyPartner.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_PolicyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyItem.h"
#import "SUPObjectList.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "Utils.h"
#import "PoliciesUtils.h"
#import "PolicyDetailsViewController.h"
#import "PoliciesEditViewController.h"
#import "CustomerDetailsViewController.h"

@implementation RelatedPolicies

@synthesize customerNumber;
@synthesize isPolicy;
@synthesize table;
@synthesize isPushed;

#pragma mark - View lifecycle

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
        // Custom initialization
  }
  return self;
}

- (void)dealloc  {
  [super dealloc];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidLoad {
  table.delegate = self;
    //[self initDictionaries];
  [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated {
  self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:[Utils getLeftButtons:self withMode:kToggleCancel]];
  [self initDictionaries];
  UIBarButtonItem *addButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addContract:)];
  self.navigationItem.rightBarButtonItem = addButton;
  [addButton release];
  [super viewWillAppear:YES];
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	return YES;
}

#pragma mark - Table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  return [[dictHeader allKeys] count]+1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {	
  static NSString *CellIdentifier = @"Cell"; 
	RelatedPolicyCustomCell *cell = (RelatedPolicyCustomCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];	
	if (cell == nil) {
		NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RelatedPolicyCustomCell" owner:self options:nil];
		for (id oneObject in nib)
			if ([oneObject isKindOfClass:[RelatedPolicyCustomCell class]])
				cell = (RelatedPolicyCustomCell *)oneObject;
	}
    
  if (indexPath.row == 0) {
    UIView *bg = [[UIView alloc] initWithFrame:cell.frame];
    bg.backgroundColor = [UIColor grayColor];
    cell.backgroundView = bg;
    [bg release];
    cell.userInteractionEnabled = NO;
    cell.accessoryType = UITableViewCellAccessoryNone;
    if (isPolicy) {
      cell.txtName.hidden = YES;
      cell.txtDate.text = @"Start Date - End Date";
    } else {
      cell.txtName.hidden = NO;
      cell.txtDate.text = @"Renewal Date";
    }
  } else {        
    if (isPolicy) {    
      cell.txtName.hidden = YES;
      qPeriorMobInsuranceDemo_PolicyHeader *header = [[dictHeader allValues] objectAtIndex:indexPath.row-1];
      cell.txtID.text = header.pId;
      cell.txtStatus.text = header.pStatus;
      cell.txtCate.text = [dictType valueForKey:header.pType];
      NSString *startDate = [Utils convertDateToStringAndDisplay:[header.pDateStart stringValue] withFormat:@"yyyyMMddHHmmss"];
      NSString *endDate = [Utils convertDateToStringAndDisplay:[header.pDateEnd stringValue] withFormat:@"yyyyMMddHHmmss"];
      cell.txtDate.text = [NSString stringWithFormat:@"%@ - %@", startDate, endDate];
      
      NSString *payment = @"";      
      SUPObjectList *listItems = header.PolicyHeaderPolicyItem;
      int count = listItems.size;
      int i = 0;
      while ([payment isEqualToString:@""] && i < count) {
        payment = [[listItems item:i] pItemPaymentType];
        i++;
      }
      cell.txtRate.text = [policyUtils convertRateDatabaseToDisplay:[[[listItems item:0]pItemRate] stringValue]];
      cell.txtPayment.text = [dictPayment valueForKey:payment];            
    } else {
      qPeriorMobInsuranceDemo_ThirdPartyHeader *header = [[dictHeader allValues] objectAtIndex:indexPath.row-1];
      cell.txtID.text = header.pId;
      cell.txtStatus.text = header.pStatus;
      cell.txtCate.text = [dictType valueForKey:header.pType];
      cell.txtDate.text = [Utils convertDateToStringAndDisplay:[header.p3rdDateRenewal stringValue] withFormat:@"yyyyMMddHHmmss"];
      NSString *payment = @"";
      SUPObjectList *listItems = header.ThirdPartyHeaderThirdPartyItem;
      int count = listItems.size;
      int i = 0;
      while ([payment isEqualToString:@""] && i < count) {
        payment = [[listItems item:i] pItemPaymentType];
        i++;
      }
      cell.txtRate.text = [policyUtils convertRateDatabaseToDisplay:[[[listItems item:0]pItemRate] stringValue]];
      cell.txtPayment.text = [dictPayment valueForKey:payment];
      cell.txtName.text = header.pCompetitorName;
    }
    cell.userInteractionEnabled = YES;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
  }
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  PolicyDetailsViewController *policyDetails = APP_IPAD.policiesDetail;
  policyDetails.data = [[dictHeader allValues] objectAtIndex:indexPath.row-1];
  if (isPolicy) {
    policyDetails.title = @"Policy Details";
  } else {
    policyDetails.title = @"3-rd Contract Details";
  }
  [policyDetails initData];
  [policyDetails loadData];
  @try {
    policyDetails.isPushed = YES;
    [self.navigationController pushViewController:policyDetails animated:YES];        
  }
  @catch (NSException *exception) {
    policyDetails.isPushed = NO;
    [self.navigationController popToViewController:policyDetails animated:YES];
  }
  @finally {
      
  }   
}

#pragma mark - Actions

- (IBAction)addContract:(id)sender {
  PoliciesEditViewController *policiesEdit = APP_IPAD.policyEdit;
  policiesEdit.editMode = NO;
  if (isPolicy) {
    policiesEdit.isPolicy = YES;
    policiesEdit.title = @"New Policy";
  } else {
    policiesEdit.isPolicy = NO;
    policiesEdit.title = @"New 3rd-Party Contract";
  }
  policiesEdit.isPushed = YES;
  CustomerDetailsViewController *customerDetail = APP_IPAD.customerDetail;
  policiesEdit.holder = customerDetail.customer;    
  policiesEdit.lockHolder = YES;
  [self.navigationController pushViewController:policiesEdit animated:YES];
}

-(IBAction)cancel:(id)sender {
  [self.navigationController popViewControllerAnimated:YES];
}

-(void)refreshData {
  [self initDictionaries];
  [table reloadData];
  [table beginUpdates];
  [table endUpdates];
}

#pragma mark - Dictionaries

-(void)initDictionaries {    
  policyUtils = [[PoliciesUtils alloc]init];
  dictType = [Utils getProcessTypeIDDictionary];
  if (dictHeader == nil) {
    dictHeader = [[NSMutableDictionary alloc]init];
  } else {
    [dictHeader removeAllObjects];
  }
  
  if (isPolicy) {
    dictHeader = [Utils getPolicies:customerNumber];
  } else {
    dictHeader = [Utils getThirdparties:customerNumber];
  }
  
  dictPayment = [Utils getPaymentIDDictionary];
  [table reloadData];
}

@end
