//
//  RelationShipAddNewController.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 10/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomerEditPopOver.h"
#import "PolicyRolesPopOver.h"
#import "DatePickerPopOver.h"
#import "RelationShipsViewController.h"

#define kTitle        @"kTitle"
#define kTextField    @"kTextField"
#define kValue        @"kValue"

#define kRowName      0
#define kRowType      1
#define kRowStartDate 2
#define kRowEndDate   3

@interface RelationShipAddNewController : UIViewController<UITextFieldDelegate,UIPopoverControllerDelegate, UITableViewDataSource, UITableViewDelegate> {
  RelationShipsViewController *delegate;
  id person2;
  IBOutlet UITableView *table;
  NSMutableArray *arrContent;
    
  UITextField *txtName;
  UITextField *txtType;
  UITextField *txtStartDate;
  UITextField *txtEndDate;
    
  UIPopoverController *popController;
  UIPopoverController *roleController;
  UIPopoverController *dateController;
  CustomerEditPopOver *popOver;
  PolicyRolesPopOver *roleOver;
  DatePickerPopOver *dateOver;
    
  NSMutableDictionary *dictRelationType;
  NSMutableDictionary *dictRelationDesc;
  NSMutableDictionary *dictCustomers;
  NSString *number;
  BOOL isPushed;
}

@property (nonatomic, retain) RelationShipsViewController *delegate;
@property (nonatomic, retain) id person2;
@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic, retain) NSMutableArray *arrContent;

@property (nonatomic, retain) UITextField *txtName;
@property (nonatomic, retain) UITextField *txtType;
@property (nonatomic, retain) UITextField *txtStartDate;
@property (nonatomic, retain) UITextField *txtEndDate;

@property (nonatomic, retain) UIPopoverController *popController;
@property (nonatomic, retain) UIPopoverController *roleController;
@property (nonatomic, retain) UIPopoverController *dateController;
@property (nonatomic, retain) CustomerEditPopOver *popOver;
@property (nonatomic, retain) PolicyRolesPopOver *roleOver;
@property (nonatomic, retain) DatePickerPopOver *dateOver;

@property (nonatomic, retain) NSMutableDictionary *dictRelationType;
@property (nonatomic, retain) NSMutableDictionary *dictRelationDesc;
@property (nonatomic, retain) NSMutableDictionary *dictCustomers;

@property (nonatomic, retain) NSString *number;
@property (nonatomic) BOOL isPushed;

- (void)initTable;
- (IBAction)cancel:(id)sender;
- (IBAction)save:(id)sender;
- (BOOL)validate;
- (BOOL)showAlert:(NSString *)content;

@end
