//
//  RelationShipAddNewController.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 10/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RelationShipAddNewController.h"
#import "CustomCell.h"
#import "CustomerEditPopOver.h"
#import "qPeriorMobInsuranceDemo_CustomerRelationships.h"
#import "SUPObjectList.h"
#import "PolicyRolesPopOver.h"
#import "DatePickerPopOver.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "Utils.h"
#import "RelationShipsViewController.h"
#import "CustomerUtils.h"

@implementation RelationShipAddNewController

@synthesize delegate;
@synthesize person2;
@synthesize table;
@synthesize arrContent;

@synthesize txtName;
@synthesize txtType;
@synthesize txtStartDate;
@synthesize txtEndDate;
@synthesize popOver;
@synthesize popController;
@synthesize roleController;
@synthesize dateController;
@synthesize roleOver;
@synthesize dateOver;
@synthesize dictRelationType;
@synthesize dictRelationDesc;
@synthesize number;
@synthesize dictCustomers;
@synthesize isPushed;

#pragma mark - View lifecycle

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
        // Custom initialization
  }
  return self;
}

- (void)dealloc {
  [super dealloc];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
  // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidLoad {
  [super viewDidLoad];
  UIBarButtonItem *cancelButton = 
    [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel 
                                                 target:self 
                                                 action:@selector(cancel:)];
  UIBarButtonItem *saveButton = 
    [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave 
                                                 target:self 
                                                 action:@selector(save:)];
  self.navigationItem.leftBarButtonItem = cancelButton;
  self.navigationItem.rightBarButtonItem = saveButton;
  [cancelButton release];
  [saveButton release];
  
  popOver = [[CustomerEditPopOver alloc]init];
  popController = [[UIPopoverController alloc]initWithContentViewController:popOver];
  popController.popoverContentSize = CGSizeMake(350, 300);
  
  roleOver = [[PolicyRolesPopOver alloc]init];
  roleController = [[UIPopoverController alloc]initWithContentViewController:roleOver];
  roleController.popoverContentSize = CGSizeMake(350, 800);
    
  dateOver = [[DatePickerPopOver alloc]init];
  dateController = [[UIPopoverController alloc]initWithContentViewController:dateOver];
  dateController.popoverContentSize = CGSizeMake(350, 254);
    
  dictRelationType = [CustomerUtils getRelationShipTypeDict];  
  dictRelationDesc = [CustomerUtils getRelationShipTypeDescDict];
  dictCustomers = [Utils getCustomers];
  self.title = @"New Relationship";
}

- (void)viewWillAppear:(BOOL)animated {
  self.navigationItem.leftBarButtonItem = 
    [[UIBarButtonItem alloc]initWithCustomView:[Utils getLeftButtons:self 
                                                            withMode:kToggleCancel]];
  [super viewWillAppear:YES];
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	return YES;
}


#pragma mark - Actions

- (IBAction)cancel:(id)sender {
  [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)save:(id)sender {
  if ([self validate]) {
    qPeriorMobInsuranceDemo_CustomerRelationships *relation = [[qPeriorMobInsuranceDemo_CustomerRelationships alloc]init];
    relation.bpNumber = number;
    if ([[dictCustomers valueForKey:number] isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
      relation.bpNumber1Name = [[dictCustomers valueForKey:number] bpCorpName];        
    } else if ([[dictCustomers valueForKey:number] isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
      relation.bpNumber1Name = [NSString stringWithFormat:@"%@ %@", 
                                  [[dictCustomers valueForKey:number] bpIndFirstName], 
                                  [[dictCustomers valueForKey:number] bpIndLastName]];
    }
    relation.bpNumber1Region = [[dictCustomers valueForKey:number] bpAddrRegion];
        
    relation.bpNumber2 = [person2 bpNumber];
    if ([person2 isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
      relation.bpNumber2Name = [person2 bpCorpName];
    } else if ([person2 isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
      relation.bpNumber2Name = [NSString stringWithFormat:@"%@ %@", [person2 bpIndFirstName], [person2 bpIndLastName]];
    }
        
    relation.bpRelType = [dictRelationDesc valueForKey:txtType.text];
    relation.bpRelTypeText1 = txtType.text;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    relation.bpRelValidFrom = [dateFormat dateFromString:[Utils convertStringToDateAndSave:txtStartDate.text 
                                                                                withFormat:@"yyyy-MM-dd"]];
    relation.bpRelValidTo = [dateFormat dateFromString:[Utils convertStringToDateAndSave:txtEndDate.text
                                                                              withFormat:@"yyyy-MM-dd"]];
    [relation create];
    [delegate.data addObject:relation];
    [delegate.table reloadData];

    [self.navigationController popViewControllerAnimated:YES];
  }    
}

- (BOOL)showAlert:(NSString*)content {
  UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" 
                                                 message:content 
                                                delegate:self 
                                       cancelButtonTitle:@"OK" 
                                       otherButtonTitles:nil];
  [alert show];
  [alert release];
  return NO;
}

- (BOOL)validate {
  if (txtName.text == nil || [txtName.text isEqualToString:@""]) {
    return [self showAlert:@"You must select a customer."];
  }
  if (txtType.text == nil || [txtType.text isEqualToString:@""]) {
    return [self showAlert:@"You must select a relationship type."];
  }
  if (txtEndDate.text != nil && ![txtEndDate.text isEqualToString:@""]) {
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [dateFormat dateFromString:[Utils convertStringToDateAndSave:txtStartDate.text 
                                                                     withFormat:@"yyyy-MM-dd"]];
    NSDate *date1 = [dateFormat dateFromString:[Utils convertStringToDateAndSave:txtEndDate.text 
                                                                      withFormat:@"yyyy-MM-dd"]];
    if ([date compare:date1] != NSOrderedAscending) {
      return [self showAlert:@"You must select a day after today."];
    }
  }  
  return YES;
}

- (void)initTable {
  if (arrContent == nil) {
    arrContent = [[NSMutableArray alloc]init];
  } else {
    [arrContent removeAllObjects];
  }
    
  [arrContent addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                           @"Customer", kTitle,
                           self.txtName, kTextField, nil]];
  [arrContent addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                           @"Type", kTitle,
                           self.txtType, kTextField, nil]];
  [arrContent addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                           @"Start Date", kTitle,
                           self.txtStartDate, kTextField, nil]];
  [arrContent addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                           @"End Date", kTitle,
                           self.txtEndDate, kTextField, nil]];
  [table reloadData];
}

- (void)dismissPopover {
  [popController dismissPopoverAnimated:YES];
  [roleController dismissPopoverAnimated:YES];
  [dateController dismissPopoverAnimated:YES];
}

- (void)getDataFromPopOver:(id)sender {
  if ([sender isKindOfClass:[PolicyRolesPopOver class]]) {
    if ([[roleOver.returnData bpNumber] isEqualToString:number]) {
      [self showAlert:@"You must select different customer"];
    } else {
      if ([roleOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
          //qPeriorMobInsuranceDemo_CustomerIndividual *ind = roleOver.returnData;
        person2 = [(qPeriorMobInsuranceDemo_CustomerIndividual*)roleOver.returnData retain];
        txtName.text = [NSString stringWithFormat:@"%@ %@", [person2 bpIndFirstName], [person2 bpIndLastName]];        
      } else if ([roleOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
        person2 = [(qPeriorMobInsuranceDemo_CustomerCorporate*)roleOver.returnData retain];
          //qPeriorMobInsuranceDemo_CustomerCorporate *cor = roleOver.returnData;
        txtName.text = [person2 bpCorpName];
      }
      [person2 retain];
    }
  } else if ([sender isKindOfClass:[DatePickerPopOver class]]) {
    DatePickerPopOver* picker = (DatePickerPopOver*)sender;
    txtEndDate.text = [NSString stringWithFormat:@"%@", picker.returnData];
  } else {
    txtType.text = [NSString stringWithFormat:@"%@", popOver.returnData];
  }
  [self dismissPopover];
}

#pragma mark - Table
- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	return [arrContent count];
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	return @"";
}

// draw cell item 
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  static NSString *CellIndentifier = @"Cell";
  CustomCell *cell = (CustomCell*) [tableView dequeueReusableCellWithIdentifier:CellIndentifier];
  if (cell == nil) {
    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
    for (id object in nib) {
      if ([object isKindOfClass:[CustomCell class]]) {
        cell = (CustomCell*)object;
      }
    }
  } else {
    UIView *view = nil;
    view = [cell.contentView viewWithTag:1];
    if (!view) {
      [view removeFromSuperview];
    }
  }
    
  NSString *text = [[arrContent objectAtIndex:indexPath.row]valueForKey:kTitle];    
  cell.label.text = text;
  UITextField *textField = [[arrContent objectAtIndex: indexPath.row] valueForKey:kTextField];
  if (indexPath.row == 2) {
    NSDate *currDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"dd.MM.yyyy"];
    NSString *dateString = [dateFormatter stringFromDate:currDate];
    textField.text = dateString;
  }
	[cell.contentView addSubview:textField];
  if (indexPath.row != kRowStartDate) {
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
  }
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  UITableViewCell *newCell = [self.table cellForRowAtIndexPath:indexPath];
  CGRect frame = CGRectMake(newCell.frame.origin.x+newCell.frame.size.width-45, 
                            newCell.frame.origin.y-2, 
                            newCell.frame.size.width, 
                            newCell.frame.size.height); 
  int row = indexPath.row;
  SUPObjectList *listRelation = [[SUPObjectList alloc]init];
  NSMutableArray *arrayType = [[NSMutableArray alloc]initWithArray:[dictRelationDesc allKeys]];
  arrayType = (NSMutableArray *)[arrayType sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
  switch (row) {
    case kRowName:
      roleOver.sender = self;
      [self.roleController presentPopoverFromRect:frame 
                                           inView:self.view 
                         permittedArrowDirections:UIPopoverArrowDirectionAny 
                                         animated:YES];
      break;
    case kRowType:
      for (int i = 0; i < arrayType.count; i++) {
        [listRelation add:[arrayType objectAtIndex:i]];
      }
      popOver.arrContent = listRelation;
      popOver.sender = self;
      [popOver loadData];
      [self.popController presentPopoverFromRect:frame 
                                          inView:self.view 
                        permittedArrowDirections:UIPopoverArrowDirectionAny 
                                        animated:YES];
      break;
    case kRowEndDate:
      dateOver.sender = self;
      [dateController presentPopoverFromRect:frame 
                                      inView:self.view 
                    permittedArrowDirections:UIPopoverArrowDirectionAny 
                                    animated:YES];
      break;
    default:
      break;
  }
}

#pragma mark - TextFields

-(UITextField*)txtName {
	if (txtName == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtName = [[UITextField alloc] initWithFrame:frame];
		txtName.borderStyle = UITextBorderStyleNone;
		txtName.font = [UIFont systemFontOfSize:17];
		txtName.backgroundColor = [UIColor clearColor];
		txtName.keyboardType = UIKeyboardTypeDefault;
		txtName.returnKeyType = UIReturnKeyDone;
		txtName.tag = 1;
		txtName.delegate = self;		
    txtName.userInteractionEnabled = NO;
	}
	return txtName;
}

-(UITextField*)txtType {
  if (txtType == nil) {
    CGRect frame = CGRectMake(130, 10, 453, 30);
    txtType = [[UITextField alloc]initWithFrame:frame];
    txtType.borderStyle = UITextBorderStyleNone;
    txtType.font = [UIFont systemFontOfSize:17];
    txtType.backgroundColor = [UIColor clearColor];
    txtType.keyboardType = UIKeyboardTypeDefault;
    txtType.returnKeyType = UIReturnKeyDone;
    txtType.tag = 1;
    txtType.delegate = self;
    txtType.userInteractionEnabled = NO;
  }
  return txtType;
}

-(UITextField*)txtStartDate {
  if (txtStartDate == nil) {
    CGRect frame = CGRectMake(130, 10, 453, 30);
    txtStartDate = [[UITextField alloc]initWithFrame:frame];
    txtStartDate.borderStyle = UITextBorderStyleNone;
    txtStartDate.keyboardType = UIKeyboardTypeDefault;
    txtStartDate.returnKeyType = UIReturnKeyDone;
    txtStartDate.backgroundColor = [UIColor clearColor];
    txtStartDate.font = [UIFont systemFontOfSize:17];
    txtStartDate.userInteractionEnabled = NO;
    txtStartDate.tag = 1;
    txtStartDate.delegate = self;
    txtStartDate.userInteractionEnabled = NO;
  }
  return txtStartDate;
}

-(UITextField*)txtEndDate {
  if (txtEndDate == nil) {
    CGRect frame = CGRectMake(130, 10, 453, 30);
    txtEndDate = [[UITextField alloc]initWithFrame:frame];
    txtEndDate.borderStyle = UITextBorderStyleNone;
    txtEndDate.keyboardType = UIKeyboardTypeDefault;
    txtEndDate.returnKeyType = UIReturnKeyDone;
    txtEndDate.backgroundColor = [UIColor clearColor];
    txtEndDate.font = [UIFont systemFontOfSize:17];
    txtEndDate.tag = 1;
    txtEndDate.delegate = self;
    txtEndDate.userInteractionEnabled = NO;
  }
  return txtEndDate;
}

@end
