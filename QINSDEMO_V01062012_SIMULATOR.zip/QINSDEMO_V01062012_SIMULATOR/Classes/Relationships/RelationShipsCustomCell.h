//
//  RelationShipsCustomCell.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RelationShipsCustomCell : UITableViewCell {
  IBOutlet UILabel *txtType;
  IBOutlet UILabel *txtName;
}

@property (nonatomic, retain) IBOutlet UILabel *txtType;
@property (nonatomic, retain) IBOutlet UILabel *txtName;

@end
