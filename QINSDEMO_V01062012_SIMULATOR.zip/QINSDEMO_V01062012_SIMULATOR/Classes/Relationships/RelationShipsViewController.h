//
//  RelationShipsViewController.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RelationShipsViewController : UIViewController {
  IBOutlet UITableView *table;
  NSMutableArray *data;
  NSMutableDictionary *dictCustomers;
  NSString *number;
  int countRows;
  BOOL isPushed;
}

@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic, retain) NSMutableArray *data;
@property (nonatomic, retain) NSMutableDictionary *dictCustomers;
@property (nonatomic, retain) NSString *number;
@property (nonatomic) BOOL isPushed;

- (IBAction)addRelationShip:(id)sender;
- (IBAction)cancel:(id)sender;
- (NSMutableArray*)getRelationShips:(NSString*)custNumber;

@end
