//
//  RelatedPolicies.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SUPObjectList.h"
#import "PoliciesUtils.h"

@interface RelatedPolicies : UIViewController<UITableViewDelegate, UITableViewDataSource> {
  PoliciesUtils *policyUtils;
  NSString *customerNumber;
  BOOL isPolicy;
  IBOutlet UITableView *table;
  NSMutableDictionary *dictHeader;
  NSMutableDictionary *dictType;
  NSMutableDictionary *dictPayment;
  BOOL isPushed;
}

@property (nonatomic, retain) NSString *customerNumber;
@property (nonatomic) BOOL isPolicy;
@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic) BOOL isPushed;

- (void)initDictionaries;
- (IBAction)cancel:(id)sender;
- (IBAction)addContract:(id)sender;
- (void)refreshData;

@end
