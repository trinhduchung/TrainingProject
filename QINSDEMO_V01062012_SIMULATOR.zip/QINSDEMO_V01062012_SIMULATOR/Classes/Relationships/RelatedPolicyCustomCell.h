//
//  RelatedPolicyCustomCell.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RelatedPolicyCustomCell : UITableViewCell {
  IBOutlet UILabel *txtID;
  IBOutlet UILabel *txtCate;
  IBOutlet UILabel *txtDate;
  IBOutlet UILabel *txtStatus;
  IBOutlet UILabel *txtName;
  IBOutlet UILabel *txtRate;
  IBOutlet UILabel *txtPayment;
}

@property (nonatomic, retain) IBOutlet UILabel *txtID;
@property (nonatomic, retain) IBOutlet UILabel *txtCate;
@property (nonatomic, retain) IBOutlet UILabel *txtDate;
@property (nonatomic, retain) IBOutlet UILabel *txtStatus;
@property (nonatomic, retain) IBOutlet UILabel *txtName;
@property (nonatomic, retain) IBOutlet UILabel *txtRate;
@property (nonatomic, retain) IBOutlet UILabel *txtPayment;

@end
