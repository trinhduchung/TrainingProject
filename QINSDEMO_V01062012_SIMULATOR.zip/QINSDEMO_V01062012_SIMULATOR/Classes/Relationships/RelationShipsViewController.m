//
//  RelationShipsViewController.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RelationShipsViewController.h"
#import "RelationShipsCustomCell.h"
#import "qPeriorMobInsuranceDemo_CustomerRelationships.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "SUPObjectList.h"
#import "CustomerDetailsViewController.h"
#import "Utils.h"
#import "RelationShipAddNewController.h"

@implementation RelationShipsViewController

@synthesize table;
@synthesize data;
@synthesize dictCustomers;
@synthesize number;
@synthesize isPushed;


#pragma mark - View lifecycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
        // Custom initialization
  }
  return self;
}

- (void)dealloc {
  [super dealloc];
}

- (void)didReceiveMemoryWarning {
  // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
    
  // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidLoad {
  [super viewDidLoad];
  dictCustomers = [Utils getCustomers];
  self.title = @"Relationships";
  UIBarButtonItem *addButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addRelationShip:)];
  self.navigationItem.rightBarButtonItem = addButton;
  [addButton release];
}

-(void)viewWillAppear:(BOOL)animated {
  countRows = [data count];
  [table reloadData];
  self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:[Utils getLeftButtons:self withMode:kToggleCancel]];
  [super viewWillAppear:YES];
}

- (void)viewDidUnload {
  [super viewDidUnload];
  // Release any retained subviews of the main view.
  // e.g. self.myOutlet = nil;
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations
	return YES;
}

#pragma mark - Table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return countRows;	
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {	
  static NSString *CellIdentifier = @"Cell"; 
	RelationShipsCustomCell *cell = (RelationShipsCustomCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];	
	if (cell == nil) {
		NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RelationShipsCustomCell" owner:self options:nil];
		for (id oneObject in nib)
			if ([oneObject isKindOfClass:[RelationShipsCustomCell class]])
				cell = (RelationShipsCustomCell *)oneObject;
	}
  qPeriorMobInsuranceDemo_CustomerRelationships *relation = [data objectAtIndex:indexPath.row];
  cell.txtType.text = relation.bpRelTypeText1;
  cell.txtName.text = [relation.bpNumber isEqualToString:number]?relation.bpNumber2Name:relation.bpNumber1Name;
  cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  qPeriorMobInsuranceDemo_CustomerRelationships *relation = [data objectAtIndex:indexPath.row];
  if ([dictCustomers valueForKey:relation.bpNumber2] != nil) {
    CustomerDetailsViewController *customerDetails = APP_IPAD.customerDetail;
    customerDetails.customer = [dictCustomers valueForKey:relation.bpNumber2];
    [customerDetails loadData];
    [self.navigationController popViewControllerAnimated:YES];
  }
}

#pragma mark - Actions

- (IBAction)cancel:(id)sender {
  [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)addRelationShip:(id)sender {
  RelationShipAddNewController *relationNew = [[RelationShipAddNewController alloc]initWithNibName:@"RelationShipAddNewController" bundle:nil];
  relationNew.number = number;
  relationNew.delegate = self;
  [relationNew initTable];
  [self.navigationController pushViewController:relationNew animated:YES];
}

- (NSMutableArray *)getRelationShips:(NSString *)custNumber {
  NSMutableArray *arrRelation = [[NSMutableArray alloc]init];
  SUPObjectList *listRelations = [[qPeriorMobInsuranceDemo_CustomerRelationships findAll]retain];
  for (qPeriorMobInsuranceDemo_CustomerRelationships *relation in listRelations) {
    if (([relation.bpNumber isEqualToString:custNumber] || [relation.bpNumber2 isEqualToString:custNumber]) && ![arrRelation containsObject:relation]) {
      [arrRelation addObject:relation];
    }
  }
  return arrRelation;
}

@end
