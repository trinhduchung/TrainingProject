//
//  KFZProductInfo3.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/20/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KFZProductInfo3 : UIViewController {
  IBOutlet UIButton *btnSummary;
}

@property (nonatomic, retain) IBOutlet UIButton *btnSummary;

@end
