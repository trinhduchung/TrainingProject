//
//  KFZProductInfo2.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/20/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DatePickerPopOver.h"

@interface KFZProductInfo2 : UIViewController <UITextFieldDelegate> {
  IBOutlet UIButton       *btnWeiter;
  IBOutlet UITextField    *txtMaxAmountPersDemage; 
  IBOutlet UITextField    *txtOwnRiskAmount;   
  IBOutlet UITextField    *txtCredit;
  IBOutlet UITextField    *txtDateRageFrom;  
  IBOutlet UITextField    *txtDateRageTo;
    
    
  UITextField         *selectedField; 
  CGFloat              animatedDistance;
  UIPopoverController *popDateController;
  DatePickerPopOver   *dateOver;
    
}

@property (nonatomic, retain) IBOutlet UIButton      *btnWeiter;
@property (nonatomic, retain) IBOutlet UITextField   *txtMaxAmountPersDemage;
@property (nonatomic, retain) IBOutlet UITextField   *txtOwnRiskAmount; 
@property (nonatomic, retain) IBOutlet UITextField   *txtCredit;
@property (nonatomic, retain) UITextField            *selectedTextField;  
@property (nonatomic, retain) UIPopoverController    *popDateController;
@property (nonatomic, retain) DatePickerPopOver      *dateOver;
@property (nonatomic, retain) IBOutlet UITextField   *txtDateRageFrom; 
@property (nonatomic, retain) IBOutlet UITextField   *txtDateRageTo; 




@end
