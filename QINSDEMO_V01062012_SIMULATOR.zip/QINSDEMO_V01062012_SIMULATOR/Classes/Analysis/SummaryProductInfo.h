//
//  SummaryProductInfo.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/20/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DatePickerPopOver.h"

@interface SummaryProductInfo : UIViewController <UITextFieldDelegate> {

    IBOutlet UITextField    *txtNextDate;  
    
    UIPopoverController *popDateController;
    DatePickerPopOver   *dateOver;
    CGFloat              animatedDistance;
    UITextField         *selectedField; 
    

}

    @property (nonatomic, retain) IBOutlet UITextField   *txtNextDate; 
    @property (nonatomic, retain) UIPopoverController    *popDateController;
    @property (nonatomic, retain) DatePickerPopOver      *dateOver;
    @property (nonatomic, retain) UITextField            *selectedTextField;  

@end
