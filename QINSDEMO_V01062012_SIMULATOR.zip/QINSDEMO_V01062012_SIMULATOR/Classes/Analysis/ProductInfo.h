//
//  ProductInfo.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/20/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductInfo : UIViewController

@end
