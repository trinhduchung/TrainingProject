//
//  KFZProductInfo.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/20/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KFZProductInfo : UIViewController <UITextFieldDelegate> {
  IBOutlet UIButton       *btnWeiter;
  IBOutlet UITextField    *txtMaxAmountPersDemage;     
  IBOutlet UITextField    *txtMaxAmountGenDemage;   
    
    UITextField    *selectedTextField;
    CGFloat animatedDistance;
    
    
    
   
}

@property (nonatomic, retain) IBOutlet UIButton *btnWeiter;
@property (nonatomic, retain) IBOutlet UITextField *txtMaxAmountPersDemage;
@property (nonatomic, retain) IBOutlet UITextField *txtMaxAmountGenDemage;
@property (nonatomic, retain) UITextField *selectedTextField;
 
@end
