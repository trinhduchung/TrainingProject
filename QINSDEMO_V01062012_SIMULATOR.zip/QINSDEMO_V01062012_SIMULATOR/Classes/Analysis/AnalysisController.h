//
//  AnalysisController.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/19/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnalysisController : UIViewController {
  IBOutlet UIButton *btnAngebot;
  IBOutlet UIButton *btnBeitrag;
  IBOutlet UIButton *btnProduct;
  IBOutlet UIImageView *imageView;
}

@property (nonatomic, retain) IBOutlet UIButton *btnAngebot;
@property (nonatomic, retain) IBOutlet UIButton *btnBeitrag;
@property (nonatomic, retain) IBOutlet UIButton *btnProduct;
@property (nonatomic, retain) IBOutlet UIImageView *imageView;

@end
