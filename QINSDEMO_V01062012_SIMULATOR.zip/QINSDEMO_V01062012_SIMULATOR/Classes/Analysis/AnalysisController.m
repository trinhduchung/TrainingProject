//
//  AnalysisController.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/19/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import "AnalysisController.h"
#import "AnalysisHome.h"
#import "ProductInfo.h"
#import "Utils.h"
#import "KFZProductInfo.h"
#import "SummaryProductInfo.h"
#import "HomeScreenViewController.h"

@implementation AnalysisController

@synthesize btnAngebot;
@synthesize btnBeitrag;
@synthesize btnProduct;
@synthesize imageView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
  [super viewDidLoad];
  self.navigationItem.leftBarButtonItem = self.navigationItem.backBarButtonItem;
 
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated {
    UIButton* backButton = [UIButton buttonWithType:101];
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [backButton setTitle:@"Back" forState:UIControlStateNormal];
    UIBarButtonItem* backItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = backItem;
    [super viewWillAppear:YES];
}

- (void)back:(id)sender {
    HomeScreenViewController *homeViewController = APP_IPAD.homeScreenViewController;
    [homeViewController.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)showProductInfo:(id)sender {
  [imageView setHidden:NO];
  ProductInfo *productInfo = [[ProductInfo alloc]initWithNibName:@"ProductInfo" bundle:nil];
  [APP_IPAD.analysisHome.navigationController pushViewController:productInfo animated:YES];
}

- (IBAction)showKFZ:(id)sender {
  [imageView setHidden:NO];
  KFZProductInfo *kfz = [[KFZProductInfo alloc]initWithNibName:@"KFZProductInfo" bundle:nil];
  [APP_IPAD.analysisHome.navigationController pushViewController:kfz animated:YES];
}

- (IBAction)summary:(id)sender {
  [imageView setHidden:NO];
  SummaryProductInfo *summaryProduct = [[SummaryProductInfo alloc]initWithNibName:@"SummaryProductInfo" bundle:nil];
  [APP_IPAD.analysisHome.navigationController pushViewController:summaryProduct animated:YES];
}

@end
