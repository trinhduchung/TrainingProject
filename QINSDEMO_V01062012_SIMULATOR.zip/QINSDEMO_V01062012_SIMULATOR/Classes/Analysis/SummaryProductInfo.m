//
//  SummaryProductInfo.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 3/20/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import "SummaryProductInfo.h"

@implementation SummaryProductInfo



@synthesize txtNextDate;
@synthesize selectedTextField;
@synthesize dateOver;
@synthesize popDateController;

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION     = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION     = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT    = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT   = 162;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    dateOver = [[DatePickerPopOver alloc] init];
    popDateController = [[UIPopoverController alloc] initWithContentViewController:dateOver];
    
    popDateController.popoverContentSize =  CGSizeMake(350, 250);
    dateOver.sender = self;   
    UIView* dummyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, 1)];    
    txtNextDate.inputView = dummyView;
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.selectedTextField = textField;
    
    CGRect frame = CGRectMake(txtNextDate.frame.origin.x+txtNextDate.bounds.size.width-45, 
                              txtNextDate.frame.origin.y-5+10, 
                              txtNextDate.frame.size.width, 
                              txtNextDate.frame.size.height);
 
    if ( [textField isEqual:txtNextDate ] ) 
    {
        [popDateController presentPopoverFromRect:frame  inView:self.view 
                         permittedArrowDirections:UIPopoverArrowDirectionRight animated:YES];
    } else {
    
    CGRect textFieldRect = [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect = [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator = midline - viewRect.origin.y - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator = (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION) * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait || orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
    
    }
    

    
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
return [ Utils textField:textField shouldChangeCharactersInRange:range replacementString:string currentTextFieldText: self.selectedTextField.text ];

}

- (void)getDataFromPopOver:(id)sender {
if ([sender isKindOfClass:[DatePickerPopOver class]]) {
    DatePickerPopOver* picker = (DatePickerPopOver*)sender;
    self.selectedTextField.text = [NSString stringWithFormat:@"%@", picker.returnData];
} 
[self dismissPopover];
}


- (void)dismissPopover {
[self.popDateController dismissPopoverAnimated:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
