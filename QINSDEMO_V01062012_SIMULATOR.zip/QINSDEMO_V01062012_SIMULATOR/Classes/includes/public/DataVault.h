/*
Copyright (c) Sybase, Inc. 2011 All rights reserved. 

In addition to the license terms set out in the Sybase License Agreement for 
the Sybase Unwired Platform ("Program"), the following additional or different 
rights and accompanying obligations and restrictions shall apply to the source 
code in this file ("Code"). Sybase grants you a limited, non-exclusive, 
non-transferable, revocable license to use, reproduce, and modify the Code 
solely for purposes of (i) maintaining the Code as reference material to better 
understand the operation of the Program, and (ii) development and testing of 
applications created in connection with your licensed use of the Program. 
The Code may not be transferred, sold, assigned, sublicensed or otherwise 
conveyed (whether by operation of law or otherwise) to another party without 
Sybase's prior written consent. The following provisions shall apply to any 
modifications you make to the Code: (i) Sybase will not provide any maintenance 
or support for modified Code or problems that result from use of modified Code; 
(ii) Sybase expressly disclaims any warranties and conditions, express or 
implied, relating to modified Code or any problems that result from use of the 
modified Code; (iii) SYBASE SHALL NOT BE LIABLE FOR ANY LOSS OR DAMAGE RELATING 
TO MODIFICATIONS MADE TO THE CODE OR FOR ANY DAMAGES RESULTING FROM USE OF THE 
MODIFIED CODE, INCLUDING, WITHOUT LIMITATION, ANY INACCURACY OF DATA, LOSS OF 
PROFITS OR DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES, EVEN 
IF SYBASE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES; (iv) you agree 
to indemnify, hold harmless, and defend Sybase from and against any claims or 
lawsuits, including attorney's fees, that arise from or are related to the 
modified Code or from use of the modified Code.
*/

//
//  DataVault.h
//
//  Class to store given data in a secure manner
//  An application can choose to store multiple data withing the vault
//  Each data can be accessed by a name (like storing DB encryption Key and X.509 certificate etc.
//  The vault is accessed by unique vaultId
//  DataVault is unlocked by a Password

#ifndef __DATAVAULT_H__
#define __DATAVAULT_H__

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// ID of the standard messaging data vault
// Messaging vault must be unlocked before calling startEngine which will use the key from this vault to decrypt the messaging queue database
extern NSString * const kMessagingDataVaultID;

// Standard password and salt used in "No" security mode
extern NSString * const kDVStandardPassword;
extern NSString * const kDVStandardSalt;

// Use this constant for 'retryLimit' if unlimited failure attempts can be allowed during unlock
#define kDVUnlimitedRetriesAllowed   0

// Use this constant for 'lockTimeout' if application requires user to enter PIN everytime the app is launched
#define kDVNoLockTimeout             0

// Name of the exception thrown for DataVault errors
extern NSString * const DataVaultExceptionName;

// Reasons for exception thrown
extern NSString * const kDataVaultExceptionReasonLocked;
extern NSString * const kDataVaultExceptionReasonInvalidPassword;
extern NSString * const kDataVaultExceptionReasonInvalidArg;
extern NSString * const kDataVaultExceptionReasonAlreadyExists;
extern NSString * const kDataVaultExceptionReasonDoesNotExist;


@interface DataVault : NSObject {
   NSString * vaultId;
   NSData * passwordHash;               
   NSData * standardPasswordHash;       

   BOOL lockTimeoutFeatureEnabled;
}

//
// Public instance methods supported by this class
//

// Class method specific for iPhone implementation
// This method must be called before accessing any DataVault methods
// Access group must be set only if DataVault must be shared by more than one application
// If the DataVault is used only by one application access group should not be set
// This access group in keychain-access-groups property of entitlements plist file is usually in format "<BundleSeedID>.com.yourcompany.DataVault"
+ (void)setAccessGroup:(NSString *)accessGroup;

// Creates a new vault and returns it with unlocked state
// If a vault already exists with same name this will throw exception with kDataVaultExceptionReasonAlreadyExists as reason
+ (DataVault*)createVault:(NSString *)dataVaultID password:(NSString *)aPassword salt:(NSString *)aSalt;

// Returns vault with given ID. This vault is in locked state
// Throws an exception if a vault does not exist with given ID (kDataVaultExceptionReasonDoesNotExist)
+ (DataVault*)getVault:(NSString *)dataVaultID;

// Returns YES if a vault with given ID exists
+ (BOOL)vaultExists:(NSString *)dataVaultID;

// Deletes vault with given ID
// Throws an exception if a vault does not exist with given ID (kDataVaultExceptionReasonDoesNotExist)
+ (void)deleteVault:(NSString *)dataVaultID;

// Unlocks the vault with given password
// Should be called before accessing the data stored in the vault
// Throws exception with kDataVaultExceptionReasonInvalidPassword as reason if password given is incorrect
- (void)unlock:(NSString *)curPassword salt:(NSString *)curSalt;

// Locks the vault
// If the vault is already locked calling this method has no effect
- (void)lock;

// Indicates if the vault is currently locked
// Returns YES if vault is locked and NO if vault is unlocked
- (BOOL)isLocked;

// Changes the password of vault
// The vault must be unlocked before changing the password
// Throws exception (with reason kDataVaultExceptionReasonInvalidArg) if newPassword is empty or nil
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (void)changePassword:(NSString *)newPassword salt:(NSString *)newSalt;

// Get the data value for given name
// Throws exception (with reason kDataVaultExceptionReasonInvalidArg) if data with given name does not exist in the vault
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (NSData *)getValue:(NSString *)name;

// Set the data value for given name
// Throws exception (with reason kDataVaultExceptionReasonInvalidArg) if data with given name does not exist in the vault
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (void)setValue:(NSString *)name value:(NSData *)data;

// Get the string form of data value for given name
// Throws exception (with reason kDataVaultExceptionReasonInvalidArg) if data with given name does not exist in the vault
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
// Throws exception (with reason kDataVaultExceptionReasonConversionError) if unable to convert the data to string
- (NSString *)getString:(NSString *)name;

// Set the string form of data value for given name
// Throws exception (with reason kDataVaultExceptionReasonInvalidArg) if data with given name does not exist in the vault
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
// Throws exception (with reason kDataVaultExceptionReasonConversionError) if unable to convert the data from string
- (void)setString:(NSString *)name value:(NSString *)strData;

// Get the lock timeout value
// kDVNoLockTimeout is returned if no lock timeout is specified
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (NSInteger)getLockTimeout;

// Set the lock timeout value
// kDVNoLockTimeout can be passed to remove any existing lock timeout
// Throws exception (with reason kDataVaultExceptionReasonInvalidArg) if invalid timeout (like negative) value is passed
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (void)setLockTimeout:(NSInteger)timeout;

// Resets the lock timeout effectively extending the timeout period from now
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (void)resetLockTimeout;

// Get retry limit value
// kDVUnlimitedRetriesAllowed indicates unlimited retries are allowed
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (NSInteger)getRetryLimit;

// Set the retry limit value
// kDVUnlimitedRetriesAllowed can be passed to remove any existing retry limits
// Throws exception (with reason kDataVaultExceptionReasonInvalidArg) if invalid retry limit (like negative) value is passed
// Throws exception (with reason kDataVaultExceptionReasonLocked) if vault is locked
- (void)setRetryLimit:(NSInteger)retryLimitValue;

@end


@interface DataVaultException : NSException {

}
- (id)initWithReason: (NSString *)reason;

@end

#endif // __DATAVAULT_H__
