/*
Copyright (c) Sybase, Inc. 2010 All rights reserved. 

In addition to the license terms set out in the Sybase License Agreement for 
the Sybase Unwired Platform ("Program"), the following additional or different 
rights and accompanying obligations and restrictions shall apply to the source 
code in this file ("Code"). Sybase grants you a limited, non-exclusive, 
non-transferable, revocable license to use, reproduce, and modify the Code 
solely for purposes of (i) maintaining the Code as reference material to better 
understand the operation of the Program, and (ii) development and testing of 
applications created in connection with your licensed use of the Program. 
The Code may not be transferred, sold, assigned, sublicensed or otherwise 
conveyed (whether by operation of law or otherwise) to another party without 
Sybase's prior written consent. The following provisions shall apply to any 
modifications you make to the Code: (i) Sybase will not provide any maintenance 
or support for modified Code or problems that result from use of modified Code; 
(ii) Sybase expressly disclaims any warranties and conditions, express or 
implied, relating to modified Code or any problems that result from use of the 
modified Code; (iii) SYBASE SHALL NOT BE LIABLE FOR ANY LOSS OR DAMAGE RELATING 
TO MODIFICATIONS MADE TO THE CODE OR FOR ANY DAMAGES RESULTING FROM USE OF THE 
MODIFIED CODE, INCLUDING, WITHOUT LIMITATION, ANY INACCURACY OF DATA, LOSS OF 
PROFITS OR DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES, EVEN 
IF SYBASE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES; (iv) you agree 
to indemnify, hold harmless, and defend Sybase from and against any claims or 
lawsuits, including attorney's fees, that arise from or are related to the 
modified Code or from use of the modified Code.
*/

//
//  SSOCertManager.h
//
//  Class to enumerate list of all certificates available and certificate picker UI

#ifndef __SSOCERTMANAGER_H__
#define __SSOCERTMANAGER_H__

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// Properties of a certificate info
@interface SSOCertInfo : NSObject {
   NSString * subject;              // In iPhone, this contains just the common name stored in the subject
   NSString * subjectCN;            // Common name stored in the subject (part of distinguished name)
   NSString * issuer;               // Issuer of the certificate in DN format. This is not available in iPhone.
   NSDate   * notBefore;            // Begin timestamp for validity of the certificate. This is not available in iPhone.
   NSDate   * notAfter;             // End timestamp for validaity of the certificate. This is not available in iPhone.
   NSString * certID;               // platform-specific ID usable for finding the certificate again. This is not available in iPhone.
   NSString * displayName;          // Display name of the certificate. Summary of the certificate (usually the common name) is passed in this.
}

- (id)init;
- (id)initWithCertInfo:(NSString *)aSubject subjectCN:(NSString *)aSubjectCN issuer:(NSString *)aIssuer notBeforeDate:(NSDate *)dtNotBefore notAfterDate:(NSDate *)dtNotAfter certID:(NSString *)aCertID displayName:(NSString *)aDispName;

@property(nonatomic, retain)NSString * subject;
@property(nonatomic, retain)NSString * subjectCN;
@property(nonatomic, retain)NSString * issuer;
@property(nonatomic, retain)NSDate * notBefore;
@property(nonatomic, retain)NSDate * notAfter;
@property(nonatomic, retain)NSString * certID;
@property(nonatomic, retain)NSString * displayName;

@end


// Delegate that would be called by SSOCertPickerController when user selects a certificate or cancels the controller
@protocol SSOCertPickerDelegate
// Called when done button is pressed by user in SSOCertPickerController
// Selected certificate is passed to caller
- (void)doneSSOCertPicker:(SSOCertInfo *)selCertInfo withCertBlob:(NSData *)selCertBlob;

// Called when user canceled SSOCertPickerController
- (void)canceledSSOCertPicker;
@end

// Name of the exception thrown for SSOCertManager errors
extern NSString * const SSOCertManagerExceptionName;

// Reasons for exception thrown
extern NSString * const kSSOCertManagerExceptionPasswordRequired;
extern NSString * const kSSOCertManagerExceptionInvalidPassword;
extern NSString * const kSSOCertManagerExceptionInvalidArg;
extern NSString * const kSSOCertManagerExceptionParseError;
extern NSString * const kSSOCertManagerExceptionDoesNotExist;
extern NSString * const kSSOCertManagerExceptionNotSupported;
extern NSString * const kSSOCertManagerExceptionServerNotAvailable;


@interface SSOCertManager : NSObject {

}

//
// Public class methods supported by this class
//

// Fetches the necessary certificate and private key from certificate in the server, constructs a CertBLOB and returns it
// sServerUsername and sServerPassword will be used by server to impersonate the user before returning the certificate
// If valid oCertInfo is passed, it will be filled with relevant certificate information. If nil is passed this parameter will be ignored
// Returns CertBLOB for the certificate that can be used for certificate authentication
+ (NSData *)importCertBlobFromServer:(NSString *)sServerUsername serverPassword:(NSString *)sServerPassword certPassword:(NSString *)sCertPassword certInfo:(SSOCertInfo*)oCertInfo;

// Fetches the necessary certificate and private key from certificate in file system, constructs a CertBLOB and returns it
// If valid oCertInfo is passed, it will be filled with relevant certificate information. If nil is passed this parameter will be ignored
// sFilePath is absolute file path (as supplied to NSData initWithContentsOfFile)
// Returns CertBLOB for the certificate that can be used for certificate authentication
+ (NSData *)importCertBlobFromFile:(NSString *)sFilePath withPassword:(NSString *)sPassword certInfo:(SSOCertInfo*)oCertInfo;

// Fetches the necessary certificate and private key from certificate in application keychain, constructs a CertBLOB and returns it
// If valid oCertInfo is passed, it will be filled with relevant certificate information. If nil is passed this parameter will be ignored
// Returns CertBLOB for the certificate
+ (NSData *)importCertBlobFromStore:(NSString *)sKeychainItemID withPassword:(NSString *)sPassword certInfo:(SSOCertInfo*)oCertInfo;


// Following APIs are not implemented for iPhone
// These APIs throw kSSOCertManagerExceptionNotSupported exception

// Retrieves a list of full path names for the certificate files found in the file system for import.
// The folder from which to retrieve the certificate files and the file extensions are passed.
// Returns array of certificate filenames
+ (NSArray *)listAvailableCertificatesFromFileSystem:(NSString *)sFolder forExtension:(NSString *)sFileExtension;

// Parse the certificate in given file and returns the SSOCertInfo structure
// If necessary (based on search options provided) will fetch the certficate file from server
// Returns the SSOCertInfo object for given certificate 
+ (SSOCertInfo *)getCertInfoFromFile:(NSString *)sFilePath withPassword:(NSString *)sPassword;

// Retrieves a list of header information for the certificates available in the system store for import.
// The retieved list can be filtered by subject of the certificate or issuer of certificate
// Returns array of SSOCertInfo objects
+ (NSArray *)listAvailableCertificatesFromStore:(NSString *)sFilterSubject filterByIssuer:(NSString *)sFilterIssuer;

// Opens certificate picker controller that populates all the certificates from given folder allows user to select a certificate
// folder - Folder to populate the certificates from
// fileExtension - File extension of certificate files to consider
// searchMode - Search in local or server or both. Refer to CERT_SEARCH constants defined above
// viewController - Parent controller. Push this controller into stack of navigation controller defined in this
// delegate - SSOCertPickerDelegate implementation. Called when user presses done or cancel button in CertPicket controller
+ (void)openCertPicker:(NSString *)folder
                     forExtension:(NSString *)fileExtension
                     searchIn:(NSInteger)searchMode
                     withTitle:(NSString *)titleStr
                     fromController:(UIViewController*)viewController
                     delegate:(id <SSOCertPickerDelegate>)delegate;

@end

// Exception object thrown by SSOCertManager methods
@interface SSOCertManagerException : NSException {

}
- (id)initWithReason: (NSString *)reason;

@end


#endif // __SSOCERTMANAGER_H__
