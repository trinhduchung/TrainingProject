@interface SUPNull : NSObject
{
}
+ (SUPNull*)getInstance;
@end
