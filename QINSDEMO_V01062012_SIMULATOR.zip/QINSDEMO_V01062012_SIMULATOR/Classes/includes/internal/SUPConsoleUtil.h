// Copyright (c) 2009, Sybase Inc.

#import "sybase_sup.h"

@interface SUPConsoleUtil : NSObject
{
}

+ (void)print:(SUPString)string;

@end
