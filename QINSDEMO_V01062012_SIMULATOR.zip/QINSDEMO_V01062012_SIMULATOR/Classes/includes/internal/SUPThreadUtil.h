// Copyright (c) 2009, Sybase Inc.

#import "sybase_sup.h"

@interface SUPThreadUtil : NSObject
{
}

+ (void)sleep:(SUPLong)ms;

@end
