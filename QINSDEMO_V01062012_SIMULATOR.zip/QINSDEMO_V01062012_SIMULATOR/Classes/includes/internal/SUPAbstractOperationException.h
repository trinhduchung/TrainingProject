@interface SUPAbstractOperationException : NSException
{
}
+ (SUPAbstractOperationException*)getInstance;
@end
