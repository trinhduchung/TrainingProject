@interface SUPNullPointerException : NSException
{
}
+ (SUPNullPointerException*)getInstance;
@end
