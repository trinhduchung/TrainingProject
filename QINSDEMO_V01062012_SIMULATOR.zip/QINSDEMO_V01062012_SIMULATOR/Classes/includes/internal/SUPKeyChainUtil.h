
@interface SUPKeyChainUtil : NSObject {

}
/*!
    @function   getPassWithUser: andService: error:
    @abstract   get password from keychain with given username and serivcename.
    @discussion retrieve password from keychain.
    @param      NSString * username
                NSString * servicename, can use application name instead
                NSError ** error
    @result     successful, return password;
                if not found, return nil;
                otherwise, return nil and *error is set.
*/

+ (NSString *) getPassWithUser: (NSString *) username andService: (NSString *)servicename error: (NSError **) error;
/*!
    @function   storePassWithUser: andPassword: andService: updateExisting: error:
    @abstract   store password into the keychain, with given username, and servicename.
    @discussion update existing password or add new password into the keychain, with given username, and servicename 
    @param      NSString * username;
                NSString * password;
                NString * servicename, can use application name;
                BOOL updateExisting, YES - update the existing; NO - not update if old password exists;
                NSError ** error,  if there is an error, *error will be set.
          
    @result    none
*/

+ (void) storePassWithUser: (NSString *) username andPassword: (NSString *) password andService: (NSString *)servicename updateExisting: (BOOL) updateExisting error: (NSError **) error;

/*!
    @function   deletePassWithUser: andService: error:
    @abstract   delete password from keychain
    @discussion delete the password from keychain with the given username, and service name.
    @param      NSString * username
                NSString * servicename, can use application name instead.
                NSError ** error, if there is an error, *error will be set.
    @result     none.
*/

+ (void) deletePassWithUser: (NSString *) username andService: (NSString *)servicename error: (NSError **) error;
/*!
 @function   getKeyWithUser: error:
 @abstract   get key from keychain with given username.
 @discussion retrieve key from keychain.
 @param      NSString * username
 NSError ** error
 @result     successful, return key;
 if not found, return nil;
 otherwise, return nil and *error is set.
 */

+ (NSString *) getKeyWithUser: (NSString *) username error: (NSError **) error;
/*!
 @function   storeKeyWithUser: andKey: error:
 @abstract   store key into the keychain, with given username.
 @discussion update existing key or add new key into the keychain, with given username 
 @param      NSString * username;
 NSString * key;
 NSError ** error,  if there is an error, *error will be set.
 
 @result    none
 */

+ (void) storeKeyWithUser: (NSString *) username andKey: (NSString *) key error: (NSError **) error;

/*!
 @function   deleteKeyWithUser: error:
 @abstract   delete key from keychain
 @discussion delete the key from keychain with the given username.
 @param      NSString * username
 NSError ** error, if there is an error, *error will be set.
 @result     none.
 */

+ (void) deleteKeyWithUser: (NSString *) username error: (NSError **) error;

@end
