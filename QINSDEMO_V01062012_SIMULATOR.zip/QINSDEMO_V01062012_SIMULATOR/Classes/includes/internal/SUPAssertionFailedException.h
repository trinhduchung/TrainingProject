@interface SUPAssertionFailedException : NSException
{
}
+ (SUPAssertionFailedException*)getInstance;
@end
