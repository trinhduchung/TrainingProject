//
//  DatePickerAlert.h
//  EB
//
//  Created by iMac 20 on 12/22/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DatePickerDelegate;

@interface DatePickerAlert : UIActionSheet {
	UIDatePicker *picker;
	BOOL layoutDone;
	id <DatePickerDelegate> pickerDelegate;
}

@property (nonatomic, retain) UIDatePicker *picker;
@property (nonatomic, retain) id pickerDelegate;
- (void)dateChanged;

@end
@protocol DatePickerDelegate <NSObject>
// transaction = nil on cancel
- (void)datePickerAlert:(DatePickerAlert *)datePickerAlert didPickDate:(NSString *)date;

@end