  //
  //  MGSplitViewController.m
  //  MGSplitView
  //
  //  Created by Matt Gemmell on 26/07/2010.
  //  Copyright 2010 Instinctive Code.
  //

#import "MGSplitViewController.h"
#import "MGSplitDividerView.h"
#import "MGSplitCornersView.h"

#define MG_DEFAULT_SPLIT_POSITION		320.0	// default width of master view in UISplitViewController.
#define MG_DEFAULT_SPLIT_WIDTH			1.0		// default width of split-gutter in UISplitViewController.
#define MG_DEFAULT_CORNER_RADIUS		5.0		// default corner-radius of overlapping split-inner corners on the master and detail views.
#define MG_DEFAULT_CORNER_COLOR			[UIColor blackColor]	// default color of intruding inner corners (and divider background).

#define MG_PANESPLITTER_CORNER_RADIUS	0.0		// corner-radius of split-inner corners for MGSplitViewDividerStylePaneSplitter style.
#define MG_PANESPLITTER_SPLIT_WIDTH		25.0	// width of split-gutter for MGSplitViewDividerStylePaneSplitter style.

#define MG_MIN_VIEW_WIDTH				200.0	// minimum width a view is allowed to become as a result of changing the splitPosition.

#define MG_ANIMATION_CHANGE_SPLIT_ORIENTATION	@"ChangeSplitOrientation"	// Animation ID for internal use.
#define MG_ANIMATION_CHANGE_SUBVIEWS_ORDER		@"ChangeSubviewsOrder"	// Animation ID for internal use.


@interface MGSplitViewController (MGPrivateMethods)

- (void)setup;
- (CGSize)splitViewSizeForOrientation:(UIInterfaceOrientation)theOrientation;
- (void)layoutSubviews;
- (void)layoutSubviewsWithAnimation:(BOOL)animate;
- (void)layoutSubviewsForInterfaceOrientation:(UIInterfaceOrientation)theOrientation 
                                withAnimation:(BOOL)animate;
- (BOOL)shouldShowMasterForInterfaceOrientation:(UIInterfaceOrientation)theOrientation;
- (BOOL)shouldShowMaster;
- (NSString *)nameOfInterfaceOrientation:(UIInterfaceOrientation)theOrientation;
- (void)reconfigureForMasterInPopover:(BOOL)inPopover;

@end


@implementation MGSplitViewController
@synthesize visible;
@synthesize reconfigurePopup;

#pragma mark -
#pragma mark Orientation helpers


- (NSString *)nameOfInterfaceOrientation:(UIInterfaceOrientation)theOrientation {
	NSString *orientationName = nil;
	switch (theOrientation) {
		case UIInterfaceOrientationPortrait:
			orientationName = @"Portrait"; // Home button at bottom
			break;
		case UIInterfaceOrientationPortraitUpsideDown:
			orientationName = @"Portrait (Upside Down)"; // Home button at top
			break;
		case UIInterfaceOrientationLandscapeLeft:
			orientationName = @"Landscape (Left)"; // Home button on left
			break;
		case UIInterfaceOrientationLandscapeRight:
			orientationName = @"Landscape (Right)"; // Home button on right
			break;
		default:
			break;
	}
	
	return orientationName;
}


- (BOOL)isLandscape {
	return UIInterfaceOrientationIsLandscape(self.interfaceOrientation);
}


- (BOOL)shouldShowMasterForInterfaceOrientation:(UIInterfaceOrientation)theOrientation {
    // Returns YES if master view should be shown directly embedded in the splitview, instead of hidden in a popover.
	return ((UIInterfaceOrientationIsLandscape(theOrientation)) ? showsMasterInLandscape : showsMasterInPortrait);
}


- (BOOL)shouldShowMaster {
	return [self shouldShowMasterForInterfaceOrientation:self.interfaceOrientation];
}


- (BOOL)isShowingMaster {
	return [self shouldShowMaster] 
    && self.masterViewController 
    && self.masterViewController.view 
    && ([self.masterViewController.view superview] == self.view);
}


#pragma mark -
#pragma mark Setup and Teardown


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
		[self setup];
	}
	
	return self;
}


- (id)initWithCoder:(NSCoder *)aDecoder {
	if ((self = [super initWithCoder:aDecoder])) {
		[self setup];
	}
	
	return self;
}


- (void)setup {
    // Configure default behaviour.
  visible = NO;
	viewControllers = [[NSMutableArray alloc] initWithObjects:[NSNull null], [NSNull null], nil];
	splitWidth = MG_DEFAULT_SPLIT_WIDTH;
	showsMasterInPortrait = NO;
	showsMasterInLandscape = YES;
	reconfigurePopup = NO;
	vertical = YES;
	masterBeforeDetail = YES;
	splitPosition = MG_DEFAULT_SPLIT_POSITION;
	CGRect divRect = self.view.bounds;
	if ([self isVertical]) {
		divRect.origin.y = splitPosition;
		divRect.size.height = splitWidth;
	} else {
		divRect.origin.x = splitPosition;
		divRect.size.width = splitWidth;
	}
	dividerView = [[MGSplitDividerView alloc] initWithFrame:divRect];
	dividerView.splitViewController = self;
	dividerView.backgroundColor = MG_DEFAULT_CORNER_COLOR;
	dividerStyle = MGSplitViewDividerStyleThin;
}


- (void)dealloc {
	delegate = nil;
	[self.view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
	[viewControllers release];
	[barButtonItem release];
	[hiddenPopoverController release];
	[dividerView release];
	[cornerViews release];
	
	[super dealloc];
}


#pragma mark -
#pragma mark View management


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
  return ((interfaceOrientation == UIInterfaceOrientationLandscapeLeft) 
            || (interfaceOrientation == UIInterfaceOrientationLandscapeRight));
  
}


- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
                                duration:(NSTimeInterval)duration {
	[self.masterViewController willRotateToInterfaceOrientation:toInterfaceOrientation 
                                                     duration:duration];
	[self.detailViewController willRotateToInterfaceOrientation:toInterfaceOrientation 
                                                     duration:duration];
}


- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
	[self.masterViewController didRotateFromInterfaceOrientation:fromInterfaceOrientation];
	[self.detailViewController didRotateFromInterfaceOrientation:fromInterfaceOrientation];
}


- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation 
                                         duration:(NSTimeInterval)duration {
	[self.masterViewController willAnimateRotationToInterfaceOrientation:toInterfaceOrientation 
                                                              duration:duration];
	[self.detailViewController willAnimateRotationToInterfaceOrientation:toInterfaceOrientation 
                                                              duration:duration];
	
    // Hide popover.
	if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
		[hiddenPopoverController dismissPopoverAnimated:NO];
	}
	
    // Re-tile views.
	reconfigurePopup = YES;
	[self layoutSubviewsForInterfaceOrientation:toInterfaceOrientation 
                                withAnimation:YES];
}


- (void)willAnimateFirstHalfOfRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation 
                                                    duration:(NSTimeInterval)duration {
	[self.masterViewController willAnimateFirstHalfOfRotationToInterfaceOrientation:toInterfaceOrientation 
                                                                         duration:duration];
	[self.detailViewController willAnimateFirstHalfOfRotationToInterfaceOrientation:toInterfaceOrientation 
                                                                         duration:duration];
}


- (void)didAnimateFirstHalfOfRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	[self.masterViewController didAnimateFirstHalfOfRotationToInterfaceOrientation:toInterfaceOrientation];
	[self.detailViewController didAnimateFirstHalfOfRotationToInterfaceOrientation:toInterfaceOrientation];
}


- (void)willAnimateSecondHalfOfRotationFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation 
                                                       duration:(NSTimeInterval)duration {
	[self.masterViewController willAnimateSecondHalfOfRotationFromInterfaceOrientation:fromInterfaceOrientation 
                                                                            duration:duration];
	[self.detailViewController willAnimateSecondHalfOfRotationFromInterfaceOrientation:fromInterfaceOrientation 
                                                                            duration:duration];
}


- (CGSize)splitViewSizeForOrientation:(UIInterfaceOrientation)theOrientation {
	UIScreen *screen = [UIScreen mainScreen];
	CGRect fullScreenRect = screen.bounds; // always implicitly in Portrait orientation.
	CGRect appFrame = screen.applicationFrame;
	
    // Find status bar height by checking which dimension of the applicationFrame is narrower than screen bounds.
    // Little bit ugly looking, but it'll still work even if they change the status bar height in future.
	float statusBarHeight = MAX((fullScreenRect.size.width - appFrame.size.width), 
                                (fullScreenRect.size.height - appFrame.size.height));
	
    // Initially assume portrait orientation.
	float width = fullScreenRect.size.width;
	float height = fullScreenRect.size.height;
	
    // Correct for orientation.
	if (UIInterfaceOrientationIsLandscape(theOrientation)) {
		width = height;
		height = fullScreenRect.size.width;
	}
	
    // Account for status bar, which always subtracts from the height (since it's always at the top of the screen).
	height -= statusBarHeight;
	
	return CGSizeMake(width, height);
}


- (void)layoutSubviewsForInterfaceOrientation:(UIInterfaceOrientation)theOrientation 
                                withAnimation:(BOOL)animate {
	if (reconfigurePopup) {
		[self reconfigureForMasterInPopover:![self shouldShowMasterForInterfaceOrientation:theOrientation]];
	}
	
    // Layout the master, detail and divider views appropriately, adding/removing subviews as needed.
    // First obtain relevant geometry.
	CGSize fullSize = [self splitViewSizeForOrientation:theOrientation];
	float width = fullSize.width;
	float height = fullSize.height;
	
	if (NO) { // Just for debugging.
		NSLog(@"Target orientation is %@, dimensions will be %.0f x %.0f", 
          [self nameOfInterfaceOrientation:theOrientation], width, height);
	}
	
    // Layout the master, divider and detail views.
	CGRect newFrame = CGRectMake(0, 0, width, height);
	UIViewController *controller;
	UIView *theView;
	BOOL shouldShowMaster = [self shouldShowMasterForInterfaceOrientation:theOrientation];
	BOOL masterFirst = [self isMasterBeforeDetail];
	if ([self isVertical]) {
      // Master on left, detail on right (or vice versa).
		CGRect masterRect, dividerRect, detailRect;
		if (masterFirst) {
			if (!shouldShowMaster) {
          // Move off-screen.
				newFrame.origin.x -= (splitPosition + splitWidth);
			}
			
			newFrame.size.width = splitPosition;
			masterRect = newFrame;
			
			newFrame.origin.x += newFrame.size.width;
			newFrame.size.width = splitWidth;
			dividerRect = newFrame;
			
			newFrame.origin.x += newFrame.size.width;
			newFrame.size.width = width - newFrame.origin.x;
			detailRect = newFrame;
			
		} else {
			if (!shouldShowMaster) {
          // Move off-screen.
				newFrame.size.width += (splitPosition + splitWidth);
			}
			
			newFrame.size.width -= (splitPosition + splitWidth);
			detailRect = newFrame;
			
			newFrame.origin.x += newFrame.size.width;
			newFrame.size.width = splitWidth;
			dividerRect = newFrame;
			
			newFrame.origin.x += newFrame.size.width;
			newFrame.size.width = splitPosition;
			masterRect = newFrame;
		}
		
      // Position master.
		controller = self.masterViewController;
		if (controller && [controller isKindOfClass:[UIViewController class]])  {
			theView = controller.view;
			if (theView) {
				theView.frame = masterRect;
				if (!theView.superview) {
					[controller viewWillAppear:NO];
					[self.view addSubview:theView];
					[controller viewDidAppear:NO];
				}
			}
		}
		
      // Position divider.
		theView = dividerView;
		theView.frame = dividerRect;
		if (!theView.superview) {
			[self.view addSubview:theView];
		}
		
      // Position detail.
		controller = self.detailViewController;
		if (controller && [controller isKindOfClass:[UIViewController class]])  {
			theView = controller.view;
			if (theView) {
				theView.frame = detailRect;
				if (!theView.superview) {
					[self.view insertSubview:theView aboveSubview:self.masterViewController.view];
				} else {
					[self.view bringSubviewToFront:theView];
				}
			}
		}
		
	} else {
      // Master above, detail below (or vice versa).
		CGRect masterRect, dividerRect, detailRect;
		if (masterFirst) {
			if (!shouldShowMaster) {
          // Move off-screen.
				newFrame.origin.y -= (splitPosition + splitWidth);
			}
			
			newFrame.size.height = splitPosition;
			masterRect = newFrame;
			
			newFrame.origin.y += newFrame.size.height;
			newFrame.size.height = splitWidth;
			dividerRect = newFrame;
			
			newFrame.origin.y += newFrame.size.height;
			newFrame.size.height = height - newFrame.origin.y;
			detailRect = newFrame;
			
		} else {
			if (!shouldShowMaster) {
          // Move off-screen.
				newFrame.size.height += (splitPosition + splitWidth);
			}
			
			newFrame.size.height -= (splitPosition + splitWidth);
			detailRect = newFrame;
			
			newFrame.origin.y += newFrame.size.height;
			newFrame.size.height = splitWidth;
			dividerRect = newFrame;
			
			newFrame.origin.y += newFrame.size.height;
			newFrame.size.height = splitPosition;
			masterRect = newFrame;
		}
		
      // Position master.
		controller = self.masterViewController;
		if (controller && [controller isKindOfClass:[UIViewController class]])  {
			theView = controller.view;
			if (theView) {
				theView.frame = masterRect;
				if (!theView.superview) {
					[controller viewWillAppear:NO];
					[self.view addSubview:theView];
					[controller viewDidAppear:NO];
				}
			}
		}
		
      // Position divider.
		theView = dividerView;
		theView.frame = dividerRect;
		if (!theView.superview) {
			[self.view addSubview:theView];
		}
		
      // Position detail.
		controller = self.detailViewController;
		if (controller && [controller isKindOfClass:[UIViewController class]])  {
			theView = controller.view;
			if (theView) {
				theView.frame = detailRect;
				if (!theView.superview) {
					[self.view insertSubview:theView aboveSubview:self.masterViewController.view];
				} else {
					[self.view bringSubviewToFront:theView];
				}
			}
		}
	}
	
    // Create corner views if necessary.
	MGSplitCornersView *leadingCorners; // top/left of screen in vertical/horizontal split.
	MGSplitCornersView *trailingCorners; // bottom/right of screen in vertical/horizontal split.
	if (!cornerViews) {
		CGRect cornerRect = CGRectMake(0, 0, 10, 10); // arbitrary, will be resized below.
		leadingCorners = [[MGSplitCornersView alloc] initWithFrame:cornerRect];
		leadingCorners.splitViewController = self;
		leadingCorners.cornerBackgroundColor = MG_DEFAULT_CORNER_COLOR;
		leadingCorners.cornerRadius = MG_DEFAULT_CORNER_RADIUS;
		trailingCorners = [[MGSplitCornersView alloc] initWithFrame:cornerRect];
		trailingCorners.splitViewController = self;
		trailingCorners.cornerBackgroundColor = MG_DEFAULT_CORNER_COLOR;
		trailingCorners.cornerRadius = MG_DEFAULT_CORNER_RADIUS;
		cornerViews = [[NSArray alloc] initWithObjects:leadingCorners, trailingCorners, nil];
		[leadingCorners release];
		[trailingCorners release];
		
	} else if ([cornerViews count] == 2) {
		leadingCorners = [cornerViews objectAtIndex:0];
		trailingCorners = [cornerViews objectAtIndex:1];
	}
	
    // Configure and layout the corner-views.
  if (vertical) {
    leadingCorners.cornersPosition = MGCornersPositionLeadingVertical;
    trailingCorners.cornersPosition = MGCornersPositionTrailingVertical;
    leadingCorners.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin;
    trailingCorners.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
  } else {
    leadingCorners.cornersPosition = MGCornersPositionLeadingHorizontal;
    trailingCorners.cornersPosition = MGCornersPositionTrailingHorizontal;
    leadingCorners.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    trailingCorners.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
  }
	
	float x, y, cornersWidth, cornersHeight;
	CGRect leadingRect, trailingRect;
	float radius = leadingCorners.cornerRadius;
	if (vertical) { // left/right split
		cornersWidth = (radius * 2.0) + splitWidth;
		cornersHeight = radius;
    x = 0;
    if (shouldShowMaster) {
      if (masterFirst) {
        x = splitPosition;
      } else {
        x = width - (splitPosition + splitWidth);
      }
    } else {
      x = (0 - splitWidth);
    }
    x = x - radius;
		y = 0;
		leadingRect = CGRectMake(x, y, cornersWidth, cornersHeight); // top corners
		trailingRect = CGRectMake(x, (height - cornersHeight), cornersWidth, cornersHeight); // bottom corners
		
	} else { // top/bottom split
		x = 0;
    y = 0;
    if (shouldShowMaster) {
      if (masterFirst) {
        y = splitPosition;
      } else {
        y = height - (splitPosition + splitWidth);
      }
    } else {
      y = (0 - splitWidth);
    }
    y = y - radius;
		cornersWidth = radius;
		cornersHeight = (radius * 2.0) + splitWidth;
		leadingRect = CGRectMake(x, y, cornersWidth, cornersHeight); // left corners
		trailingRect = CGRectMake((width - cornersWidth), y, cornersWidth, cornersHeight); // right corners
	}
	
	leadingCorners.frame = leadingRect;
	trailingCorners.frame = trailingRect;
	
    // Ensure corners are visible and frontmost.
	if (!leadingCorners.superview) {
		[self.view insertSubview:leadingCorners aboveSubview:self.detailViewController.view];
		[self.view insertSubview:trailingCorners aboveSubview:self.detailViewController.view];
	} else {
		[self.view bringSubviewToFront:leadingCorners];
		[self.view bringSubviewToFront:trailingCorners];
	}
}


- (void)layoutSubviewsWithAnimation:(BOOL)animate {
	[self layoutSubviewsForInterfaceOrientation:self.interfaceOrientation 
                                withAnimation:animate];
}


- (void)layoutSubviews {
	[self layoutSubviewsForInterfaceOrientation:self.interfaceOrientation 
                                withAnimation:YES];
}


- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	visible = YES;
	if ([self isShowingMaster]) {
		[self.masterViewController viewWillAppear:animated];
	}
	[self.detailViewController viewWillAppear:animated];
	
	reconfigurePopup = YES;
	[self layoutSubviews];
}


- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	
	if ([self isShowingMaster]) {
		[self.masterViewController viewDidAppear:animated];
	}
	[self.detailViewController viewDidAppear:animated];
}


- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	visible = NO;
	if ([self isShowingMaster]) {
		[self.masterViewController viewWillDisappear:animated];
	}
	[self.detailViewController viewWillDisappear:animated];
}


- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	
	if ([self isShowingMaster]) {
		[self.masterViewController viewDidDisappear:animated];
	}
	[self.detailViewController viewDidDisappear:animated];
}


#pragma mark -
#pragma mark Popover handling


- (void)reconfigureForMasterInPopover:(BOOL)inPopover {
	reconfigurePopup = NO;
	
	if ((inPopover && hiddenPopoverController) 
        || (!inPopover && !hiddenPopoverController) 
        || !self.masterViewController) {
      // Nothing to do.
		return;
	}
	
	if (inPopover && !hiddenPopoverController && !barButtonItem) {
      // Create and configure popover for our masterViewController.
		[hiddenPopoverController release];
		hiddenPopoverController = nil;
		[self.masterViewController viewWillDisappear:NO];
		hiddenPopoverController = 
      [[UIPopoverController alloc] initWithContentViewController:self.masterViewController];
		[self.masterViewController viewDidDisappear:NO];
		
      // Create and configure _barButtonItem.
		barButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Master", nil) 
                                                     style:UIBarButtonItemStyleBordered 
                                                    target:self 
                                                    action:@selector(showMasterPopover:)];
		
      // Inform delegate of this state of affairs.
		if (delegate && [delegate respondsToSelector:@selector(splitViewController:
                                                            willHideViewController:
                                                            withBarButtonItem:
                                                            forPopoverController:)]) {
			[(NSObject <MGSplitViewControllerDelegate> *)delegate splitViewController:self 
                                                         willHideViewController:self.masterViewController 
                                                              withBarButtonItem:barButtonItem 
                                                           forPopoverController:hiddenPopoverController];
		}
		
	} else if (!inPopover && hiddenPopoverController && barButtonItem) {
      // I know this looks strange, but it fixes a bizarre issue with UIPopoverController leaving masterViewController's views in disarray.
		[hiddenPopoverController presentPopoverFromRect:CGRectZero 
                                             inView:self.view 
                           permittedArrowDirections:UIPopoverArrowDirectionAny 
                                           animated:NO];
		
      // Remove master from popover and destroy popover, if it exists.
		[hiddenPopoverController dismissPopoverAnimated:NO];
		[hiddenPopoverController release];
		hiddenPopoverController = nil;
		
      // Inform delegate that the _barButtonItem will become invalid.
		if (delegate && [delegate respondsToSelector:@selector(splitViewController:
                                                           willShowViewController:
                                                           invalidatingBarButtonItem:)]) {
			[(NSObject <MGSplitViewControllerDelegate> *)delegate splitViewController:self 
                                                         willShowViewController:self.masterViewController 
                                                      invalidatingBarButtonItem:barButtonItem];
		}
		
      // Destroy _barButtonItem.
		[barButtonItem release];
		barButtonItem = nil;
		
      // Move master view.
		UIView *masterView = self.masterViewController.view;
		if (masterView && masterView.superview != self.view) {
			[masterView removeFromSuperview];
		}
	}
}


- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
	[self reconfigureForMasterInPopover:NO];
}


- (void)notePopoverDismissed {
	[self popoverControllerDidDismissPopover:hiddenPopoverController];
}


#pragma mark -
#pragma mark Animations


- (void)animationDidStop:(NSString *)animationID 
                finished:(NSNumber *)finished 
                 context:(void *)context {
	if (([animationID isEqualToString:MG_ANIMATION_CHANGE_SPLIT_ORIENTATION] || 
       [animationID isEqualToString:MG_ANIMATION_CHANGE_SUBVIEWS_ORDER])
      && cornerViews) {
		for (UIView *corner in cornerViews) {
			corner.hidden = NO;
		}
		dividerView.hidden = NO;
	}
}


#pragma mark -
#pragma mark IB Actions


- (IBAction)toggleSplitOrientation:(id)sender {
	BOOL showingMaster = [self isShowingMaster];
	if (showingMaster) {
		if (cornerViews) {
			for (UIView *corner in cornerViews) {
				corner.hidden = YES;
			}
			dividerView.hidden = YES;
		}
		[UIView beginAnimations:MG_ANIMATION_CHANGE_SPLIT_ORIENTATION context:nil];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
	}
	self.vertical = (!self.vertical);
	if (showingMaster) {
		[UIView commitAnimations];
	}
}


- (IBAction)toggleMasterBeforeDetail:(id)sender {
	BOOL showingMaster = [self isShowingMaster];
	if (showingMaster) {
		if (cornerViews) {
			for (UIView *corner in cornerViews) {
				corner.hidden = YES;
			}
			dividerView.hidden = YES;
		}
		[UIView beginAnimations:MG_ANIMATION_CHANGE_SUBVIEWS_ORDER context:nil];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
	}
	self.masterBeforeDetail = (!self.masterBeforeDetail);
	if (showingMaster) {
		[UIView commitAnimations];
	}
}


- (IBAction)toggleMasterView:(id)sender {
	if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
		[hiddenPopoverController dismissPopoverAnimated:NO];
	}
	
	if (![self isShowingMaster]) {
      // We're about to show the master view. Ensure it's in place off-screen to be animated in.
		reconfigurePopup = YES;
		[self reconfigureForMasterInPopover:NO];
		[self layoutSubviews];
	}
	
    // This action functions on the current primary orientation; it is independent of the other primary orientation.
	[UIView beginAnimations:@"toggleMaster" context:nil];
	if (self.isLandscape) {
		self.showsMasterInLandscape = !showsMasterInLandscape;
	} else {
		self.showsMasterInPortrait = !showsMasterInPortrait;
	}
	[UIView commitAnimations];
}


- (IBAction)showMasterPopover:(id)sender {
	if (hiddenPopoverController && !(hiddenPopoverController.popoverVisible)) {
      // Inform delegate.
		if (delegate && [delegate respondsToSelector:@selector(splitViewController:
                                                           popoverController:
                                                           willPresentViewController:)]) {
			[(NSObject <MGSplitViewControllerDelegate> *)delegate splitViewController:self 
                                                              popoverController:hiddenPopoverController 
                                                      willPresentViewController:self.masterViewController];
		}
		
      // Show popover.
		[hiddenPopoverController presentPopoverFromBarButtonItem:barButtonItem 
                                    permittedArrowDirections:UIPopoverArrowDirectionAny 
                                                    animated:YES];
	}
}


#pragma mark -
#pragma mark Accessors and properties


- (id)delegate {
	return delegate;
}


- (void)setDelegate:(id <MGSplitViewControllerDelegate>)newDelegate {
	if (newDelegate != delegate && 
      (!newDelegate || [(NSObject *)newDelegate conformsToProtocol:@protocol(MGSplitViewControllerDelegate)])) {
		delegate = newDelegate;
	}
}


- (BOOL)showsMasterInPortrait {
	return showsMasterInPortrait;
}


- (void)setShowsMasterInPortrait:(BOOL)flag {
	if (flag != showsMasterInPortrait) {
		showsMasterInPortrait = flag;
		
		if (![self isLandscape]) { // i.e. if this will cause a visual change.
			if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
				[hiddenPopoverController dismissPopoverAnimated:NO];
			}
			
        // Rearrange views.
			reconfigurePopup = YES;
			[self layoutSubviews];
		}
	}
}


- (BOOL)showsMasterInLandscape {
	return showsMasterInLandscape;
}


- (void)setShowsMasterInLandscape:(BOOL)flag {
	if (flag != showsMasterInLandscape) {
		showsMasterInLandscape = flag;
		
		if ([self isLandscape]) { // i.e. if this will cause a visual change.
			if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
				[hiddenPopoverController dismissPopoverAnimated:NO];
			}
			
        // Rearrange views.
			reconfigurePopup = YES;
			[self layoutSubviews];
		}
	}
}


- (BOOL)isVertical {
	return vertical;
}


- (void)setVertical:(BOOL)flag {
	if (flag != vertical) {
		if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
			[hiddenPopoverController dismissPopoverAnimated:NO];
		}
		
		vertical = flag;
		
      // Inform delegate.
		if (delegate && [delegate respondsToSelector:@selector(splitViewController:
                                                           willChangeSplitOrientationToVertical:)]) {
			[delegate splitViewController:self willChangeSplitOrientationToVertical:vertical];
		}
		
		[self layoutSubviews];
	}
}


- (BOOL)isMasterBeforeDetail {
	return masterBeforeDetail;
}


- (void)setMasterBeforeDetail:(BOOL)flag {
	if (flag != masterBeforeDetail) {
		if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
			[hiddenPopoverController dismissPopoverAnimated:NO];
		}
		
		masterBeforeDetail = flag;
		
		if ([self isShowingMaster]) {
			[self layoutSubviews];
		}
	}
}


- (float)splitPosition {
	return splitPosition;
}


- (void)setSplitPosition:(float)posn {
    // Check to see if delegate wishes to constrain the position.
	float newPosn = posn;
	BOOL constrained = NO;
	CGSize fullSize = [self splitViewSizeForOrientation:self.interfaceOrientation];
	if (delegate && [delegate respondsToSelector:@selector(splitViewController:
                                                         constrainSplitPosition:
                                                         splitViewSize:)]) {
		newPosn = [delegate splitViewController:self 
                     constrainSplitPosition:newPosn 
                              splitViewSize:fullSize];
		constrained = YES; // implicitly trust delegate's response.
		
	} else {
      // Apply default constraints if delegate doesn't wish to participate.
		float minPos = MG_MIN_VIEW_WIDTH;
		float maxPos = ((vertical) 
                    ? fullSize.width 
                    : fullSize.height) - (MG_MIN_VIEW_WIDTH + splitWidth);
		constrained = (newPosn != splitPosition && newPosn >= minPos && newPosn <= maxPos);
	}
	
	if (constrained) {
		if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
			[hiddenPopoverController dismissPopoverAnimated:NO];
		}
		
		splitPosition = newPosn;
		
      // Inform delegate.
		if (delegate && [delegate respondsToSelector:@selector(splitViewController:willMoveSplitToPosition:)]) {
			[delegate splitViewController:self willMoveSplitToPosition:splitPosition];
		}
		
		if ([self isShowingMaster]) {
			[self layoutSubviews];
		}
	}
}


- (void)setSplitPosition:(float)posn animated:(BOOL)animate
{
	BOOL shouldAnimate = (animate && [self isShowingMaster]);
	if (shouldAnimate) {
		[UIView beginAnimations:@"SplitPosition" context:nil];
	}
	[self setSplitPosition:posn];
	if (shouldAnimate) {
		[UIView commitAnimations];
	}
}


- (float)splitWidth
{
	return splitWidth;
}


- (void)setSplitWidth:(float)width
{
	if (width != splitWidth && width >= 0) {
		splitWidth = width;
		if ([self isShowingMaster]) {
			[self layoutSubviews];
		}
	}
}


- (NSArray *)viewControllers
{
	return [[viewControllers copy] autorelease];
}


- (void)setViewControllers:(NSArray *)controllers
{
	if (controllers != viewControllers) {
		for (UIViewController *controller in viewControllers) {
			if ([controller isKindOfClass:[UIViewController class]]) {
				[controller.view removeFromSuperview];
			}
		}
		[viewControllers release];
		viewControllers = [[NSMutableArray alloc] initWithCapacity:2];
		if (controllers && [controllers count] >= 2) {
			self.masterViewController = [controllers objectAtIndex:0];
			self.detailViewController = [controllers objectAtIndex:1];
		} else {
			NSLog(@"Error: %@ requires 2 view-controllers. (%@)",
              NSStringFromClass([self class]), 
              NSStringFromSelector(_cmd));
		}
		
		[self layoutSubviews];
	}
}


- (UIViewController *)masterViewController {
	if (viewControllers && [viewControllers count] > 0) {
		NSObject *controller = [viewControllers objectAtIndex:0];
		if ([controller isKindOfClass:[UIViewController class]]) {
			return (UIViewController *)[[controller retain] autorelease];
		}
	}
	
	return nil;
}


- (void)setMasterViewController:(UIViewController *)master {
	if (!viewControllers) {
		viewControllers = [[NSMutableArray alloc] initWithCapacity:2];
	}
	
	NSObject *newMaster = master;
	if (!newMaster) {
		newMaster = [NSNull null];
	}
	
	BOOL changed = YES;
	if ([viewControllers count] > 0) {
		if ([viewControllers objectAtIndex:0] == newMaster) {
			changed = NO;
		} else {
			[viewControllers replaceObjectAtIndex:0 withObject:newMaster];
		}
		
	} else {
		[viewControllers addObject:newMaster];
	}
	
	if (changed) {
		[self layoutSubviews];
	}
}


- (UIViewController *)detailViewController {
	if (viewControllers && [viewControllers count] > 1) {
		NSObject *controller = [viewControllers objectAtIndex:1];
		if ([controller isKindOfClass:[UIViewController class]]) {
			return (UIViewController *)[[controller retain] autorelease];
		}
	}
	
	return nil;
}


- (void)setDetailViewController:(UIViewController *)detail {
	if (!viewControllers) {
		viewControllers = [[NSMutableArray alloc] initWithCapacity:2];
		[viewControllers addObject:[NSNull null]];
	}
	
	BOOL changed = YES;
	if ([viewControllers count] > 1) {
		if ([viewControllers objectAtIndex:1] == detail) {
			changed = NO;
		} else {
			[viewControllers replaceObjectAtIndex:1 withObject:detail];
		}
		
	} else {
		[viewControllers addObject:detail];
	}
	
	if (changed) {
		[self layoutSubviews];
	}
}


- (MGSplitDividerView *)dividerView {
	return [[dividerView retain] autorelease];
}


- (void)setDividerView:(MGSplitDividerView *)divider {
	if (divider != dividerView) {
		[dividerView removeFromSuperview];
		[dividerView release];
		dividerView = [divider retain];
		dividerView.splitViewController = self;
		dividerView.backgroundColor = MG_DEFAULT_CORNER_COLOR;
		if ([self isShowingMaster]) {
			[self layoutSubviews];
		}
	}
}


- (BOOL)allowsDraggingDivider {
	if (dividerView) {
		return dividerView.allowsDragging;
	}
	
	return NO;
}


- (void)setAllowsDraggingDivider:(BOOL)flag {
	if (self.allowsDraggingDivider != flag && dividerView) {
		dividerView.allowsDragging = flag;
	}
}


- (MGSplitViewDividerStyle)dividerStyle {
	return dividerStyle;
}


- (void)setDividerStyle:(MGSplitViewDividerStyle)newStyle {
	if (hiddenPopoverController && hiddenPopoverController.popoverVisible) {
		[hiddenPopoverController dismissPopoverAnimated:NO];
	}
	
    // We don't check to see if newStyle equals _dividerStyle, because it's a meta-setting.
    // Aspects could have been changed since it was set.
	dividerStyle = newStyle;
	
    // Reconfigure general appearance and behaviour.
	float cornerRadius;
	if (dividerStyle == MGSplitViewDividerStyleThin) {
		cornerRadius = MG_DEFAULT_CORNER_RADIUS;
		splitWidth = MG_DEFAULT_SPLIT_WIDTH;
		self.allowsDraggingDivider = NO;
		
	} else if (dividerStyle == MGSplitViewDividerStylePaneSplitter) {
		cornerRadius = MG_PANESPLITTER_CORNER_RADIUS;
		splitWidth = MG_PANESPLITTER_SPLIT_WIDTH;
		self.allowsDraggingDivider = YES;
	}
	
    // Update divider and corners.
	[dividerView setNeedsDisplay];
	if (cornerViews) {
		for (MGSplitCornersView *corner in cornerViews) {
			corner.cornerRadius = cornerRadius;
		}
	}
	
    // Layout all views.
	[self layoutSubviews];
}


- (void)setDividerStyle:(MGSplitViewDividerStyle)newStyle 
               animated:(BOOL)animate {
	BOOL shouldAnimate = (animate && [self isShowingMaster]);
	if (shouldAnimate) {
		[UIView beginAnimations:@"DividerStyle" context:nil];
	}
	[self setDividerStyle:newStyle];
	if (shouldAnimate) {
		[UIView commitAnimations];
	}
}


- (NSArray *)cornerViews {
	if (cornerViews) {
		return [[cornerViews retain] autorelease];
	}
	
	return nil;
}


@synthesize showsMasterInPortrait;
@synthesize showsMasterInLandscape;
@synthesize vertical;
@synthesize delegate;
@synthesize viewControllers;
  //@synthesize masterViewController;
  //@synthesize detailViewController;
@synthesize dividerView;
@synthesize splitPosition;
@synthesize splitWidth;
  //@synthesize allowsDraggingDivider;
@synthesize dividerStyle;

@end
