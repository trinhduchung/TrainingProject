  //
  //  HomeScreenViewController.m
  //  QINS3
  //
  //  Created by Binh Ho on 8/15/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "HomeScreenViewController.h"
#import "MGSplitViewController.h"
#import "CustomerDetailsViewController.h"
#import "CustomerViewController.h"
#import "CustomDetailsEdit.h"
#import "PoliciesViewController.h"
#import "PolicyDetailsViewController.h"
#import "PoliciesEditViewController.h"
#import "ProfilesViewController.h"
#import "ProfilesDetailsViewController.h"
#import "Utils.h"
#import "qPeriorMobInsuranceDemo_PersonalizationParameters.h"
#import "SettingViewController.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_PolicyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "SUPObjectList.h"
#import "PoliciesUtils.h"
#import "InterviewHome.h"
#import "Utils.h"
#import "AnalysisHome.h"
#import "AnalysisController.h"
#import "InterviewController.h"
#import "InterviewDetails.h"

@implementation HomeScreenViewController

@synthesize visible;
@synthesize infoButton;
@synthesize cusButton;
@synthesize poliButton;
@synthesize profileButton;

#pragma mark - View lifecycle

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

  // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
	self.title = @"Home";
	[self initTooolbar];    
  self.navigationItem.hidesBackButton = YES;
  [self createSplitViews];
//  if (![qPeriorMobInsuranceDemo_QPeriorMobInsuranceDemoDB databaseExists]) {
//    [qPeriorMobInsuranceDemo_QPeriorMobInsuranceDemoDB createDatabase];
//    [APP_IPAD.utils saveData];
//  }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
  return ((interfaceOrientation == UIInterfaceOrientationLandscapeLeft)
            || (interfaceOrientation == UIInterfaceOrientationLandscapeRight));
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewWillAppear:(BOOL)animated {
  visible = YES;
  [super viewWillAppear:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
  [infoButton setCustomView:[Utils initButtonwithImage:@"Home_Normal.png" 
                                                targer:self 
                                              selector:@selector(home_clicked:)]];
  [super viewWillDisappear:YES];
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
  [super dealloc];
}


#pragma mark - Create splitviews

-(void)releaseAndReCreateSplitViews {
  if (APP_IPAD.splitView) {
    [APP_IPAD.splitView release];
    [APP_IPAD.policiesSplit release];
    [APP_IPAD.profilesSplit release];
  }
  [self createSplitViews];
}

-(void)createSplitViews {
  APP_IPAD.customerDetail = 
    [[CustomerDetailsViewController alloc] initWithNibName:@"CustomerDetailsViewController" 
                                                    bundle:nil];
  APP_IPAD.splitView = 
    [(MGSplitViewController *)[self createSplitView:APP_IPAD.customerView 
                                         DetailView:APP_IPAD.customerDetail] 
      retain];
  
  APP_IPAD.policiesDetail = 
    [[PolicyDetailsViewController alloc]initWithNibName:@"PolicyDetailsViewController" 
                                                 bundle:nil];
  APP_IPAD.policiesSplit = 
    [(MGSplitViewController*)[self createSplitView:APP_IPAD.policiesView 
                                        DetailView:APP_IPAD.policiesDetail]
      retain];
  
  APP_IPAD.profilesSplit = 
    [(MGSplitViewController*)[self createSplitView:APP_IPAD.profilesView
                                        DetailView:APP_IPAD.profilesDetailsView]
      retain];
  
  APP_IPAD.analysisSplit = 
    [(MGSplitViewController*)[self createSplitView:APP_IPAD.analysis 
                                        DetailView:APP_IPAD.analysisHome]
     retain];
  APP_IPAD.interviewSplit = 
  [(MGSplitViewController*)[self createSplitView:APP_IPAD.interview 
                                      DetailView:APP_IPAD.interviewDetail] 
   retain];
  
}

- (UIViewController *)createSplitView:(UIViewController *)rootView1 
                           DetailView:(UIViewController *)detailView1 {
	UINavigationController *navRoot = 
    [[[UINavigationController alloc] initWithRootViewController:rootView1] retain];
	UINavigationController *navDetail = 
    [[[UINavigationController alloc] initWithRootViewController:detailView1] retain];
	MGSplitViewController *splitViewTemp = [[MGSplitViewController alloc] init];
	splitViewTemp.viewControllers = [NSArray arrayWithObjects:navRoot,navDetail, nil];
	[splitViewTemp setShowsMasterInLandscape:YES];
	[splitViewTemp setShowsMasterInPortrait:YES];
	[splitViewTemp setAllowsDraggingDivider:YES];
	return splitViewTemp;
}

#pragma mark - Buttons actions

- (void)initTooolbar {
    //Initialize the toolbar
	toolbar = [[UIToolbar alloc] init];
	
    //Set the toolbar to fit the width of the app.
	[toolbar sizeToFit];
	
    //Caclulate the height of the toolbar
    //CGFloat toolbarHeight = [toolbar frame].size.height;
	
    //Get the bounds of the parent view
	CGRect rootViewBounds = self.parentViewController.view.bounds;
	
    //Get the height of the parent view.
	CGFloat rootViewHeight = CGRectGetHeight(rootViewBounds);
	
    //Get the width of the parent view,
	CGFloat rootViewWidth = CGRectGetWidth(rootViewBounds);
	
    //Create a rectangle for the toolbar
	CGRect rectArea = CGRectMake(0, rootViewHeight - 48, rootViewWidth, 48);
	
    //Reposition and resize the receiver
	[toolbar setFrame:rectArea];
  [self setToolbarBack:@"Tabbar_BG.png" toolbar:toolbar];
    //Create a button
  UIBarButtonItem *flexibleSpace = 
    [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace 
                                                 target:nil 
                                                 action:nil];
  UIButton *button;
  button = [Utils initButtonwithImage:@"Home_Normal.png" 
                               targer:self 
                             selector:@selector(home_clicked:)];
  infoButton = [[UIBarButtonItem alloc]initWithCustomView:button];
  button = [Utils initButtonwithImage:@"Customer_Normal.png" 
                               targer:self 
                             selector:@selector(customerAction:)];
  cusButton = [[UIBarButtonItem alloc]initWithCustomView:button];
  button = [Utils initButtonwithImage:@"Policy_Normal.png" 
                               targer:self 
                             selector:@selector(policiesAction:)];
  poliButton = [[UIBarButtonItem alloc]initWithCustomView:button];
  button = [Utils initButtonwithImage:@"Profile_Normal.png" 
                               targer:self 
                             selector:@selector(interview_clicked:)];
  profileButton = [[UIBarButtonItem alloc]initWithCustomView:button];    
  
  NSMutableArray *arrayItems = [[NSMutableArray alloc]init];
  [arrayItems addObject:flexibleSpace];
  [arrayItems addObject:infoButton];
  [arrayItems addObject:cusButton];
  [arrayItems addObject:poliButton];
  [arrayItems addObject:profileButton];
  [arrayItems addObject:flexibleSpace];
  
	[toolbar setItems:arrayItems];
    //[flexibleSpace release];
  
    //Add the toolbar as a subview to the navigation controller.
	[self.navigationController.view addSubview:toolbar];
}

- (void)setToolbarBack:(NSString *)bgFilename toolbar:(UIToolbar *)bottombar {
    // Add Custom Toolbar
  UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:bgFilename]];
  iv.frame = CGRectMake(0, 0, bottombar.frame.size.width, bottombar.frame.size.height);
  iv.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    // Add the tab bar controller's view to the window and display.
  if([[[UIDevice currentDevice] systemVersion] intValue] >= 5)
    [bottombar insertSubview:iv atIndex:1]; // iOS5 atIndex:1
  else
    [bottombar insertSubview:iv atIndex:0]; // iOS4 atIndex:0
  bottombar.tintColor = [UIColor clearColor];
}

- (void)setButtonHighlighted:(int)button {
    //    [infoButton setCustomView:[Utils initButtonwithImage:@"Home_Normal.png" targer:self selector:@selector(home_clicked:)]];
    //    [cusButton setCustomView:[Utils initButtonwithImage:@"Customer_Normal.png" targer:self selector:@selector(customerAction:)]];
    //    [poliButton setCustomView:[Utils initButtonwithImage:@"Policy_Normal.png" targer:self selector:@selector(policiesAction:)]];
    //    [profileButton setCustomView:[Utils initButtonwithImage:@"Profile_Normal.png" targer:self selector:@selector(profiles_clicked:)]];
    //    switch (button) {
    //        case kButtonHome:
    //            [infoButton setCustomView:[Utils initButtonwithImage:@"Home_Active.png" targer:self selector:@selector(home_clicked:)]];
    //            break;
    //        case kButtonCustomer:
    //            [cusButton setCustomView:[Utils initButtonwithImage:@"Customer_Active.png" targer:self selector:@selector(customerAction:)]];
    //            break;
    //        case kButtonPolicies:
    //            [poliButton setCustomView:[Utils initButtonwithImage:@"Policy_Active.png" targer:self selector:@selector(policiesAction:)]];
    //            break;
    //        case kButtonProfiles:
    //            [profileButton setCustomView:[Utils initButtonwithImage:@"Profile_Active.png" targer:self selector:@selector(profiles_clicked:)]];
    //            break;
    //        default:
    //            break;
    //    }
}


- (IBAction)customerAction:(id)sender {
  self.navigationController.navigationBar.hidden = YES;
  if (!APP_IPAD.splitView.visible) {
    [self releaseAndReCreateSplitViews];
    [APP_IPAD.customerView cancelSearch];
    @try {
      [self.navigationController pushViewController:APP_IPAD.splitView 
                                           animated:YES];
    }
    @catch (NSException *exception) {
      [self.navigationController popToViewController:APP_IPAD.splitView 
                                            animated:YES];
    }
  }    
}

- (IBAction)policiesAction:(id)sender {
  self.navigationController.navigationBar.hidden = YES;
  if (!APP_IPAD.policiesSplit.visible) {    
    [self releaseAndReCreateSplitViews];
    [APP_IPAD.policiesView cancelSearch];
    @try {
      [self.navigationController pushViewController:APP_IPAD.policiesSplit 
                                           animated:YES];
    }
    @catch (NSException *exception) {
      [self.navigationController popToViewController:APP_IPAD.policiesSplit 
                                            animated:YES];
    }
  }
}

- (void)home_clicked:(id)sender {
	self.navigationController.navigationBar.hidden = NO;
	[self.navigationController popToViewController:APP_IPAD.homeScreenViewController 
                                        animated:YES];
}

- (void)setting_clicked:(id)sender {
  SettingViewController *settingView =
    [[SettingViewController alloc]initWithNibName:@"SettingViewController" 
                                           bundle:nil];
  self.navigationController.navigationBar.hidden = YES;
  [self.navigationController pushViewController:settingView 
                                       animated:YES];
}

- (void)interview_clicked:(id)sender {
    APP_IPAD.hasFromCustomerDetail = NO;
  if ([sender isKindOfClass:[UIButton class]]) {
    APP_IPAD.interviewHome.bpNumber = @"";
    APP_IPAD.interviewHome.customerName = @"";
  }
  self.navigationController.navigationBar.hidden = YES;
  if (!APP_IPAD.interviewHome.visible) {
    [self releaseAndReCreateSplitViews];
    @try {
      [self.navigationController pushViewController:APP_IPAD.interviewHome 
                                           animated:YES];
    }
    @catch (NSException *exception) {
      [self.navigationController popToViewController:APP_IPAD.interviewHome 
                                            animated:YES];
    }
  }
}

- (IBAction)profiles_clicked:(id)sender {
  self.navigationController.navigationBar.hidden = YES;
  if (!APP_IPAD.profilesSplit.visible) {
    [self releaseAndReCreateSplitViews];
    @try {
      [self.navigationController pushViewController:APP_IPAD.profilesSplit 
                                           animated:YES];
    }
    @catch (NSException *exception) {
      [self.navigationController popToViewController:APP_IPAD.profilesSplit 
                                            animated:YES];
    }
  } 
}

@end


#pragma mark - Implement UIToolbar

@implementation UIToolbar (CustomImage)

- (void)drawRect:(CGRect)rect {
  if (self.frame.size.width > 200) {
    UIImage *image = [UIImage imageNamed: @"Tabbar_BG.png"];
    [image drawInRect:CGRectMake(0, 
                                 0, 
                                 self.frame.size.width, 
                                 self.frame.size.height)];
  }  
}

@end
