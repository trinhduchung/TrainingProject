//
//  QINS3AppDelegate.m
//  QINS3
//
//  Created by Binh Ho on 8/15/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "QINS3AppDelegate.h"
#import "qPeriorMobInsuranceDemo_QPeriorMobInsuranceDemoDB.h"
#import "SUPMessageClient.h"
#import "HomeScreenViewController.h"
#import "qPeriorMobInsuranceDemo_LogRecordImpl.h"
#import "CountryUtils.h"
#import "CustomerUtils.h"
#import "CustomerDetailsViewController.h"
#import "CustomDetailsEdit.h"
#import "PoliciesViewController.h"
#import "PoliciesEditViewController.h"
#import "PolicyDetailsViewController.h"
#import "PoliciesUtils.h"
#import "RelatedPolicies.h"
#import "ProfilesViewController.h"
#import "ProfilesDetailsViewController.h"
#import "InterviewController.h"
#import "InterviewDetails.h"
#import "SUPPushNotification.h"
#import "Utils.h"
#import "AnalysisController.h"
#import "AnalysisHome.h"
#import "InterviewHome.h"

@implementation QINS3AppDelegate

@synthesize utils;
@synthesize window;
@synthesize navigationController;
@synthesize homeScreenViewController;
@synthesize customerView;
@synthesize customerDetail;
@synthesize policiesView;
@synthesize policiesDetail;
@synthesize policyEdit;
@synthesize customerEdit;
@synthesize profilesView;
@synthesize profilesDetailsView;
@synthesize interview;
@synthesize interviewDetail;
@synthesize splitView;
@synthesize policiesSplit;
@synthesize profilesSplit;
@synthesize analysisSplit;
@synthesize interviewSplit;
@synthesize country;
@synthesize customerUtils;
@synthesize relatedPolicies;
@synthesize analysis;
@synthesize analysisHome;
@synthesize interviewHome;
@synthesize hasFromCustomerDetail;

- (BOOL)application:(UIApplication *)application 
      didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
  utils = [[Utils alloc]init];
  if (![qPeriorMobInsuranceDemo_QPeriorMobInsuranceDemoDB databaseExists]) {
    [qPeriorMobInsuranceDemo_QPeriorMobInsuranceDemoDB createDatabase];
    [utils saveData];
  }  
  customerView = 
    [[CustomerViewController alloc]initWithNibName:@"CustomerViewController" bundle:nil];
  customerDetail = 
    [[CustomerDetailsViewController alloc] initWithNibName:@"CustomerDetailsViewController" 
                                                    bundle:nil];
  customerEdit = 
    [[CustomDetailsEdit alloc]initWithNibName:@"CustomDetailsEdit" bundle:nil];
  relatedPolicies = 
    [[RelatedPolicies alloc]initWithNibName:@"RelatedPolicies" bundle:nil];
    
  policiesView = 
    [[PoliciesViewController alloc]initWithNibName:@"PoliciesViewController" bundle:nil];
  policiesDetail = 
    [[PolicyDetailsViewController alloc]initWithNibName:@"PolicyDetailsViewController" bundle:nil];
  policyEdit = 
    [[PoliciesEditViewController alloc]initWithNibName:@"PoliciesEditViewController" bundle:nil];
    
  profilesView = 
    [[ProfilesViewController alloc]initWithNibName:@"ProfilesViewController" bundle:nil];
  profilesDetailsView = 
    [[ProfilesDetailsViewController alloc]initWithNibName:@"ProfilesDetailsViewController" bundle:nil];
  
  analysis = [[AnalysisController alloc]initWithNibName:@"AnalysisController" bundle:nil];
  analysisHome = [[AnalysisHome alloc]initWithNibName:@"AnalysisHome" bundle:nil];
  
  interviewHome = [[InterviewHome alloc]initWithNibName:@"InterviewHome" bundle:nil];
  interview = [[InterviewController alloc]initWithNibName:@"InterviewController" bundle:nil];
  interviewDetail = [[InterviewDetails alloc]initWithNibName:@"InterviewDetails" bundle:nil];
    
  customerUtils = [[CustomerUtils alloc]init];
  country = [[CountryUtils alloc]init];       
	
  homeScreenViewController = 
  [[HomeScreenViewController alloc]initWithNibName:@"HomeScreenViewController" bundle:nil];
  
  navigationController = 
    [[UINavigationController alloc] initWithRootViewController:homeScreenViewController];  
  
  [self.window addSubview:navigationController.view]; 	
  [window makeKeyAndVisible];
    
	return YES;
}

- (void)dealloc {
  [window release];
  [super dealloc];
}

@end 
