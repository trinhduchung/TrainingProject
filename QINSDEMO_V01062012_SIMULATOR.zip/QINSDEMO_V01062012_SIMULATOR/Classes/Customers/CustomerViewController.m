    //
//  CustomerViewController.m
//  QINS3
//
//  Created by Binh Ho on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomerViewController.h"
#import "CustomerDetailsViewController.h"
#import	"CustomerUtils.h"
#import "CustomDetailsEdit.h"
#import "Utils.h"
#import	"PopOver.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_PersonalizationParameters.h"
#import "HomeScreenViewController.h"

@implementation CustomerViewController

@synthesize customerNewID;
@synthesize searchBar;
@synthesize tblView;
@synthesize data;
@synthesize arrData;
@synthesize popController;
@synthesize popOver;
@synthesize customerUtils;
@synthesize dictCustomers;
@synthesize visible;

#pragma mark - View lifecycle
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
	self.title = @"Customer";
	customerUtils = APP_IPAD.customerUtils;
//	data = [customerUtils getAllCustomer];
    
//	arrData = [data copy];//[customerUtils getAllCustomer];
	searchBar.autocorrectionType = UITextAutocorrectionTypeNo;
	tblView.delegate = self;
    
    // create toolbar buttons
  UIBarButtonItem *addButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addCustomer:)];
	self.navigationItem.rightBarButtonItem = addButton;
    
    // create create Account popOver
  popOver = [[PopOver alloc]init];
  popOver.arrContent = [[NSMutableArray alloc]initWithObjects:@"Corporate Account",@"Individual Account",nil];	
  popOver.sender = self;
  popController = [[UIPopoverController alloc]initWithContentViewController:popOver];
  popController.popoverContentSize = CGSizeMake(260,160);
    
	[addButton release];	
	[tblView reloadData];	
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)viewWillAppear:(BOOL)animated {
  [APP_IPAD.homeScreenViewController setButtonHighlighted:kButtonCustomer];
  visible = YES;
  NSThread *thread = [[NSThread alloc]initWithTarget:self selector:@selector(getData) object:nil];
  [thread start];
  [super viewWillAppear:YES];
}

- (void)getData {
  data = [customerUtils getAllCustomer];
  arrData = [data copy];
  [tblView reloadData];
}

-(void)viewWillDisappear:(BOOL)animated {
  visible = NO;
  [super viewWillDisappear:YES];
}

- (void)dealloc {
  [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
  return YES;
}

#pragma mark - Table methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView {
	return [data count];
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	NSMutableArray *arrGroup = [data objectAtIndex:section];
	return [arrGroup count];
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	NSMutableArray *characters = [[NSMutableArray alloc]initWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",nil];
	return [characters objectAtIndex:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"CellIdentifier";
	
	// Dequeue or create a cell of the appropriate type.
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle 
                                   reuseIdentifier:CellIdentifier] 
              autorelease];
		cell.accessoryType = UITableViewCellAccessoryNone;
	}
	
	NSMutableArray *section = [data objectAtIndex:indexPath.section];
	NSMutableArray *row = [section objectAtIndex:indexPath.row];
  
  
	cell.textLabel.text = [row objectAtIndex:kStringCustomerName];
	cell.textLabel.font = [UIFont boldSystemFontOfSize:16];
  NSString *detail = [row objectAtIndex:kStringCustomerStreet];
  if (detail.length > 30) {
    detail = [detail substringToIndex:27];
    detail = [detail stringByAppendingString:@"..."];
  }
	cell.detailTextLabel.text = detail;
	cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
	cell.imageView.image = [UIImage imageNamed:@"money.png"];
	
	UILabel *label;
	CGRect Label1Frame = CGRectMake(180, 25, 150, 14);
	label = [[UILabel alloc]initWithFrame:Label1Frame];	
  NSString *city = [row objectAtIndex:kStringCustomerCity];
  if (city.length > 20) {
    city = [city substringToIndex:16];
    city = [city stringByAppendingString:@"..."];
  }
	label.text = city;
	label.tag = 1;
	label.font = [UIFont systemFontOfSize:12];
    label.backgroundColor = [UIColor colorWithRed:245.0/255.0 green: 245.0/255.0 blue: 245.0/255.0 alpha: 1.0];
	label.textColor = [UIColor blackColor];
	label.highlightedTextColor = [UIColor whiteColor];
	for (UIView *view in cell.contentView.subviews) {
		[view removeFromSuperview];
	}
	[cell.contentView addSubview:label];
	[label release];	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Reload Customer Detail View
  NSMutableArray *section = [data objectAtIndex:indexPath.section];
  NSMutableArray *row = [section objectAtIndex:indexPath.row];
	NSString *number = [row objectAtIndex:kStringCustomerNumber];
  if ([qPeriorMobInsuranceDemo_CustomerCorporate findByPrimaryKey:number] != nil) {
    CustomerDetailsViewController *detailView = APP_IPAD.customerDetail;
    detailView.customer = [qPeriorMobInsuranceDemo_CustomerCorporate findByPrimaryKey:number];
    [detailView loadData];
  } else if ([qPeriorMobInsuranceDemo_CustomerIndividual findByPrimaryKey:number] != nil) {
    CustomerDetailsViewController *detailView = APP_IPAD.customerDetail;
    detailView.customer = [qPeriorMobInsuranceDemo_CustomerIndividual findByPrimaryKey:number];
    [detailView loadData];
  }
}


// Display Alphabet Sections
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
	NSMutableArray *tempArray = [[NSMutableArray alloc] initWithObjects:@"A",@"B",@"C",@"D",@"E",
                                                                      @"F",@"G",@"H",@"I",@"J",
                                                                      @"K",@"L",@"M",@"N",@"O",
                                                                      @"P",@"Q",@"R",@"S",@"T",
                                                                      @"U",@"V",@"W",@"X",@"Y",
                                                                      @"Z",nil];
	return tempArray;
}

- (NSInteger)tableView:(UITableView *)tableView 
    sectionForSectionIndexTitle:(NSString *)title 
    atIndex:(NSInteger)index {	
	return index % 2;
}

#pragma mark - Search

// Search Bar action
- (void)searchBar:(UISearchBar *)searchbar textDidChange:(NSString *)searchText {
	if ([searchText isEqualToString:@""] || searchText==nil) {
		[self.tblView reloadData];
		return;
	}
	//[data removeAllObjects];
  data = [[NSMutableArray alloc]init ];
	for (int i=0; i<26; i++) {
		NSMutableArray *arr = [[NSMutableArray alloc]init];
		[data addObject:arr];
	}
	
    // Filter Invidual and Corporate
  for (int i=0; i < [arrData count]; i++) {		
    NSMutableArray *arrGroup = [arrData objectAtIndex:i];
    for (int j = 0; j < [arrGroup count]; j++) {
      NSString *name = [[arrGroup objectAtIndex:j]objectAtIndex:kStringCustomerName];
      name = [name uppercaseString];
      searchText = [searchText uppercaseString];
      NSRange r = [name rangeOfString:searchText];
      if(r.location != NSNotFound) {
        [[data objectAtIndex:i] addObject:[arrGroup objectAtIndex:j]];
      }
		}
	}
	[tblView reloadData];
}

// search Bar Cancel Action
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchbar {	
	//[data removeAllObjects];
	[self cancelSearch];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchbar {
	[searchBar resignFirstResponder];
}

- (void)cancelSearch {
  data = [arrData copy];
	[tblView reloadData];
  self.searchBar.text = @"";
  [self.searchDisplayController setActive:NO animated:YES];
}

#pragma mark - Actions

-(IBAction)toggleSplitview {
  [Utils toggleSplitview];
}

-(void)loadData {
  [tblView reloadData];
  if (customerNewID != nil) {
    [tblView scrollToRowAtIndexPath:[self getIndexPathOfCustomer:customerNewID] atScrollPosition:UITableViewScrollPositionTop animated:YES];
    [tblView selectRowAtIndexPath:[self getIndexPathOfCustomer:customerNewID] animated:YES scrollPosition:UITableViewScrollPositionTop];
  }  
}

- (NSIndexPath *)getIndexPathOfCustomer:(NSString *)customerID {
  NSIndexPath *index;
  BOOL found = NO;
  int section = 0;
  while (!found && section < data.count) {
    NSMutableArray *array = [data objectAtIndex:section];
    int row = 0;
    while (!found && row < array.count) {
      NSMutableArray *arrayRow = [array objectAtIndex:row];
      if ([[arrayRow objectAtIndex:kStringCustomerNumber]isEqualToString:customerID]) {
        index = [NSIndexPath indexPathForRow:row inSection:section];
        found = YES;
      }
      row++;
    }
    section++;
  }
  return index;
}

-(void)refreshData {
  data = [customerUtils getAllCustomer];
  arrData = [data copy];//[customerUtils getAllCustomer];
  [tblView reloadData];
  [tblView beginUpdates];
  [tblView endUpdates];
}

-(void)waiting {
  NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
  [Utils startWaiting:self.view withContent:nil];
  [pool drain];
}

-(void)dismissPopOver {
  [popController dismissPopoverAnimated:YES];
}

// Add Customer Action
-(IBAction)addCustomer:(id)sender {
	if ([popController isPopoverVisible]) {
		[popController dismissPopoverAnimated:YES];
	} else {
		[popController presentPopoverFromBarButtonItem:sender 
                          permittedArrowDirections:UIPopoverArrowDirectionAny 
                                          animated:NO];        
	}
}

@end

@implementation UISearchDisplayController (DoNotHideBar)

- (void)setActive:(BOOL)visible animated:(BOOL)animated {
  if (visible) {
    [self.searchContentsController.navigationController setNavigationBarHidden:YES animated:YES];
    [self.searchBar setShowsCancelButton:YES animated:YES];
    [self.searchBar becomeFirstResponder];
  } else {
    [self.searchContentsController.navigationController setNavigationBarHidden:NO animated:YES];
    [self.searchBar setShowsCancelButton:NO animated:YES];
    [self.searchBar resignFirstResponder];
  }
}

@end
