//
//  CustomDetailsEdit.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 8/26/11.
//  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "CustomerEditPopOver.h"
#import "CountryUtils.h"
#import "SUPObjectList.h"
#import "CustomerUtils.h"
#import "CustomerDetailsViewController.h"

#define kSectionTitle @"SectionTitle"
#define kFieldKey @"FieldKey"
#define kValueKey @"ValueKey"

@class CustomerViewController;
@class CustomerDetailsViewController;


@interface CustomDetailsEdit : UIViewController<UITextFieldDelegate,
                                                UIPopoverControllerDelegate,
                                                CustomerProtocol>{
    
  NSMutableArray *arrContactNumber;
  NSMutableArray *contact;
    
	id customer;
  id customerStored;
	IBOutlet UITableView *table;
  IBOutlet UIImageView *image;
	NSMutableArray *arrData;
	NSMutableArray *arrTextField;
	
  NSMutableDictionary *dict;
    
	BOOL visible;
	BOOL editMode;
	BOOL isCorp; // customer kind, YES: corporate customer, NO: individual customer
	
	UITextField *txtFirstName;
	UITextField *txtLastName;
	UITextField *txtRole;
	UITextField *txtStreet;
	UITextField *txtNumber;
	UITextField *txtPostalCode;
	UITextField *txtCity;
  UITextField *txtRegion;
	UITextField *txtCountry;
	UITextField *txtTel;
	UITextField *txtMobile;
	UITextField *txtFax;
	UITextField *txtEmail;
	
	UIPopoverController *popController;
	CustomerEditPopOver *popOver;
  BOOL isFiltered;
    
  CustomerUtils *customerUtils;
  CountryUtils *country;
    
  int indexOfTextField;
  UITextField *activeTextField;
  BOOL keyboardShown;
  BOOL viewMoved;
    
  NSIndexPath *cellIndex;
    
  BOOL regionEnable;
  int listSize;
    
  NSMutableArray *arrSectionTitle;
    
  SUPObjectList *corpRoles;
  SUPObjectList *indiRoles;
    
  BOOL isPushed;
}
@property (nonatomic, retain) NSMutableArray *arrContactNumber;
@property (nonatomic, retain) NSMutableArray *contact;
@property (nonatomic, retain) SUPObjectList *corpRoles;
@property (nonatomic, retain) SUPObjectList *indiRoles;

@property (nonatomic,retain) id customer;
@property (nonatomic,retain) id customerStored;
@property (nonatomic,retain) IBOutlet UITableView *table;
@property (nonatomic,retain) IBOutlet UIImageView *image;
@property (nonatomic,retain) NSMutableArray *arrData;
@property (nonatomic,retain) NSMutableArray *arrTextField;
@property (nonatomic,retain) UITextField *txtFirstName;
@property (nonatomic,retain) UITextField *txtLastName;

@property (nonatomic,retain) NSMutableDictionary *dict;

@property (nonatomic,retain, readonly) UITextField *txtRole;
@property (nonatomic,retain) UITextField *txtStreet;
@property (nonatomic,retain) UITextField *txtNumber;
@property (nonatomic,retain) UITextField *txtPostalCode;
@property (nonatomic,retain) UITextField *txtCity;
@property (nonatomic,retain, readonly) UITextField *txtRegion;
@property (nonatomic,retain, readonly) UITextField *txtCountry;
@property (nonatomic,retain) UITextField *txtTel;
@property (nonatomic,retain) UITextField *txtMobile;
@property (nonatomic,retain) UITextField *txtFax;
@property (nonatomic,retain) UITextField *txtEmail;
@property (nonatomic) BOOL visible;
@property (nonatomic) BOOL editMode;
@property (nonatomic) BOOL isCorp;
@property (nonatomic,readwrite) BOOL isFiltered;
@property (nonatomic, retain) CustomerUtils *customerUtils;
@property (nonatomic) BOOL viewMoved;

@property (nonatomic,retain) UIPopoverController *popController;
@property (nonatomic,retain) CustomerEditPopOver *popOver;

@property (nonatomic) BOOL isPushed;

- (void)loadData;
- (void)setText;
- (void)addTextFieldToArray;
- (void)getDataFromPopOver:(id)sender;
- (BOOL)validate;
- (BOOL)NSStringIsValidEmail:(NSString *)checkString;
- (void)dismissPopover;
- (BOOL)showAlert:(NSString *)string;
- (NSMutableArray *)createNameData:(BOOL)isCorp;
- (NSMutableArray *)createAddressData;
- (NSMutableArray *)createContactData:(BOOL)isCorp;
- (void)setCustomerData:(id)cust isCorporate:(BOOL)isCorporate;

@end

