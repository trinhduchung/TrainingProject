//
//  CustomerViewController.h
//  QINS3
//
//  Created by Binh Ho on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "CustomerUtils.h"
#import "CustomDetailsEdit.h"

@class PopOver;
@class CustomerDetailsViewController;
@class CustomDetailsEdit;


@interface CustomerViewController : UIViewController<UISearchDisplayDelegate, 
                                                      UITableViewDataSource, 
                                                      UITableViewDelegate,
                                                      UIPopoverControllerDelegate,
                                                      CustomerProtocol> {
  NSString *customerNewID;
  NSMutableArray* data;
	NSMutableArray* arrData;
  IBOutlet UISearchBar *searchBar;
	IBOutlet UITableView *tblView;
	BOOL searching;
	BOOL letUserSelectRow;
	UIPopoverController *popController;
  PopOver *popOver;
  CustomerUtils *customerUtils;
  BOOL visible;
    
}

@property(nonatomic, retain) NSString *customerNewID;
@property(nonatomic, retain) IBOutlet UISearchBar *searchBar;
@property(nonatomic, retain) IBOutlet UITableView *tblView;
@property(nonatomic, retain) NSMutableArray *data;
@property(nonatomic, retain) NSMutableArray *arrData;
@property(nonatomic, retain) UIPopoverController *popController;
@property(nonatomic, retain) PopOver *popOver;
@property(nonatomic, retain) CustomerUtils *customerUtils;
@property(nonatomic, retain) NSMutableDictionary *dictCustomers;
@property(nonatomic) BOOL visible;

- (IBAction)addCustomer:(id)sender;
- (void)dismissPopOver;
- (void)waiting;
- (IBAction)toggleSplitview;
- (void)refreshData;
- (void)cancelSearch;

- (NSIndexPath *)getIndexPathOfCustomer:(NSString *)customerID;

@end

