//
//  CustomerDetailInfo.h
//  QINS3
//
//  Created by Ha Nguyen on 8/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "CustomerUtils.h"
//#import "CustomerDetailsViewController.h"

@class CustomerDetailsViewController;
@interface CustomerDetailInfo : UIViewController <UITableViewDelegate,UITableViewDataSource> {
	id cusDetailInfo;
  NSMutableArray *arrTitle;
	NSMutableArray *arrCustomer;
	UITableView *tblSubInfo;
    
}

@property (nonatomic, retain) id cusDetailInfo;
@property (nonatomic, retain) UITableView *tblSubInfo;
@property (nonatomic, retain) NSMutableArray *arrTitle;
@property (nonatomic, retain) NSMutableArray *arrCustomer;

- (void)reloadDataInfo;

@end
