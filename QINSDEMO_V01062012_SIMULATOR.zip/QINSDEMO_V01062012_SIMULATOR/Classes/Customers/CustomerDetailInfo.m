  //
  //  CustomerDetailInfo.m
  //  QINS3
  //
  //  Created by Ha Nguyen on 8/25/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "CustomerDetailInfo.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "CustomerDetailsInfoCustomCell.h"
#import "CustomerUtils.h"

@implementation CustomerDetailInfo

@synthesize cusDetailInfo;
@synthesize tblSubInfo;
@synthesize arrCustomer;
@synthesize arrTitle;


-(void)viewDidLoad {
	tblSubInfo = [[UITableView alloc] init];
	tblSubInfo.dataSource = self;
	tblSubInfo.delegate = self;
    //custUtils = [[CustomerUtils alloc]init];
}

-(void)reloadDataInfo {
	if (arrCustomer == nil) {
		arrCustomer = [[NSMutableArray alloc] init];
	}
  if (arrTitle == nil) {
    arrTitle = [[NSMutableArray alloc]init];
    [arrTitle addObject:@"Address"];
    [arrTitle addObject:@"Tel."];
    [arrTitle addObject:@"Fax"];
    [arrTitle addObject:@"E-Mail"];
    [arrTitle addObject:@"Role"];
  }
  if (arrCustomer == nil) {
    arrCustomer = [[NSMutableArray alloc]init];
  } else {
    [arrCustomer removeAllObjects];
  }
  NSString *strRole = @"";
  if ([cusDetailInfo isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
    strRole = [CustomerUtils getFullRole:[cusDetailInfo bpRole] isCorporate:YES];
  } else if ([cusDetailInfo isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
    strRole = [CustomerUtils getFullRole:[cusDetailInfo bpRole] isCorporate:NO];
  } else {
    
  }
  CustomerUtils *custUtils = [[CustomerUtils alloc]init];
  NSString *strStreet = [cusDetailInfo bpAddrStreet];
  if (strStreet.length > 15) {
    strStreet = [NSString stringWithFormat:@"%@...", [strStreet substringToIndex:13]];
  }
  
  NSString *strCity = [cusDetailInfo bpAddrCity];
  if (strCity.length >30) {
    strCity = [NSString stringWithFormat:@"%@...", [strCity substringToIndex:28]];
  }
  
  NSString *strCountry = [CustomerUtils getFullLocationName:[cusDetailInfo bpAddrCountry] 
                                                   isRegion:NO];
  
  NSString *address = [[NSString alloc] initWithFormat:@"%@ %@\n%@ \n%@",
                                                      [cusDetailInfo bpAddrHouseNo],
                                                      strStreet,
                                                      strCity,
                                                      strCountry];
  
  NSString *telephone = [custUtils convertContactNumberDatabaseToDisplay:[cusDetailInfo bpComTelephone]];
	NSString *fax = [custUtils convertContactNumberDatabaseToDisplay:[cusDetailInfo bpComFax]];
  NSString *email = [[NSString alloc] initWithFormat:@"%@",[cusDetailInfo bpComEmail]];
  
	[arrCustomer addObject:address];
  [arrCustomer addObject:telephone];
	[arrCustomer addObject:fax];
	[arrCustomer addObject:email];
	[arrCustomer addObject:strRole];
	
	if (tblSubInfo == nil) {
		tblSubInfo = [[UITableView alloc] init];
	}
	tblSubInfo.dataSource = self;
	[tblSubInfo reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return 1;
}

  // Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 5;
}

  // Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  static NSString *CellIdentifier = @"Cell";
  
  CustomerDetailsInfoCustomCell *cell = (CustomerDetailsInfoCustomCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomerDetailsInfoCustomCell" owner:self options:nil];
    for (id oneObject in nib)
      if ([oneObject isKindOfClass:[CustomerDetailsInfoCustomCell class]])
        cell = (CustomerDetailsInfoCustomCell *)oneObject;
  } else {
    UIView *view = nil;
    view = [cell.contentView viewWithTag:1];
    if (!view) {
      [view removeFromSuperview];
    }
  }
  
  if (indexPath.row == 0) {    
    cell.txtValue.lineBreakMode = UILineBreakModeWordWrap;
    cell.txtValue.numberOfLines = 3;
    cell.txtValue.frame = CGRectMake(cell.txtValue.frame.origin.x, cell.txtValue.frame.origin.y-20, cell.txtValue.frame.size.width, 100);
  }
	cell.txtKey.text = [arrTitle objectAtIndex:indexPath.row];
  cell.txtValue.text = [arrCustomer objectAtIndex:indexPath.row];
  return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.row == 0) {
    return 100; 
  }
  return 40;
}

- (void)dealloc {
  [super dealloc];
}


@end
