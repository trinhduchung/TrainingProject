  //
  //  CustomerDetailsViewController.h
  //  QINS3
  //
  //  Created by Binh Ho on 8/15/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "CustomerDetailInfo.h"
#import "CustomerDetailRelated.h"
#import "PieChartView.h"
#import "CustomerViewController.h"

@class CustomerViewController;
@class CustomDetailsEdit;
@class ProfileListProductsPopOver;

@interface CustomerDetailsViewController : UIViewController<CustomerProtocol> {
  
  id customer;
  IBOutlet UIButton *btnInfo;
  IBOutlet UIButton *btnIntervew;
  IBOutlet UIImageView *image;
	IBOutlet UILabel *name;
	IBOutlet UILabel *cusID;
	IBOutlet UITableView *tblInfo;
	IBOutlet UITableView *tblRelated;
	IBOutlet UIView *pieChartView;
	IBOutlet PieChartView *_pieChart;
	CustomerDetailInfo *cusInfo;
	CustomerDetailRelated *cusRelated;
  IBOutlet UIImageView *chartBG;
  
  NSMutableDictionary *dictPolicy;
  NSMutableDictionary *dictThirdParty;
  
  BOOL isPushed;
  SUPObjectList *listProducts;
  
  UIPopoverController *popController;
  ProfileListProductsPopOver *popOver;
}

@property (nonatomic, retain) IBOutlet UIButton *btnInfo;
@property (nonatomic, retain) IBOutlet UIImageView *image;
@property (nonatomic, retain) IBOutlet UIButton *btnInterview;
@property (nonatomic, retain) id customer;
@property (nonatomic, retain) UILabel *name;
@property (nonatomic, retain) UILabel *cusID;
@property (nonatomic, retain) UITableView *tblInfo;
@property (nonatomic, retain) UITableView *tblRelated;
@property (nonatomic, retain) IBOutlet UIView *pieChartView;
@property (nonatomic, retain) IBOutlet UIImageView *chartBG;
@property (nonatomic, retain) PieChartView *_pieChart;
@property (nonatomic, retain) CustomerDetailInfo *cusInfo;
@property (nonatomic, retain) CustomerDetailRelated *cusRelated;

@property (nonatomic) BOOL isPushed;

- (void)loadData;
- (void)loadName;
- (void)createTableInfo;
- (void)createTableRelated;
- (void)loadPieChart:(NSMutableDictionary *)dictColor;
- (void)initDictionaries;
- (NSMutableDictionary *)getListPercents:(NSString *)number;
- (IBAction)chartInfo:(id)sender;
- (IBAction)cancel:(id)sender;
- (void)addDataToDictionary:(NSMutableDictionary *)dictDestination 
                 fromSource:(NSMutableDictionary *)dictSource 
                      andID:(NSString *)pId;
- (NSString *)getProductName:(id)item;
- (SUPObjectList*)getListProducts;
- (void)saveAllData;
- (void)getData;

@end



