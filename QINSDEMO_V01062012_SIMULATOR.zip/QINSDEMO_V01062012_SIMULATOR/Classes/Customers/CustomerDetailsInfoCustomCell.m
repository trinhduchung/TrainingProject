  //
  //  CustomerDetailsInfoCustomCell.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 9/30/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "CustomerDetailsInfoCustomCell.h"


@implementation CustomerDetailsInfoCustomCell

@synthesize txtValue;
@synthesize txtKey;

- (id)initWithStyle:(UITableViewCellStyle)style 
    reuseIdentifier:(NSString *)reuseIdentifier {
  if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
    
  }
  return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
  [super setSelected:selected animated:animated];
}

- (void)dealloc {
  [super dealloc];
}

@end
