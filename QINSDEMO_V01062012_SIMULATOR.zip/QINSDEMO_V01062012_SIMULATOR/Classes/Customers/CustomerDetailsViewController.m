  //
  //  CustomerDetailsViewController.m
  //  QINS3
  //
  //  Created by Binh Ho on 8/15/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "CustomerDetailsViewController.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "CustomerDetailInfo.h"
#import "CustomerDetailRelated.h"
#import "CustomerUtils.h"
#import "Utils.h"
#import "MGSplitViewController.h"
#import "CustomDetailsEdit.h"
#import "CustomerViewController.h"
#import "qPeriorMobInsuranceDemo_PolicyPartner.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_PolicyItem.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyItem.h"
#import "qPeriorMobInsuranceDemo_CustomizingProduct.h"
#import "ProfileListProductsPopOver.h"
#import "MGSplitViewController.h"
#import "HomeScreenViewController.h"
#import "InterviewHome.h"
#import "InterviewDetails.h"
#import "InterviewController.h"
#import "MGSplitViewController.h"

@implementation CustomerDetailsViewController

@synthesize btnInfo;
@synthesize btnInterview;
@synthesize image;
@synthesize customer;
@synthesize name;
@synthesize cusID;
@synthesize tblInfo;
@synthesize tblRelated;
@synthesize cusInfo;
@synthesize cusRelated;
@synthesize pieChartView;
@synthesize _pieChart;
@synthesize isPushed;
@synthesize chartBG;
  //@synthesize blankChart;

#pragma mark - View Lifecycle
  // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
	self.title = @"Customer Details";
  
	cusInfo = [[CustomerDetailInfo alloc] init];    
	cusRelated = [[CustomerDetailRelated alloc] init];
  
  tblInfo.hidden = YES;
  tblRelated.hidden = YES;
  btnIntervew.hidden = YES;
  cusRelated.view.hidden = YES;
  btnInfo.hidden = YES;
  btnInterview.hidden = YES;
  name.hidden = YES;
  cusID.hidden = YES;
  image.hidden = YES;
  listProducts = [self getListProducts];
  popOver = [[ProfileListProductsPopOver alloc] initWithNibName:@"ProfileListProductsPopOver" 
                                                         bundle:nil];
	popController = [[UIPopoverController alloc] initWithContentViewController:popOver];
  if (customer != nil) {        
    [self loadData];
  }    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
  return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
  
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated {
  UIToolbar *toolbar;
  if (isPushed) {
    toolbar = [Utils getLeftButtons:self withMode:kToggleCancel];
  } else {
    toolbar = [Utils getLeftButtons:self withMode:kToggleOnly];
  }
  self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:toolbar];
  if (customer != nil) {
    [self loadData];
  }
  CustomerViewController *customerView = APP_IPAD.customerView;
  customerView.view.userInteractionEnabled = YES;
  [super viewWillAppear:YES];
}

- (void)dealloc {
  [super dealloc];
}

- (IBAction)showInterview:(id)sender {
  HomeScreenViewController *homeController = APP_IPAD.homeScreenViewController;
  InterviewHome *interviewHome = [[InterviewHome alloc]initWithNibName:@"InterviewHome" bundle:nil];  
  interviewHome.bpNumber = [customer bpNumber];
  if ([customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
    interviewHome.customerName = [customer bpCorpName];
  } else {
    interviewHome.customerName = [NSString stringWithFormat:@"%@ %@", [customer bpIndFirstName], [customer bpIndLastName]];
  }
  APP_IPAD.interviewHome = interviewHome;
    InterviewDetails* interviewDetails = [[InterviewDetails alloc] init] ;
    interviewDetails.bpNumber = [customer bpNumber];
    [interviewDetails loadData];
    APP_IPAD.interviewDetail = interviewDetails;
    
//  [homeController.navigationController pushViewController:interviewHome animated:YES];
    APP_IPAD.hasFromCustomerDetail = YES;
    @try {
        APP_IPAD.interview = [[InterviewController alloc]initWithNibName:@"InterviewController" bundle:nil];
        
        APP_IPAD.interviewSplit = (MGSplitViewController*)[APP_IPAD.homeScreenViewController createSplitView:APP_IPAD.interview 
            DetailView:APP_IPAD.interviewDetail];
        
        APP_IPAD.homeScreenViewController.navigationController.navigationBar.hidden = YES;
        
        [APP_IPAD.homeScreenViewController.navigationController pushViewController:APP_IPAD.interviewSplit animated:YES];
        
    } @catch (NSException *exception) { }
     
}

#pragma mark - Actions
- (IBAction)cancel:(id)sender {
  [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)editCustomer:(id)sender{	
	CustomDetailsEdit *customEdit = APP_IPAD.customerEdit;	
	customEdit.editMode = YES;
	customEdit.customer = self.customer;
  customEdit.customerStored = self.customer;
  [customEdit loadData];
  APP_IPAD.customerView.view.userInteractionEnabled = NO;
	[self.navigationController pushViewController:customEdit animated:YES];
}

#pragma mark - Load Data

- (void)loadData {    
  [self initDictionaries];
  UIBarButtonItem *editButton = 
  [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit 
                                               target:self 
                                               action:@selector(editCustomer:)];
  self.navigationItem.rightBarButtonItem = editButton;
  [editButton release];
	[self loadName];
	[self createTableInfo];
	[self createTableRelated];
	[self loadPieChart:[self getListPercents:[customer bpNumber]]];
}

- (void)loadName {
  name.hidden = NO;
  cusID.hidden = NO;
  image.hidden = NO;
  chartBG.hidden = NO;
  btnInfo.hidden = NO;
  btnIntervew.hidden = NO;
  NSString *stringName = @"";
	if ([customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
		stringName = [NSString stringWithFormat:@"%@",[customer bpCorpName]];
		cusID.text = [NSString stringWithFormat:@"%@",[customer bpNumber]];
  }
  if ([customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]){
		stringName = [NSString stringWithFormat:@"%@ %@",
                                            [customer bpIndFirstName],
                                            [customer bpIndLastName]];
		cusID.text = [NSString stringWithFormat:@"%@",[customer bpNumber]];
  }
  if (stringName.length > 35) {
    stringName = [stringName substringToIndex:31];
    stringName = [stringName stringByAppendingString:@"..."];
  }
  name.text = stringName;
}

- (void)createTableInfo {
	tblInfo.delegate = cusInfo;
	tblInfo.dataSource = cusInfo;
	tblInfo.allowsSelection = NO;
  tblInfo.hidden = NO;
  btnInfo.hidden = NO;
  btnInterview.hidden = NO;
	cusInfo.cusDetailInfo = customer;    
	[cusInfo reloadDataInfo];
	tblInfo.backgroundView.hidden = YES;
	[tblInfo reloadData];
}

- (void)createTableRelated {
	tblRelated.delegate = cusRelated;
	tblRelated.dataSource = cusRelated;
  tblRelated.hidden = NO;
	cusRelated.cusDetailRelated = customer;
  cusRelated.view.hidden = YES;
	[cusRelated loadDataRelated];
	tblRelated.backgroundView.hidden = YES;
	[tblRelated reloadData];
}

- (void)initDictionaries {
  
  SUPObjectList *lstPolicy = [[qPeriorMobInsuranceDemo_PolicyHeader findAll]retain];
  SUPObjectList *lstThirdParty = [[qPeriorMobInsuranceDemo_ThirdPartyHeader findAll]retain];
  
  dictPolicy = [[NSMutableDictionary alloc]init];
  for (int i = 0; i < [lstPolicy size]; i++) {
    qPeriorMobInsuranceDemo_PolicyHeader *header = [lstPolicy item:i];
    if ([dictPolicy valueForKey:header.pId] == nil) {
      [dictPolicy setValue:header forKey:header.pId];
    }
  }
  
  dictThirdParty = [[NSMutableDictionary alloc]init];
  for (int i = 0; i < [lstThirdParty size]; i++) {
    qPeriorMobInsuranceDemo_ThirdPartyHeader *header = [lstThirdParty item:i];
    if ([dictThirdParty valueForKey:header.pId] == nil) {
      [dictThirdParty setValue:header forKey:header.pId];
    }
  }    
}

// count policy items or third party contract items and add to dictionary with key is item name and value is quantity
- (void)addDataToDictionary:(NSMutableDictionary *)dictDestination 
                 fromSource:(NSMutableDictionary *)dictSource 
                      andID:(NSString *)pId {
  if ([dictSource valueForKey:pId] != nil) {
    SUPObjectList *lstItem;
    if (dictSource == dictPolicy) {
      lstItem = [[dictSource valueForKey:pId] PolicyHeaderPolicyItem];
    } else {
      lstItem = [[dictSource valueForKey:pId] ThirdPartyHeaderThirdPartyItem];
    }
    NSString *strName = @"";
    for (int j = 0; j < [lstItem size]; j++) {
      strName = [self getProductName:[lstItem item:j]];
      if (![strName isEqualToString:@""]) {
        if ([dictDestination valueForKey:strName] == nil) {
          [dictDestination setValue:@"1" forKey:strName];
        } else {
          int c = [[dictDestination valueForKey:strName] intValue];
          c++;
          NSNumber *num = [NSNumber numberWithInt:c];
          [dictDestination setValue:[num stringValue] forKey:strName];
        }
      }            
    }
  }
}

- (NSString *)getProductName:(id)item {
  if ([item pItemProductId] != nil && ![[item pItemProductId] isEqualToString:@""]) {
    return [item pItemProductId];
  } else if([item pItemProductDescr] != nil 
                && ![[item pItemProductDescr] isEqualToString:@""]){
    char character = [[item pItemProductDescr] characterAtIndex:0];
    NSString *returnString = [NSString stringWithFormat:@"%C", character];
    NSArray *arrSpace = [[item pItemProductDescr] componentsSeparatedByString:@" "];
    if ([arrSpace count] > 1) {
      for (int i = 0; i < [arrSpace count]-1; i++) {
        int index = [[item pItemProductDescr]rangeOfString:@" "].location;
        char c = [[item pItemProductDescr] characterAtIndex:index+1];
        returnString = [returnString stringByAppendingFormat:@"%C", c];
      }
    } else if ([arrSpace count] == 1) {
      NSString *substring = [[item pItemProductDescr] substringToIndex:2];
      returnString = [NSString stringWithFormat:@"%@", substring];
    }
    return returnString;
  }
  return @"";
}

#pragma mark - Pie Chart
- (void)loadPieChart:(NSMutableDictionary *)dictColor {
  [_pieChart clearItems];	
	[_pieChart setGradientFillStart:0.3 andEnd:0.3];
	[_pieChart setGradientFillColor:PieChartItemColorMake(0.0, 0.0, 0.0, 0.7)];
  
  for (int i = 0; i < [[dictColor allKeys] count]; i++) {
    NSString *strName = [[dictColor allKeys] objectAtIndex:i];
    if ([[dictColor valueForKey:strName] isEqualToString:kRed]) {
      [_pieChart addItemValue:1 
                    withColor:PieChartItemColorMake(1, 0, 0, 0.8) 
                     withName:strName];
    } else if ([[dictColor valueForKey:strName] isEqualToString:kGreen]) {
      [_pieChart addItemValue:1 
                    withColor:PieChartItemColorMake(0.13, 0.54, 0.13, 0.8) 
                     withName:strName];
    } else {
      [_pieChart addItemValue:1 
                    withColor:PieChartItemColorMake(1, 1, 0, 0.8) 
                     withName:strName];
    }
  }
  
	_pieChart.alpha = 1.0;
	[_pieChart setHidden:NO];
	[_pieChart setNeedsDisplay];
	
    // Animate the fade-in
	/*[UIView beginAnimations:nil context:NULL];
   [UIView setAnimationDuration:0.5];
   _pieChart.alpha = 1.0;
   [UIView commitAnimations];*/
}

  // get list percents for chart
- (NSMutableDictionary *)getListPercents:(NSString *)number {
  NSMutableDictionary *dictProductColor = [[NSMutableDictionary alloc]init];
  if (number != nil) {
    SUPObjectList *listProduct = [[qPeriorMobInsuranceDemo_CustomizingProduct findAll]retain];
    for (qPeriorMobInsuranceDemo_CustomizingProduct *product in listProduct) {
      if ([dictProductColor valueForKey:product.customizeProductId] == nil) {
        NSString *productId = [NSString stringWithFormat:@"%@", product.customizeProductId];
        [dictProductColor setValue:kRed forKey:productId];
      }
    }
    NSString *customerNumber = [customer bpNumber];
    
    NSMutableDictionary *dictPolicyHeader = [Utils getPolicies:customerNumber];   
    
    SUPObjectList *listPolicyPartners = 
        [[qPeriorMobInsuranceDemo_PolicyPartner findByBpAssignedNumber:customerNumber] retain];
    if ([listPolicyPartners size] > 0) {
      for (qPeriorMobInsuranceDemo_PolicyPartner *partner in listPolicyPartners) {
        qPeriorMobInsuranceDemo_PolicyHeader *header = [dictPolicyHeader valueForKey:partner.pGuid];
        SUPObjectList *listItems = header.PolicyHeaderPolicyItem;
        for (qPeriorMobInsuranceDemo_PolicyItem *item in listItems) {
          if ([dictProductColor valueForKey:item.pItemProductId] != nil) {
            [dictProductColor setValue:kGreen forKey:item.pItemProductId];
          }
        }
      }
    }    
    
    NSMutableDictionary *dictThirdPartyHeader = [Utils getThirdparties:customerNumber];
    
    SUPObjectList *listThirdPartyPartners = 
        [[qPeriorMobInsuranceDemo_ThirdPartyPartner findByBpAssignedNumber:customerNumber]retain];
    if ([listThirdPartyPartners size] > 0) {
      for (qPeriorMobInsuranceDemo_ThirdPartyPartner *partner in listThirdPartyPartners) {
        qPeriorMobInsuranceDemo_ThirdPartyHeader *header = [dictThirdPartyHeader valueForKey:partner.pGuid];
        SUPObjectList *listItems = header.ThirdPartyHeaderThirdPartyItem;
        for (qPeriorMobInsuranceDemo_ThirdPartyItem *item in listItems) {
          if ([dictProductColor valueForKey:item.pItemProductId] != nil 
                && ![[dictProductColor valueForKey:item.pItemProductId] isEqualToString:kGreen]) {
            [dictProductColor setValue:kYellow forKey:item.pItemProductId];
          }
        }
      }
    }
  }        
  
  return dictProductColor;
}

- (SUPObjectList *)getListProducts {
  SUPObjectList *list = [[SUPObjectList alloc]init];
  NSMutableDictionary *dictProductID = [Utils getProductIDDictionary];
  NSArray *arrID = [dictProductID allKeys];
  arrID = [arrID sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
  for (NSString *strID in arrID) {
    [list addObject:strID];
  }
  return list;
}

- (IBAction)chartInfo:(id)sender {
  CGRect frame = CGRectMake(btnInfo.frame.origin.x+410, 
                            btnInfo.frame.origin.y+90, 
                            btnInfo.frame.size.width, 
                            btnInfo.frame.size.height); 
  popOver.data = listProducts;
  popOver.sender = self;
  int size = [popOver.data size];
  int height = 350;
  if (size <= 10) {
    height = size*45;
  }
  [popOver loadData];
  popController.popoverContentSize = CGSizeMake(300,height);
  [self->popController presentPopoverFromRect:frame 
                                       inView:self.view 
                     permittedArrowDirections:UIPopoverArrowDirectionRight 
                                     animated:YES]; 
}

@end
