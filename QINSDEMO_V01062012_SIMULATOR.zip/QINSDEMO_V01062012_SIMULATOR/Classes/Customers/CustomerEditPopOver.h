//
//  CustomerEditPopOver.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 8/31/11.
//  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SUPObjectList.h"
#import "Utils.h"

@interface CustomerEditPopOver : UIViewController <UITableViewDelegate, UITableViewDataSource>{
	IBOutlet UITableView *table;
	IBOutlet UIBarButtonItem *button;
	SUPObjectList *arrContent;
	id returnData;
	id sender;
}

@property (nonatomic,retain) IBOutlet UITableView *table;
@property (nonatomic,retain) IBOutlet UIBarButtonItem *button;
@property (nonatomic,retain) SUPObjectList *arrContent;
@property (nonatomic,retain) id returnData;
@property (nonatomic,retain) id sender;

- (void)loadData;
- (void)dismissPopover;

@end
