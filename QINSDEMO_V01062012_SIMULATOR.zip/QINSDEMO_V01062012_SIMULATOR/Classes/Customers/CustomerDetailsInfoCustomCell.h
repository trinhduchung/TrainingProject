//
//  CustomerDetailsInfoCustomCell.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 9/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomerDetailsInfoCustomCell : UITableViewCell {
  IBOutlet UILabel *txtKey;
  IBOutlet UILabel *txtValue;
}

@property (nonatomic, retain) IBOutlet UILabel *txtKey;
@property (nonatomic, retain) IBOutlet UILabel *txtValue;

@end
