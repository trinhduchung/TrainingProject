//
//  CustomerDetailRelated.h
//  QINS3
//
//  Created by Ha Nguyen on 8/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "CustomerDetailsViewController.h"
@class CustomerDetailsViewController; 

@interface CustomerDetailRelated : UIViewController <UITableViewDelegate,UITableViewDataSource>{
	id cusDetailRelated;
	NSMutableArray *data;
	UITableView *tblRelated;
  NSString *strNumber;
}

@property (nonatomic,retain) id cusDetailRelated;
@property (nonatomic,retain) NSMutableArray *data;
@property (nonatomic,retain) UITableView *tblRelated;

- (void)countRelationShips;
- (void)countAppointments;
- (void)countTasks;
- (void)loadDataRelated;
- (void)addNew:(id)sender;

@end
