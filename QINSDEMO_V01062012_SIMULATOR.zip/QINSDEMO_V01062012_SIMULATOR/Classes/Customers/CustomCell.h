//
//  CustomCell.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 8/26/11.
//  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomCell : UITableViewCell {
	IBOutlet UILabel *label;
	IBOutlet UITextField *textField;
}

@property (nonatomic,retain) IBOutlet UILabel *label;
@property (nonatomic,retain) IBOutlet UITextField *textField;

@end
