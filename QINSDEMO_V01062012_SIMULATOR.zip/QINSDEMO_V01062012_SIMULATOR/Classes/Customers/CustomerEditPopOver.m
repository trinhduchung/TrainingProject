  //
  //  CustomerEditPopOver.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 8/31/11.
  //  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
  //

#import "CustomerEditPopOver.h"
#import "CustomDetailsEdit.h"
#import "Utils.h"
#import "qPeriorMobInsuranceDemo_CustomizingCountry.h"
#import "qPeriorMobInsuranceDemo_CustomizingRegion.h"
#import "qPeriorMobInsuranceDemo_CustomizingCustCorpRoles.h"
#import "qPeriorMobInsuranceDemo_CustomizingIndvCorpRoles.h"
#import "SUPObjectList.h"
#import "PoliciesEditViewController.h"
#import "qPeriorMobInsuranceDemo_CustomizingProcessType.h"
#import "qPeriorMobInsuranceDemo_CustomerRelationships.h"
#import "qPeriorMobInsuranceDemo_CustomizingPaymentType.h"

@implementation CustomerEditPopOver

@synthesize table;
@synthesize button;
@synthesize arrContent;
@synthesize returnData;
@synthesize sender;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */


  // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
	returnData = nil;
  arrContent = [[SUPObjectList alloc] init];
	table.backgroundView = NO;
    //customEdit = APP_IPAD.customerEdit;
}

-(void)loadData {
	[table reloadData];
}

-(void)dismissPopover {
  [sender dismissPopover];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  return [arrContent size];
}


  // Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {    
  static NSString *CellIdentifier = @"Cell";    
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                   reuseIdentifier:CellIdentifier] 
                autorelease];
  }
  id object = [arrContent item:indexPath.row];
  if ([object isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingCountry class]]) {
    qPeriorMobInsuranceDemo_CustomizingCountry *country = [arrContent item:indexPath.row];
    cell.textLabel.text = country.customizeAddrCountryDescr;
  } else if ([object isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingRegion class]]) {
    qPeriorMobInsuranceDemo_CustomizingRegion *region = [arrContent item:indexPath.row];
    cell.textLabel.text = region.customizeAddrRegionDescr;
  } else if ([object isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingCustCorpRoles class]]) {
    qPeriorMobInsuranceDemo_CustomizingCustCorpRoles *role = [arrContent item:indexPath.row];
    cell.textLabel.text = role.customizeCustRoleDescr;
  } else if ([object isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingIndvCorpRoles class]]) {
    qPeriorMobInsuranceDemo_CustomizingIndvCorpRoles *role = [arrContent item:indexPath.row];
    cell.textLabel.text = role.customizeCustRoleDescr;
  } else if ([object isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingPaymentType class]]) {
    qPeriorMobInsuranceDemo_CustomizingPaymentType *payment = [arrContent item:indexPath.row];
    cell.textLabel.text = payment.customizePamentTypeDescr;
  } else {
    cell.textLabel.text = [NSString stringWithFormat:@"%@", [arrContent item:indexPath.row]];
  }
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	returnData = [arrContent item:indexPath.row];
  [sender getDataFromPopOver:self];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  return YES;
}


- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
}


- (void)viewDidUnload {
  [super viewDidUnload];
}


- (void)dealloc {
  [super dealloc];
}

@end
