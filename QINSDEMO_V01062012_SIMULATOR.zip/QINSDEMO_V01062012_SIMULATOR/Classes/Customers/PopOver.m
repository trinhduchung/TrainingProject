    //
//  PopOver.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 8/31/11.
//  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
//

#import "PopOver.h"
#import "Utils.h"
#import "CustomerViewController.h"
#import "CustomerDetailsViewController.h"
#import	"CustomDetailsEdit.h"
#import "PoliciesEditViewController.h"
#import "PolicyDetailsViewController.h"
#import "PoliciesViewController.h"

@implementation PopOver

@synthesize sender;
@synthesize table;
@synthesize button;
@synthesize arrContent;

#pragma mark - View Lifecycle
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
	self.title = @" ";
	table.backgroundView = NO;
	UIBarButtonItem *cancelButton =
    [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh 
                                                 target:self 
                                                 action:nil];
	self.navigationItem.leftBarButtonItem = cancelButton;
	[cancelButton release];
	table.delegate = self;
	table.scrollEnabled = NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
  return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
  [super dealloc];
}

-(void)dismissPopover {
	[sender dismissPopOver];
}

#pragma mark - Table methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
  return [arrContent count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {    
  static NSString *CellIdentifier = @"Cell";    
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                   reuseIdentifier:CellIdentifier]
                autorelease];
  }
	cell.textLabel.text = [arrContent objectAtIndex:indexPath.row];
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  if ([sender isKindOfClass:[CustomerViewController class]]) {
    customEdit = APP_IPAD.customerEdit;
    customEdit.editMode = NO;
    customEdit.title = @"New Customer";
    
    if (indexPath.row == 0) {            			
      customEdit.isCorp = YES;		
    } else if (indexPath.row ==1) {		
      customEdit.isCorp = NO;
    }
    
    if (!customEdit.visible) {
      customerView = APP_IPAD.customerView;
      customerView.view.userInteractionEnabled = NO;
      customerDetails = APP_IPAD.customerDetail;
      @try {
        [customerDetails.navigationController pushViewController:customEdit
                                                        animated:YES];
      }
      @catch (NSException *exception) {
        [customerDetails.navigationController popToViewController:customEdit 
                                                         animated:YES];
      }
    } else {
      customEdit.customer = nil;
      [customEdit loadData];
    }
  } else if ([sender isKindOfClass:[PoliciesViewController class]]){
    policyEdit = APP_IPAD.policyEdit;
    if (indexPath.row == 0) {
      policyEdit.editMode = NO;
      policyEdit.isPolicy = YES;
      policyEdit.title = @"New Policy";	
    } else if (indexPath.row == 1) {
      policyEdit.editMode = NO;
      policyEdit.isPolicy = NO;
      policyEdit.title = @"New 3rd-Party Contract";		
    }
    if (!policyEdit.visible) {	
      policyView = APP_IPAD.policiesView;            
      policyDetail = APP_IPAD.policiesDetail;
      policyView.view.userInteractionEnabled = NO;
      @try {
        [policyDetail.navigationController pushViewController:policyEdit 
                                                     animated:YES];
      }
      @catch (NSException *exception) {
        [policyDetail.navigationController popToViewController:policyEdit 
                                                      animated:YES];
      }
    } else {
      policyEdit.data = nil;
      [policyEdit loadData];
    }
  }	
	[sender dismissPopOver];
}

@end
