  //
  //  CustomDetailsEdit.m
  //  QINS3
  //
  //  Created by Phạm Phi Phúc on 8/26/11.
  //  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
  //

#import "CustomDetailsEdit.h"
#import "CustomCell.h"
#import	"qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "CustomerDetailsViewController.h"
#import "CustomerViewController.h"
#import "Utils.h"
#import "CustomerEditPopOver.h"
#import "CustomerUtils.h"
#import "CountryUtils.h"
#import "qPeriorMobInsuranceDemo_CustomizingRegion.h"
#import "qPeriorMobInsuranceDemo_CustomizingCountry.h"
#import "qPeriorMobInsuranceDemo_CustomizingCustCorpRoles.h"
#import "qPeriorMobInsuranceDemo_CustomizingIndvCorpRoles.h"
#import "SUPObjectList.h"
#import "qPeriorMobInsuranceDemo_LocalKeyGenerator.h"

@implementation CustomDetailsEdit

@synthesize arrContactNumber;
@synthesize contact;
@synthesize customer;
@synthesize customerStored;
@synthesize arrData;
@synthesize table;
@synthesize image;
@synthesize txtFirstName;
@synthesize txtLastName;
@synthesize txtRole;
@synthesize txtStreet;
@synthesize txtNumber;
@synthesize txtPostalCode;
@synthesize txtCity;
@synthesize txtRegion;
@synthesize txtCountry;
@synthesize txtTel;
@synthesize txtMobile;
@synthesize txtFax;
@synthesize txtEmail;
@synthesize arrTextField;
@synthesize visible;
@synthesize editMode;
@synthesize popController;
@synthesize popOver;
@synthesize isCorp;
@synthesize isFiltered;
@synthesize customerUtils;
@synthesize dict;
@synthesize viewMoved;
@synthesize isPushed;
@synthesize corpRoles;
@synthesize indiRoles;

#pragma mark - View Lifecycle
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

  // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
  table.backgroundView.hidden = YES;
	UIBarButtonItem *saveButton = 
  [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave 
                                               target:self 
                                               action:@selector(saveData:)];
	self.navigationItem.rightBarButtonItem = saveButton;
	[saveButton release];
	self.title = @"Customer Details";
  
  listSize = 0;
  keyboardShown = NO;
  viewMoved = NO;
  regionEnable = NO;
  listSize = 0;
  
  customerUtils = APP_IPAD.customerUtils;
  country = APP_IPAD.country;
  
  corpRoles = [[qPeriorMobInsuranceDemo_CustomizingCustCorpRoles findAll]retain];
  indiRoles = [[qPeriorMobInsuranceDemo_CustomizingIndvCorpRoles findAll]retain];
  
  dict = [country getDictRegionsByCountries:[country getRegions]];
  popOver = [[CustomerEditPopOver alloc]init];
	popOver.sender = self;
	popController = [[UIPopoverController alloc] initWithContentViewController:popOver];
  
	isFiltered = NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
	return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewWillAppear:(BOOL)animated {
  visible = YES;
  if (![txtCountry.text isEqualToString:@""]) {
    regionEnable = YES;
  }
  [self loadData];
  UIToolbar *toolbar = [Utils getLeftButtons:self withMode:kToggleCancel];
  self.navigationItem.leftBarButtonItem = 
      [[UIBarButtonItem alloc]initWithCustomView:toolbar];
  [super viewWillAppear:YES];
}

- (void)viewDidAppear:(BOOL)animated {	
  [super viewDidAppear:animated];	
}

- (void)viewWillDisappear:(BOOL)animated {
	visible = NO;
  regionEnable = NO;    
  customer = nil;
  customerStored = nil;
	[super viewWillDisappear:animated];	
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
  [super dealloc];
}

#pragma mark - Table Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return [arrData count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	NSMutableArray *arrTemp = [arrData objectAtIndex:section];
	return [arrTemp count];	
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {	
    //CustomCell
	static NSString *CellIdentifier = @"Cell"; 
	CustomCell *cell = (CustomCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];	
	if (cell == nil) {
		NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
		for (id oneObject in nib)
			if ([oneObject isKindOfClass:[CustomCell class]])
				cell = (CustomCell *)oneObject;
	} else {
		UIView *view = nil;
		view = [cell.contentView viewWithTag:1];
		if (!view) {
			[view removeFromSuperview];
		}
	}
  NSMutableArray *section = [self.arrData objectAtIndex: indexPath.section];
  NSMutableDictionary *row = [section objectAtIndex:indexPath.row];
  cell.label.text = [row valueForKey:kSectionTitle];
	UITextField *textField = [row valueForKey:kFieldKey];
	cell.tag = [arrTextField indexOfObject:textField];
	if ([cell.label.text isEqualToString:@"Role"] 
          || [cell.label.text isEqualToString:@"Country"] 
          || [cell.label.text isEqualToString:@"Region"]) {
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	}
	[cell.contentView addSubview:textField];
	cell.backgroundColor = [UIColor colorWithRed:247.0/255.0 green: 247.0/255.0 blue: 247.0/255.0 alpha: 1.0];
	return cell;
} 

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  
	UITableViewCell *newCell = [self.table cellForRowAtIndexPath:indexPath];
  CGRect frame = CGRectMake(newCell.frame.origin.x+newCell.frame.size.width-45, 
                            newCell.frame.origin.y+kCellHeight-5, 
                            newCell.frame.size.width, 
                            newCell.frame.size.height);    
	cellIndex = indexPath;	
	[self.table numberOfRowsInSection:indexPath.section];
  
	if ([popController isPopoverVisible]) {
		[popController dismissPopoverAnimated:YES];
	} else {
		if (indexPath.row == [self.table numberOfRowsInSection:indexPath.section]-1 
          && indexPath.section == 0) {			
      popOver.arrContent = (isCorp) ? corpRoles : indiRoles;
      int size = [popOver.arrContent size];
      int height = 600;
      if (size <= 10) {
        height = size*40+80;
      }
      [popOver loadData];
      popController.popoverContentSize = CGSizeMake(300,height);
      [popController presentPopoverFromRect:frame 
                                     inView:self.view 
                   permittedArrowDirections:UIPopoverArrowDirectionRight 
                                   animated:NO];
    } else if (indexPath.row == [self.table numberOfRowsInSection:indexPath.section]-2 
                && indexPath.section == 1) {
      popOver.arrContent = [country getCountries];
      int size = [popOver.arrContent size];
      int height = 600;
      if (size <= 10) {
        height = size*40+80;
      }
      [popOver loadData];
      popController.popoverContentSize = CGSizeMake(300,height);            
      [popController presentPopoverFromRect:frame 
                                     inView:self.view 
                   permittedArrowDirections:UIPopoverArrowDirectionRight 
                                   animated:NO];
    } else if (indexPath.row == [self.table numberOfRowsInSection:indexPath.section]-1 
                && indexPath.section == 1) {            
      if (regionEnable) {
        NSString *stringCountry = [CustomerUtils getShortLocationName:txtCountry.text isRegion:NO];
        popOver.arrContent = [dict valueForKey:stringCountry];                
        int size = [popOver.arrContent size];
        int height = 600;
        if (size <= 10) {
          height = size*40+80;
        }
        [popOver loadData];
        popController.popoverContentSize = CGSizeMake(300,height);
        [popController presentPopoverFromRect:frame 
                                       inView:self.view 
                     permittedArrowDirections:UIPopoverArrowDirectionRight
                                     animated:NO];
      }
    }		
	}
}

#pragma mark - TextField Methods
- (BOOL)textField:(UITextField *)textField 
      shouldChangeCharactersInRange:(NSRange)range 
      replacementString:(NSString *)string {
  if (textField == txtPostalCode) {
    NSString *resultingString = [textField.text stringByReplacingCharactersInRange:range 
                                                                        withString:string];    
      // This allows backspace
    if ([resultingString length] == 0) {
      return true;
    }    
    
    int input;    
    NSScanner *scan = [NSScanner scannerWithString: resultingString]; 
    return [scan scanInt:&input] && [scan isAtEnd];
  }    
  
  if (textField == txtMobile || textField == txtTel || textField == txtFax) {
    if (string.length > 0) {
        // if textfield is blank, user can input "+" too
      NSString *format = textField.text.length > 0 ? @"[\\d]" : @"[\\d\\+]";
      NSPredicate *formatTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", format];
      if ([formatTest evaluateWithObject:string]) {
        NSString *text = textField.text;
        text = [text stringByAppendingString:string];
        textField.text = [customerUtils convertContactNumberDatabaseToDisplay:text];
        return NO;                               
      } else {
        return NO;
      }
    } else {
      if (textField.text.length > 1) {
        NSString *text = [textField.text substringToIndex:textField.text.length-1];
        textField.text = [customerUtils convertContactNumberDatabaseToDisplay:text];
      } else {
        textField.text = @"";
      }            
      return NO;
    }
  }
  
  return YES;
}

  // Move table up to prevent virtual keyboard cover the textfields
- (void)textFieldDidBeginEditing:(UITextField *)sender {
  activeTextField = sender;
	if (keyboardShown) {
    return;	
	}
	indexOfTextField = [arrTextField indexOfObject:activeTextField];
  if (indexOfTextField > 4) {
    CGRect frame = self.view.frame;
    frame.origin.y -= (indexOfTextField-4)*kCellHeight;
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:0.3];
    self.view.frame = frame;
    [UIView commitAnimations];		
    viewMoved = YES;
  }	
  keyboardShown = YES;
}

  // Move table down to original position after input text
- (void)textFieldDidEndEditing:(UITextField *)textField {
	activeTextField = nil;
	if (viewMoved) {
		CGRect frame = self.view.frame;
		frame.origin.y += (indexOfTextField-4)*kCellHeight;
		[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
		[UIView setAnimationDuration:0.3];
		self.view.frame = frame;
		[UIView commitAnimations];		
		viewMoved = NO;
	}
  keyboardShown = NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
  [textField resignFirstResponder];
  return YES;
}

- (void)dismissPopover {
  [self.popController dismissPopoverAnimated:YES];
}

#pragma mark - Load Data
  // create table sections
- (void)loadData {
	if (arrData == nil) {
		arrData = [[NSMutableArray alloc]init];
    arrContactNumber = [[NSMutableArray alloc]init];
	} else {
		[arrData removeAllObjects];
    [arrContactNumber removeAllObjects];
	}   
  
  if (customer != nil) {
    isCorp = [customer isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]? NO : YES;
  }    
  
	[arrData addObject:[self createNameData:isCorp]];
	[arrData addObject:[self createAddressData]];
	[arrData addObject:[self createContactData:isCorp]];
	[self setText];
	[self addTextFieldToArray];
	[self.table reloadData];
}

  // create section display name
- (NSMutableArray *)createNameData:(BOOL)isCorporate {
  NSMutableArray *arrName = [[NSMutableArray alloc]init];
  NSString *strName = isCorporate?[customer bpCorpName]:[customer bpIndFirstName];
  
  [arrName addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                      isCorporate?@"Name":@"First Name", kSectionTitle,
                      editMode?strName:@"", kValueKey,
                      self.txtFirstName, kFieldKey,
                      nil]];
  if (!isCorporate) {
    [arrName addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                        @"Last Name", kSectionTitle,
                        editMode?[customer bpIndLastName]:@"", kValueKey,
                        self.txtLastName, kFieldKey,
                        nil]];
  }
  [arrName addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                      @"Role", kSectionTitle,
                      editMode?[customer bpRole]:@"", kValueKey,
                      self.txtRole, kFieldKey,
                      nil]];
  return arrName;
}

  // create section display address
- (NSMutableArray *)createAddressData {
  NSMutableArray *arrAddress = [[NSMutableArray alloc]init];
  [arrAddress addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Street", kSectionTitle,
                         editMode?[customer bpAddrStreet]:@"", kValueKey,
                         self.txtStreet, kFieldKey,
                         nil]];
  [arrAddress addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Number", kSectionTitle,
                         editMode?[customer bpAddrHouseNo]:@"", kValueKey,
                         self.txtNumber, kFieldKey,
                         nil]];
  [arrAddress addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Postal Code", kSectionTitle,
                         editMode?[customer bpAddrPostalCode]:@"", kValueKey,
                         self.txtPostalCode, kFieldKey,
                         nil]];
  [arrAddress addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"City", kSectionTitle,
                         editMode?[customer bpAddrCity]:@"", kValueKey,
                         self.txtCity, kFieldKey,
                         nil]];
  [arrAddress addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Country", kSectionTitle,
                         editMode?[customer bpAddrCountry]:@"", kValueKey,
                         self.txtCountry, kFieldKey,
                         nil]];
  [arrAddress addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Region", kSectionTitle,
                         editMode?[customer bpAddrRegion]:@"", kValueKey,
                         self.txtRegion, kFieldKey,
                         nil]];
  return arrAddress;
}

  // create section display contact info
- (NSMutableArray *)createContactData:(BOOL)isCorporate {
  NSMutableArray *arrContact = [[NSMutableArray alloc]init];
  [arrContact addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                           @"Telephone", kSectionTitle,
                           editMode?[customerUtils convertContactNumberDatabaseToDisplay:[customer bpComTelephone]]:@"", kValueKey,
                           self.txtTel, kFieldKey,
                           nil]];
  
  if (!isCorporate) {
    [arrContact addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                           @"Mobile", kSectionTitle,
                           editMode?[customerUtils convertContactNumberDatabaseToDisplay:[customer bpComMobile]]:@"", kValueKey,
                           self.txtMobile, kFieldKey,
                           nil]];
    
  }    
  [arrContact addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Fax", kSectionTitle,
                         editMode?[customerUtils convertContactNumberDatabaseToDisplay:[customer bpComFax]]:@"", kValueKey,
                         self.txtFax, kFieldKey,
                         nil]];
  
  [arrContact addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                         @"Email", kSectionTitle,
                         editMode?[customer bpComEmail]:@"", kValueKey,
                         self.txtEmail, kFieldKey,
                         nil]];
  return arrContact;
}

- (void)setText {
  if ([arrData count] >0) {        
    txtFirstName.text = [[[arrData objectAtIndex:0]objectAtIndex:0]valueForKey:kValueKey];
    txtLastName.text = [[[arrData objectAtIndex:0]objectAtIndex:1]valueForKey:kValueKey];
    txtStreet.text = [[[arrData objectAtIndex:1]objectAtIndex:0]valueForKey:kValueKey];
    txtNumber.text = [[[arrData objectAtIndex:1]objectAtIndex:1]valueForKey:kValueKey];
    txtPostalCode.text = [[[arrData objectAtIndex:1]objectAtIndex:2]valueForKey:kValueKey];
    txtCity.text = [[[arrData objectAtIndex:1]objectAtIndex:3]valueForKey:kValueKey];
    txtCountry.text = [CustomerUtils getFullLocationName:[[[arrData objectAtIndex:1]objectAtIndex:4]valueForKey:kValueKey] isRegion:NO];
    NSString *region = [NSString stringWithFormat:@"%@ %@", 
                        [[[arrData objectAtIndex:1]objectAtIndex:5]valueForKey:kValueKey], 
                        [[[arrData objectAtIndex:1]objectAtIndex:4]valueForKey:kValueKey]];
    txtRegion.text = [CustomerUtils getFullLocationName:region isRegion:YES];
    txtTel.text = [[[arrData objectAtIndex:2]objectAtIndex:0]valueForKey:kValueKey];
      //txtMobile.text = [[[arrData objectAtIndex:2]objectAtIndex:1]valueForKey:kValueKey];
    if (!isCorp) {
      txtMobile.text = [[[arrData objectAtIndex:2]objectAtIndex:1]valueForKey:kValueKey];
      txtRole.text = [CustomerUtils getFullRole:[[[arrData objectAtIndex:0]objectAtIndex:2]valueForKey:kValueKey] isCorporate:NO];
      txtFax.text = [[[arrData objectAtIndex:2]objectAtIndex:2]valueForKey:kValueKey];
      txtEmail.text = [[[arrData objectAtIndex:2]objectAtIndex:2]valueForKey:kValueKey];
    } else {
      txtRole.text = [CustomerUtils getFullRole:[[[arrData objectAtIndex:0]objectAtIndex:1]valueForKey:kValueKey] isCorporate:YES];
      txtFax.text = [[[arrData objectAtIndex:2]objectAtIndex:1]valueForKey:kValueKey];
      txtEmail.text = [[[arrData objectAtIndex:2]objectAtIndex:2]valueForKey:kValueKey];
    }
  }
}

- (void)addTextFieldToArray {
	[arrTextField removeAllObjects];
	if (!isCorp) {
    arrTextField = [[NSMutableArray alloc]init];
    [arrTextField addObject:txtFirstName];
    [arrTextField addObject:txtLastName];
    [arrTextField addObject:txtRole];
    [arrTextField addObject:txtStreet];
    [arrTextField addObject:txtNumber];
    [arrTextField addObject:txtPostalCode];
    [arrTextField addObject:txtCity];
    [arrTextField addObject:txtCountry];
    [arrTextField addObject:txtRegion];
    [arrTextField addObject:txtTel];
    [arrTextField addObject:txtMobile];
    [arrTextField addObject:txtFax];
    [arrTextField addObject:txtEmail];
	} else {
    arrTextField = [[NSMutableArray alloc]init];
    [arrTextField addObject:txtFirstName];
    [arrTextField addObject:txtRole];
    [arrTextField addObject:txtStreet];
    [arrTextField addObject:txtNumber];
    [arrTextField addObject:txtPostalCode];
    [arrTextField addObject:txtCity];
    [arrTextField addObject:txtCountry];
    [arrTextField addObject:txtRegion];
    [arrTextField addObject:txtTel];
    [arrTextField addObject:txtFax];
    [arrTextField addObject:txtEmail];
	}
}

#pragma mark - Save Data
  // create or update customer to database 
- (IBAction)saveData:(id)sender {
  [activeTextField resignFirstResponder];
  if ([self validate]) {
    id cust;
    regionEnable = NO;
    visible = NO;
    CustomerDetailsViewController *customerDetails = APP_IPAD.customerDetail;
    CustomerViewController *customerView = APP_IPAD.customerView;
    
    if (!isCorp) {
      qPeriorMobInsuranceDemo_CustomerIndividual *individual = 
          [[qPeriorMobInsuranceDemo_CustomerIndividual alloc]init];
      
      if (editMode) {
          //update to database
        individual = [customer retain];
        [self setCustomerData:individual isCorporate:NO];
        [individual update];
        cust = individual;
      } else {
          //create on database
        [self setCustomerData:individual isCorporate:NO];
        [individual create];
        cust = individual;
      }		
    } else {
      qPeriorMobInsuranceDemo_CustomerCorporate *corporate = 
          [[qPeriorMobInsuranceDemo_CustomerCorporate alloc]init];
      if (editMode) {
          //update to database
        corporate = [customer retain];
        [self setCustomerData:corporate isCorporate:YES];
        [corporate update];
        cust = corporate;
      } else {
          //create on database
        [self setCustomerData:corporate isCorporate:YES];
        [corporate create];
        cust = corporate;
      }	
    }     
    customerView.data = [customerUtils getAllCustomer];
    customerView.arrData = [customerView.data copy];
    customerDetails.customer = cust;
    customerView.customerNewID = [cust bpNumber];
    [customerView loadData];
    [customerDetails loadData];
    [self.navigationController popViewControllerAnimated:YES];       
  }
}

- (void) getDataFromPopOver:(id)sender {
  [self.popController dismissPopoverAnimated:YES];
	if ([popOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingCountry class]]) {
    qPeriorMobInsuranceDemo_CustomizingCountry *acountry = popOver.returnData;
    txtCountry.text = acountry.customizeAddrCountryDescr;
    regionEnable = YES;
    SUPObjectList *lstRegions = [dict valueForKey:[CustomerUtils getShortLocationName:txtCountry.text isRegion:NO]];
    BOOL found = NO;
    int i = 0;
    while (i < [lstRegions size] && !found) {
      qPeriorMobInsuranceDemo_CustomizingRegion *aregion= [lstRegions item:i++];
      if ([aregion.customizeAddrRegionDescr isEqualToString:txtRegion.text]) {
        found = YES;
      }
    }
    if (!found) {
      txtRegion.text = @"";
    }
  } else if ([popOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingRegion class]]) {
    qPeriorMobInsuranceDemo_CustomizingRegion *aregion = popOver.returnData;
    txtRegion.text = aregion.customizeAddrRegionDescr;
  } else if ([popOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingCustCorpRoles class]]){
    qPeriorMobInsuranceDemo_CustomizingCustCorpRoles *role = popOver.returnData;
    txtRole.text = role.customizeCustRoleDescr;
  } else if ([popOver.returnData isKindOfClass:[qPeriorMobInsuranceDemo_CustomizingIndvCorpRoles class]]){
    qPeriorMobInsuranceDemo_CustomizingIndvCorpRoles *role = popOver.returnData;
    txtRole.text = role.customizeCustRoleDescr;
  }
}

- (IBAction)cancel:(id)sender {
  [activeTextField resignFirstResponder];
  regionEnable = NO;
  if (editMode) {
		customer = nil;
		visible = NO;
		[self.navigationController popViewControllerAnimated:YES];
	} else {
		if (!customer && customerStored) {
      customer = customerStored;
      editMode = YES;
			[self loadData];		
			self.title = @"Customer Details";
		} else {
			visible = NO;
			[self.navigationController popViewControllerAnimated:YES];
		}		
	}
}

- (void)setCustomerData:(id)cust isCorporate:(BOOL)isCorporate {
  if (isCorporate) {
    [cust setBpCorpName:txtFirstName.text]; 
    [cust setBpRole:[CustomerUtils getShortRole:txtRole.text isCorporate:YES]];
  } else {
    [cust setBpIndFirstName:txtFirstName.text];
    [cust setBpIndLastName:txtLastName.text];
    [cust setBpComMobile:txtMobile.text];
    [cust setBpRole:[CustomerUtils getShortRole:txtRole.text isCorporate:NO]];
  }
  if ([cust bpNumber] == nil) {
    int64_t generatedID = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateId];
    [cust setBpNumber:[NSString stringWithFormat:@"%ld",generatedID]];
  }
  [cust setBpAddrStreet:txtStreet.text];
  [cust setBpAddrHouseNo:txtNumber.text];
  [cust setBpAddrPostalCode:txtPostalCode.text];
  [cust setBpAddrCity:txtCity.text];
  [cust setBpAddrCountry:[CustomerUtils getShortLocationName:txtCountry.text 
                                                    isRegion:NO]];
  [cust setBpAddrRegion:[CustomerUtils getShortLocationName:txtRegion.text 
                                                   isRegion:YES]];
  
  [cust setBpComTelephone:txtTel.text];
  [cust setBpComFax:txtFax.text];
  [cust setBpComEmail:txtEmail.text];
}

- (BOOL)showAlert:(NSString *)string {
  UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" 
                                                 message:string 
                                                delegate:self 
                                       cancelButtonTitle:@"OK" 
                                       otherButtonTitles:nil];
  [alert show];
  [alert release];
  return NO;
}

- (BOOL)validate {
  NSString *firstChar = @"[a-zA-Z]{1}";
  NSPredicate *formatTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", firstChar];
  NSCharacterSet *charsSet = [NSCharacterSet whitespaceCharacterSet];  
  if (!isCorp) {
    if ([[txtFirstName.text stringByTrimmingCharactersInSet:charsSet] length] == 0) {        
      return [self showAlert:@"First Name cannot be blank."];
    }
    if (![formatTest evaluateWithObject:[txtFirstName.text substringToIndex:1]]) {
      return [self showAlert:@"First Name must be started by a character."];
    }
    if ([txtFirstName.text length] > 40) {
      return [self showAlert:@"First Name cannot be longer than 160 characters."];
    }    
    
    if ([[txtLastName.text stringByTrimmingCharactersInSet:charsSet] length] == 0) {
      return [self showAlert:@"Last Name cannot be blank."];
    }
    if (![formatTest evaluateWithObject:[txtLastName.text substringToIndex:1]]) {
      return [self showAlert:@"Last Name must be started by a character."];
    }
    if ([txtLastName.text length] > 40) {
      return [self showAlert:@"Last Name cannot longer than 40 characters."];
    }
  } else {
    if ([[txtFirstName.text stringByTrimmingCharactersInSet:charsSet] length] == 0) {        
      return [self showAlert:@"Name cannot be blank."];
    }
    if (![formatTest evaluateWithObject:[txtFirstName.text substringToIndex:1]]) {
      return [self showAlert:@"Name must be started by a character."];
    }
    if ([txtFirstName.text length] > 160) {
      return [self showAlert:@"Name cannot be longer than 160 characters."];
    }
  }
  
  if ([txtRole.text length] == 0) {
    return [self showAlert:@"You must select a role."];
  }
  if ([[txtStreet.text stringByTrimmingCharactersInSet:charsSet] length] == 0) {
    return [self showAlert:@"Street cannot be blank."];
  }
  if ([txtStreet.text length] > 60) {
    return [self showAlert:@"Street cannot longer than 60 characters."];
  }
  if ([[txtPostalCode.text stringByTrimmingCharactersInSet:charsSet] length] == 0) {
    return [self showAlert:@"Postal Code cannot be blank."];
  }
  NSString *stringCountry = [CustomerUtils getShortLocationName:txtCountry.text isRegion:NO];
  if ([stringCountry isEqualToString:@"CH"] && txtPostalCode.text.length != 4) {
    return [self showAlert:@"Postal Code must be 4 digits."];
  } else {
    if ([txtPostalCode.text length] > 10) {
      return [self showAlert:@"Postal Code cannot longer than 10 characters."];
    }
  }  
  if ([[txtCity.text stringByTrimmingCharactersInSet:charsSet] length] == 0) {
    return [self showAlert:@"City cannot be blank."];
  }
  if ([txtCity.text length] > 40) {
    return [self showAlert:@"City cannot longer than 40 characters."];
  }
  if ([txtCountry.text length] == 0) {
    return [self showAlert:@"You must select a country."];
  }
  if ([txtRegion.text length] == 0) {
    return [self showAlert:@"You must select a region."];
  }
  if ([txtEmail.text length] > 241) {
    return [self showAlert:@"Email cannot longer than 241 characters."];
  }
  if ([[txtEmail.text stringByTrimmingCharactersInSet:charsSet] length] != 0 
        && ![self NSStringIsValidEmail:txtEmail.text]) {
    return [self showAlert:@"Invalid email."];
  }
  
  return YES;
}

  // check if email is valid with 2 format, Strict and Lax
  // to check with Lax format, just set stricterFilter = NO
-(BOOL) NSStringIsValidEmail:(NSString *)checkString {
  BOOL stricterFilter = YES;
  NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
  NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
  NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
  NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
  return [emailTest evaluateWithObject:checkString];
}

#pragma mark - Init TextFields

- (UITextField *)txtFirstName {
	if (txtFirstName == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtFirstName = [[UITextField alloc] initWithFrame:frame];
		txtFirstName.borderStyle = UITextBorderStyleNone;
		txtFirstName.font = [UIFont systemFontOfSize:17];
		txtFirstName.backgroundColor = [UIColor clearColor];
		txtFirstName.keyboardType = UIKeyboardTypeDefault;
		txtFirstName.returnKeyType = UIReturnKeyDone;	
		txtFirstName.tag = 1;
		txtFirstName.delegate = self;		
	}
	return txtFirstName;
}

- (UITextField *)txtLastName {
	if (txtLastName == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtLastName = [[UITextField alloc] initWithFrame:frame];
		txtLastName.borderStyle = UITextBorderStyleNone;
		txtLastName.font = [UIFont systemFontOfSize:17];
		txtLastName.backgroundColor = [UIColor clearColor];
		txtLastName.keyboardType = UIKeyboardTypeDefault;
		txtLastName.returnKeyType = UIReturnKeyDone;	
		txtLastName.tag = 1;
		txtLastName.delegate = self;		
	}
	return txtLastName;
}

- (UITextField *)txtRole {
	if (txtRole == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtRole = [[UITextField alloc] initWithFrame:frame];
		txtRole.borderStyle = UITextBorderStyleNone;
		txtRole.font = [UIFont systemFontOfSize:17];
		txtRole.backgroundColor = [UIColor clearColor];
		txtRole.keyboardType = UIKeyboardTypeDefault;
		txtRole.returnKeyType = UIReturnKeyDone;	
		txtRole.tag = 1;
		txtRole.delegate = self;
		txtRole.userInteractionEnabled = NO;
	}
	return txtRole;
}

- (UITextField *)txtStreet {
	if (txtStreet == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtStreet = [[UITextField alloc] initWithFrame:frame];
		txtStreet.borderStyle = UITextBorderStyleNone;
		txtStreet.font = [UIFont systemFontOfSize:17];
		txtStreet.backgroundColor = [UIColor clearColor];
		txtStreet.keyboardType = UIKeyboardTypeDefault;
		txtStreet.returnKeyType = UIReturnKeyDone;	
		txtStreet.tag = 1;
		txtStreet.delegate = self;		
	}
	return txtStreet;
}

- (UITextField *)txtNumber {
	if (txtNumber == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtNumber = [[UITextField alloc] initWithFrame:frame];
		txtNumber.borderStyle = UITextBorderStyleNone;
		txtNumber.font = [UIFont systemFontOfSize:17];
		txtNumber.backgroundColor = [UIColor clearColor];
		txtNumber.keyboardType = UIKeyboardTypeDefault;
		txtNumber.returnKeyType = UIReturnKeyDone;	
		txtNumber.tag = 1;
		txtNumber.delegate = self;
    txtNumber.keyboardType = UIKeyboardTypeNumberPad;
	}
	return txtNumber;
}

- (UITextField *)txtPostalCode {
	if (txtPostalCode == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtPostalCode = [[UITextField alloc] initWithFrame:frame];
		txtPostalCode.borderStyle = UITextBorderStyleNone;
		txtPostalCode.font = [UIFont systemFontOfSize:17];
		txtPostalCode.backgroundColor = [UIColor clearColor];
		txtPostalCode.keyboardType = UIKeyboardTypeDefault;
		txtPostalCode.returnKeyType = UIReturnKeyDone;	
		txtPostalCode.tag = 1;
		txtPostalCode.delegate = self;	
    txtPostalCode.keyboardType = UIKeyboardTypeNumberPad;
	}
	return txtPostalCode;
}

- (UITextField *)txtCity {
	if (txtCity == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtCity = [[UITextField alloc] initWithFrame:frame];
		txtCity.borderStyle = UITextBorderStyleNone;
		txtCity.font = [UIFont systemFontOfSize:17];
		txtCity.backgroundColor = [UIColor clearColor];
		txtCity.keyboardType = UIKeyboardTypeDefault;
		txtCity.returnKeyType = UIReturnKeyDone;	
		txtCity.tag = 1;
		txtCity.delegate = self;		
	}
	return txtCity;
}

- (UITextField *)txtRegion {
	if (txtRegion == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtRegion = [[UITextField alloc] initWithFrame:frame];
		txtRegion.borderStyle = UITextBorderStyleNone;
		txtRegion.font = [UIFont systemFontOfSize:17];
		txtRegion.backgroundColor = [UIColor clearColor];
		txtRegion.keyboardType = UIKeyboardTypeDefault;
		txtRegion.returnKeyType = UIReturnKeyDone;	
		txtRegion.tag = 1;
		txtRegion.delegate = self;		
    txtRegion.userInteractionEnabled = NO;
	}
	return txtRegion;
}

- (UITextField *)txtCountry {
	if (txtCountry == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtCountry = [[UITextField alloc] initWithFrame:frame];
		txtCountry.borderStyle = UITextBorderStyleNone;
		txtCountry.font = [UIFont systemFontOfSize:17];
		txtCountry.backgroundColor = [UIColor clearColor];
		txtCountry.keyboardType = UIKeyboardTypeDefault;
		txtCountry.returnKeyType = UIReturnKeyDone;	
		txtCountry.tag = 1;
		txtCountry.delegate = self;	
		txtCountry.userInteractionEnabled = NO;
	}
	return txtCountry;
}

- (UITextField *)txtTel {
	if (txtTel == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtTel = [[UITextField alloc] initWithFrame:frame];
		txtTel.borderStyle = UITextBorderStyleNone;
		txtTel.font = [UIFont systemFontOfSize:17];
		txtTel.backgroundColor = [UIColor clearColor];
		txtTel.keyboardType = UIKeyboardTypeDefault;
		txtTel.returnKeyType = UIReturnKeyDone;	
		txtTel.tag = 1;
		txtTel.delegate = self;		
    txtTel.keyboardType = UIKeyboardTypeNumberPad;
    txtTel.text = @"+00 (00) 00000000";
	}
	return txtTel;
}

- (UITextField *)txtMobile {
	if (txtMobile == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtMobile = [[UITextField alloc] initWithFrame:frame];
		txtMobile.borderStyle = UITextBorderStyleNone;
		txtMobile.font = [UIFont systemFontOfSize:17];
		txtMobile.backgroundColor = [UIColor clearColor];
		txtMobile.keyboardType = UIKeyboardTypeDefault;
		txtMobile.returnKeyType = UIReturnKeyDone;	
		txtMobile.tag = 1;
		txtMobile.delegate = self;	
    txtMobile.keyboardType = UIKeyboardTypeNumberPad;
	}
	return txtMobile;
}

- (UITextField *)txtFax {
	if (txtFax == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtFax = [[UITextField alloc] initWithFrame:frame];
		txtFax.borderStyle = UITextBorderStyleNone;
		txtFax.font = [UIFont systemFontOfSize:17];
		txtFax.backgroundColor = [UIColor clearColor];		
		txtFax.keyboardType = UIKeyboardTypeDefault;
		txtFax.returnKeyType = UIReturnKeyDone;		
		txtFax.tag = 1;
		txtFax.delegate = self;	
    txtFax.keyboardType = UIKeyboardTypeNumberPad;
	}
	return txtFax;
}

- (UITextField *)txtEmail {
	if (txtEmail == nil) {
		CGRect frame = CGRectMake(130,10,453,30);
		txtEmail = [[UITextField alloc] initWithFrame:frame];
		txtEmail.borderStyle = UITextBorderStyleNone;
		txtEmail.font = [UIFont systemFontOfSize:17];
		txtEmail.backgroundColor = [UIColor clearColor];		
		txtEmail.keyboardType = UIKeyboardTypeDefault;
		txtEmail.returnKeyType = UIReturnKeyDone;
		txtEmail.tag = 1;
		txtEmail.delegate = self;
	}
	return txtEmail;
}

@end
