  //
  //  PieChart.m
  //
  //  Created by Dain on 7/23/10.
  //  Copyright 2010 Dain Kaplan. All rights reserved.
  //

#import <QuartzCore/QuartzCore.h>
#import "PieChartView.h"

@interface PieChartItem : NSObject {
	PieChartItemColor _color;
	float _value;
}

@property (nonatomic, assign) PieChartItemColor color;
@property (nonatomic, assign) float value;

@end


@implementation PieChartItem

- (id)init {	
  if (self == [super init]) {
		_value = 0.0;
	}
	return self;
}

@synthesize color = _color;
@synthesize value = _value;

@end


@interface PieChartView()
  // Private interface
- (UIImage *)maskImage:(UIImage *)image withMask:(UIImage *)maskImage;
- (UIImage *)createCircleMaskUsingCenterPoint:(CGPoint)point andRadius:(float)radius;
- (UIImage *)createGradientImageUsingRect:(CGRect)rect;
@end

@implementation PieChartView


- (id)initWithFrame:(CGRect)aRect {	
  if (self == [super initWithFrame:aRect]) {
		_gradientFillColor = PieChartItemColorMake(0.0, 0.0, 0.0, 0.4);
		_gradientStart = 0.3;
		_gradientEnd = 0.3;
		self.backgroundColor = [UIColor clearColor];
	}
	return self;
}

  // XXX: In the case this view is being loaded from a NIB/XIB (and not programmatically)
  // initWithCoder is called instead of initWithFrame:
- (id)initWithCoder:(NSCoder *)decoder {	
  if (self == [super initWithCoder:decoder]) {
		_gradientFillColor = PieChartItemColorMake(0.0, 0.0, 0.0, 0.4);
		_gradientStart = 0.3;
		_gradientEnd = 0.3;
		self.backgroundColor = [UIColor clearColor];
	}
	return self;
}

- (void)clearItems {
	if(_pieItems) {
		[_pieItems removeAllObjects];	
	}	
	_sum = 0.0;
}

- (void)addItemValue:(float)value 
           withColor:(PieChartItemColor)color 
            withName:(NSString *)name {
	PieChartItem *item = [[PieChartItem alloc] init];
	item.value = value;
	item.color = color;
  
	if( !_pieItems ) {
		_pieItems = [[NSMutableArray alloc] initWithCapacity:3];
	}
	if (!_pieName) {
		_pieName = [[NSMutableArray alloc] init];
	}
	
	[_pieItems addObject:item];
	[_pieName addObject:name];
	
	[item release];
	
	_sum += value;
}

- (void)setNoDataFillColorRed:(float)r green:(float)g blue:(float)b {
	_noDataFillColor = PieChartItemColorMake(r, g, b, 1.0);
}

- (void)setNoDataFillColor:(PieChartItemColor)color {
	_noDataFillColor = color;
}

- (void)setGradientFillColorRed:(float)r green:(float)g blue:(float)b {
	_gradientFillColor = PieChartItemColorMake(r, g, b, 0.4);
}

- (void)setGradientFillColor:(PieChartItemColor)color {
	_gradientFillColor = color;
}

- (void)setGradientFillStart:(float)start andEnd:(float)end {
	_gradientStart = start;
	_gradientEnd = end;
}

  // Only override drawRect: if you perform custom drawing.
  // An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
	float startDeg = 0;
	float endDeg = 0;
	
	int x = self.center.x;
	int y = self.center.y;
  int r = 0;
  if (self.bounds.size.width > self.bounds.size.height) {
    r = self.bounds.size.height / 2 * 0.8;
  } else {
    r = self.bounds.size.width / 2 * 0.8;
  }
	
	CGContextRef ctx = UIGraphicsGetCurrentContext();
	CGContextSetRGBStrokeColor(ctx, 0.0, 0.0, 0.0, 0.4);
  float a =0.0;
  if ([_pieItems count] != 0) {
    a = 2.0;
  }
	CGContextSetLineWidth(ctx, a);
  
  CGContextMoveToPoint(ctx, x, y);
  CGContextAddLineToPoint(ctx, x, y-r);
  CGContextClosePath(ctx);
  CGContextFillPath(ctx);
  CGContextStrokePath(ctx);
    // Draw a thin line around the circle
	CGContextAddArc(ctx, x, y, r, 0.0, 360.0*M_PI/180.0, 0);
	CGContextClosePath(ctx);
	CGContextDrawPath(ctx, kCGPathStroke);
  
    // Loop through all the values and draw the graph
	startDeg = 0;
	
	NSUInteger idx = 0;
	
	CGAffineTransform xform = CGAffineTransformMake(1, 0, 0, -1, 0, 0);
	CGContextSetTextMatrix(ctx, xform);
	
	for( idx = 0; idx < [_pieItems count]; idx++ ) {
		
		PieChartItem *item = [_pieItems objectAtIndex:idx];
		
		PieChartItemColor color = item.color;
		float currentValue = item.value;
		
		float theta = (360.0 * (currentValue/_sum));
		
		if( theta > 0.0 ) {
			endDeg += theta;
			beginDeg = startDeg;
			
			if( startDeg != endDeg ) {
				CGContextSetRGBFillColor(ctx, color.red, color.green, color.blue, color.alpha );
				
				CGContextMoveToPoint(ctx, x, y);
				CGContextAddArc(ctx, x, y, r, (startDeg-90)*M_PI/180.0, (endDeg-90)*M_PI/180.0, 0);
				CGContextClosePath(ctx);
				CGContextFillPath(ctx);
				
				CGContextSetFillColorWithColor(ctx, [UIColor blackColor].CGColor);
				NSString *foo = [_pieName objectAtIndex:idx];
				const char *text = [foo UTF8String];
				CGContextSelectFont(ctx, "Arial", 13, kCGEncodingMacRoman);
				
				float xPoint = 0;
				float yPoint = 0;
				float degree = (endDeg - startDeg - 180)/2;
				
				xPoint = (4*r/5)*cos((beginDeg + degree)*M_PI/180);
				yPoint = (4*r/5)*sin((beginDeg + degree)*M_PI/180);
				
				CGContextShowTextAtPoint(ctx,x+xPoint-10,y+yPoint,text, strlen(text));
          //CGContextShowTextAtPoint(ctx,xPoint,yPoint,text, strlen(text));
				CGContextDrawPath(ctx, kCGPathStroke);
				CGAffineTransform xform = CGAffineTransformMake(1, 0, 0, -1, 0, 0);
				CGContextSetTextMatrix(ctx, xform);
				
			}
		}
		
		startDeg = endDeg;
	}
	
    // Draw the remaining portion as a no-data-fill color, though there should never be one. (current code doesn't allow it)
	if( endDeg < 360.0 ) {
		
		startDeg = endDeg;
		endDeg = 360.0;
		
		if( startDeg != endDeg ) {
			CGContextSetRGBFillColor(ctx, 
                               _noDataFillColor.red, 
                               _noDataFillColor.green, 
                               _noDataFillColor.blue, 
                               _noDataFillColor.alpha );
			CGContextMoveToPoint(ctx, x, y);
			CGContextAddArc(ctx, x, y, r, (startDeg-90)*M_PI/180.0, (endDeg-90)*M_PI/180.0, 0);
			CGContextClosePath(ctx);
			CGContextFillPath(ctx);
		}	
	}
  
  if ([_pieItems count] != 0) {
    CGContextSetLineWidth(ctx, 0.2);
    CGContextMoveToPoint(ctx, x, y);
    CGContextAddLineToPoint(ctx, x, y-r);
    CGContextClosePath(ctx);
    CGContextStrokePath(ctx);
    
    CGContextSetRGBFillColor(ctx, 1, 1, 1, 1);
    CGContextAddArc(ctx, x, y, r*0.45, 0, 360.0, 0);        
    CGContextFillPath(ctx);        
    
    CGContextSetLineWidth(ctx, 0.2);
    CGContextSetRGBFillColor(ctx, 0, 0, 0, 1);
    CGContextShowTextAtPoint(ctx,
                             x-30,
                             y-5,
                             [@"Customer" UTF8String],
                             strlen([@"Customer" UTF8String]));
    CGContextShowTextAtPoint(ctx,
                             x-25,
                             y+15,
                             [@"Portfolio" UTF8String],
                             strlen([@"Portfolio" UTF8String]));
    CGContextAddArc(ctx, x, y, r*0.45, 0, 360.0, 0);        
    CGContextStrokePath(ctx);
	}
   
	self.layer.shadowRadius = 00;
	self.layer.shadowColor = [UIColor blackColor].CGColor;
	self.layer.shadowOpacity = 1.0;
	self.layer.shadowOffset = CGSizeMake(0.0, 0.0);
	
}
 
- (UIImage *)createCircleMaskUsingCenterPoint:(CGPoint)point 
                                    andRadius:(float)radius {
	UIGraphicsBeginImageContext( self.bounds.size );
	CGContextRef ctx2 = UIGraphicsGetCurrentContext();
	CGContextSetRGBFillColor(ctx2, 1.0, 1.0, 1.0, 1.0 );
	CGContextFillRect(ctx2, self.bounds);
	CGContextSetRGBFillColor(ctx2, 0.0, 0.0, 0.0, 1.0 );
	CGContextMoveToPoint(ctx2, point.x, point.y);
	CGContextAddArc(ctx2, point.x, point.y, radius, 0.0, (360.0)*M_PI/180.0, 0);
	CGContextClosePath(ctx2);
	CGContextFillPath(ctx2);
	UIImage *maskImage = [[UIGraphicsGetImageFromCurrentImageContext() retain] autorelease];
	UIGraphicsPopContext();
	
	return maskImage;
}

// Shout out to: http://stackoverflow.com/questions/422066/gradients-on-uiview-and-uilabels-on-iphone
- (UIImage *)createGradientImageUsingRect:(CGRect)rect {
	UIGraphicsBeginImageContext( rect.size );
	CGContextRef ctx3 = UIGraphicsGetCurrentContext();
	
	size_t locationsCount = 2;
  CGFloat locations[2] = { 1.0-_gradientStart, 1.0-_gradientEnd };
  CGFloat components[8] = { /* loc 2 */ 0.0, 0.0, 0.0, 0.0, /* loc 1 */
                            _gradientFillColor.red, 
                            _gradientFillColor.green, 
                            _gradientFillColor.blue, 
                            _gradientFillColor.alpha };
	
  CGColorSpaceRef rgbColorspace = CGColorSpaceCreateDeviceRGB();
	CGGradientRef gradient = CGGradientCreateWithColorComponents(rgbColorspace, 
                                                               components, 
                                                               locations, 
                                                               locationsCount);
	
  CGRect currentBounds = rect;
  CGPoint topCenterPoint = CGPointMake(CGRectGetMidX(currentBounds), CGRectGetMinY(currentBounds));
  CGPoint bottomCenterPoint = CGPointMake(CGRectGetMidX(currentBounds), CGRectGetMaxY(currentBounds));
  CGContextDrawLinearGradient(ctx3, gradient, topCenterPoint, bottomCenterPoint, 0);
	
  CGGradientRelease(gradient);
  CGColorSpaceRelease(rgbColorspace); 
	UIImage *gradientImage = [[UIGraphicsGetImageFromCurrentImageContext() retain] autorelease];
	UIGraphicsPopContext();
	
	return gradientImage;
}

  // Masks one image with another
  // Shout out to: http://iphonedevelopertips.com/cocoa/how-to-mask-an-image.html
- (UIImage *) maskImage:(UIImage *)image withMask:(UIImage *)maskImage {
	
	CGImageRef maskRef = maskImage.CGImage; 
	
	CGImageRef mask = CGImageMaskCreate(CGImageGetWidth(maskRef),
                                      CGImageGetHeight(maskRef),
                                      CGImageGetBitsPerComponent(maskRef),
                                      CGImageGetBitsPerPixel(maskRef),
                                      CGImageGetBytesPerRow(maskRef),
                                      CGImageGetDataProvider(maskRef), NULL, false);
	
	CGImageRef masked = CGImageCreateWithMask([image CGImage], mask);
	UIImage *ret = [UIImage imageWithCGImage:masked];
	CGImageRelease(masked);
	CGImageRelease(mask);
	return ret;	
}

- (void)dealloc {
	[_pieItems release];
  [super dealloc];
}

@end
