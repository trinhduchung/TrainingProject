//
//  PopOver.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 8/31/11.
//  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomerViewController.h"
#import "CustomerDetailsViewController.h"
#import "CustomDetailsEdit.h"
#import "PoliciesViewController.h"
#import "PolicyDetailsViewController.h"
#import "PoliciesEditViewController.h"

@interface PopOver : UIViewController <UITableViewDelegate, UITableViewDataSource>{
  id sender;
	IBOutlet UITableView *table;
	IBOutlet UIBarButtonItem *button;
	NSMutableArray *arrContent;
	CustomerViewController *customerView;
	CustomerDetailsViewController *customerDetails;
	CustomDetailsEdit *customEdit;
  PoliciesViewController *policyView;
  PoliciesEditViewController *policyEdit;
  PolicyDetailsViewController *policyDetail;
}

@property (nonatomic, retain) id sender;
@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *button;
@property (nonatomic, retain) NSMutableArray *arrContent;

@end
