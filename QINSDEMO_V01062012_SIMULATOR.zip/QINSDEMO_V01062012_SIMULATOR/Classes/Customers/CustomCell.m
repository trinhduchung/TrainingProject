    //
//  CustomCell.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 8/26/11.
//  Copyright 2011 ORIENT SOFTWARE DEVELOPMENT. All rights reserved.
//

#import "CustomCell.h"


@implementation CustomCell
@synthesize label;
@synthesize textField;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        
  }
  return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
  [super setSelected:selected animated:animated];
}

- (void)dealloc {
  [super dealloc];
}

@end
