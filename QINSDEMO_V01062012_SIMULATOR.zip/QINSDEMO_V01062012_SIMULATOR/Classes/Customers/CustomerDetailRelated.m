  //
  //  CustomerDetailRelated.m
  //  QINS3
  //
  //  Created by Ha Nguyen on 8/25/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "CustomerDetailRelated.h"
#import "qPeriorMobInsuranceDemo_CustomerRelationships.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "SUPObjectList.h"
#import "RelationShipsViewController.h"
#import "CustomerDetailsViewController.h"
#import "Utils.h"
#import "qPeriorMobInsuranceDemo_PolicyPartner.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyPartner.h"
#import "qPeriorMobInsuranceDemo_PolicyHeader.h"
#import "qPeriorMobInsuranceDemo_ThirdPartyHeader.h"
#import "RelatedPolicies.h"
#import "RelationShipAddNewController.h"
#import "PoliciesEditViewController.h"

@implementation CustomerDetailRelated

@synthesize cusDetailRelated;
@synthesize data;
@synthesize tblRelated;

- (void)loadDataRelated{
	if (data == nil) {
    data = [[NSMutableArray alloc]init];
    [data addObject:@"RelationShips"];
    [data addObject:@"Appointments"];
    [data addObject:@"Tasks"];
    [data addObject:@"Policies"];
    [data addObject:@"3rd-Party Contracts"];
	}
  
  if ([cusDetailRelated isKindOfClass:[qPeriorMobInsuranceDemo_CustomerCorporate class]]) {
    qPeriorMobInsuranceDemo_CustomerCorporate *customer = (qPeriorMobInsuranceDemo_CustomerCorporate*)cusDetailRelated;
    strNumber = customer.bpNumber;
    
  } else if ([cusDetailRelated isKindOfClass:[qPeriorMobInsuranceDemo_CustomerIndividual class]]) {
    qPeriorMobInsuranceDemo_CustomerIndividual *customer = (qPeriorMobInsuranceDemo_CustomerIndividual*)cusDetailRelated;
    strNumber = customer.bpNumber;
  }
  
  [self countRelationShips];
  [self countAppointments];
  [self countTasks];
  
  int count = 0;
  NSMutableDictionary *dictPolicies = [Utils getPolicies:strNumber];
  count = [[dictPolicies allKeys] count];
  [dictPolicies release];
  NSString *policies = [NSString stringWithFormat:@"Policies (%i)", count];
  [data replaceObjectAtIndex:3 withObject:policies];
  NSMutableDictionary *dictThirdParties = [Utils getThirdparties:strNumber];
  count = [[dictThirdParties allKeys] count];
  [dictThirdParties release];
  NSString *thirdparties = [NSString stringWithFormat:@"3rd-Party Contracts (%i)", count];
  [data replaceObjectAtIndex:4 withObject:thirdparties];
  
	if (tblRelated == nil) {
		tblRelated = [[UITableView alloc]init];
	}
	tblRelated.dataSource = self;
	[tblRelated reloadData];
}


- (void)countRelationShips {
  SUPObjectList *listRelation = [[qPeriorMobInsuranceDemo_CustomerRelationships findAll] retain];
  int count = 0;
  for (int i = 0; i < [listRelation size]; i++) {
    qPeriorMobInsuranceDemo_CustomerRelationships *relation = [listRelation item:i];
    if ([relation.bpNumber isEqualToString:strNumber] 
          || [relation.bpNumber2 isEqualToString:strNumber]) {
      count++;
    }
  }    
  [listRelation release];
  NSString *relationships = [NSString stringWithFormat:@"Relationships (%i)",count];
  [data replaceObjectAtIndex:0 withObject:relationships];
}

- (void)countAppointments {
  
}

- (void)countTasks {
  
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return 1;
}

- (NSString*)tableView:(UITableView*)tableView titleForHeaderSection:(NSInteger)section {
	return @"Related Lists";
}

  // Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  return 5;
}

  // Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  
  static NSString *CellIdentifier = @"Cell";
  
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                   reuseIdentifier:CellIdentifier] 
              autorelease];
		
  }
  
  cell.textLabel.text = [data objectAtIndex:indexPath.row];
	[cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
	int count = 0;
	for (UIView *view in cell.contentView.subviews) {
		count++;
	}
	if (count<2) {
		UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
		[button addTarget:self action:nil forControlEvents:UIControlEventTouchDown];	
		button.frame = CGRectMake(250, 12.0, 20.0, 20.0);
    [button addTarget:self action:@selector(addNew:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = indexPath.row;
		[cell.contentView addSubview:button];
	}	
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  APP_IPAD.customerView.view.userInteractionEnabled = NO;
  if (indexPath.row == 0) {
    RelationShipsViewController *relationController = 
        [[RelationShipsViewController alloc]initWithNibName:@"RelationShipsViewController" 
                                                     bundle:nil];
    CustomerDetailsViewController *detailsController = APP_IPAD.customerDetail;
    relationController.number = strNumber;
    relationController.data = [relationController getRelationShips:strNumber];
    relationController.isPushed = YES;
    [detailsController.navigationController pushViewController:relationController animated:YES];
  } else if (indexPath.row == 3) {
    RelatedPolicies *relatedPolicies = [[RelatedPolicies alloc]initWithNibName:@"RelatedPolicies" 
                                                                        bundle:nil];
    relatedPolicies.title = @"Policies";
    CustomerDetailsViewController *detailsController = APP_IPAD.customerDetail;
    relatedPolicies.customerNumber = strNumber;
    relatedPolicies.isPolicy = YES;
    [relatedPolicies initDictionaries];
    relatedPolicies.isPushed = YES;
    [detailsController.navigationController pushViewController:relatedPolicies animated:YES];
  } else if (indexPath.row == 4) {
    RelatedPolicies *relatedPolicies = APP_IPAD.relatedPolicies;
    relatedPolicies.title = @"3rd-Party Contracts";
    CustomerDetailsViewController *detailsController = APP_IPAD.customerDetail;
    relatedPolicies.customerNumber = [self.cusDetailRelated bpNumber];
    relatedPolicies.isPolicy = NO;
    [relatedPolicies initDictionaries];
    relatedPolicies.isPushed = YES;
    [detailsController.navigationController pushViewController:relatedPolicies animated:YES];
  }
}

- (void)addNew:(id)sender {
  NSInteger tag = ((UIControl *) sender).tag;
  if (tag == 0) {
    APP_IPAD.customerView.view.userInteractionEnabled = NO;
    RelationShipAddNewController *relationNew = 
        [[RelationShipAddNewController alloc]initWithNibName:@"RelationShipAddNewController" 
                                                      bundle:nil];
    CustomerDetailsViewController *detailsController = APP_IPAD.customerDetail;
    relationNew.number = strNumber;
    [relationNew initTable];
    relationNew.isPushed = YES;
    [detailsController.navigationController pushViewController:relationNew animated:YES];
  }  
  if (tag == 3) {
    APP_IPAD.customerView.view.userInteractionEnabled = NO;
    PoliciesEditViewController *policyEdit = APP_IPAD.policyEdit;
    CustomerDetailsViewController *detailsController = APP_IPAD.customerDetail;
    policyEdit.editMode = NO;
    policyEdit.isPushed = YES;
    policyEdit.holder = detailsController.customer;
    policyEdit.lockHolder = YES;
    policyEdit.isPolicy = YES;
    policyEdit.title = @"New Policy";
    [detailsController.navigationController pushViewController:policyEdit animated:YES];
  }
  if (tag == 4) {
    APP_IPAD.customerView.view.userInteractionEnabled = NO;
    PoliciesEditViewController *policyEdit = APP_IPAD.policyEdit;
    CustomerDetailsViewController *detailsController = APP_IPAD.customerDetail;
    policyEdit.editMode = NO;
    policyEdit.isPushed = YES;
    policyEdit.holder = detailsController.customer;
    policyEdit.lockHolder = YES;
    policyEdit.isPolicy = NO;
    policyEdit.title = @"New 3rd-Party Contract";
    [detailsController.navigationController pushViewController:policyEdit animated:YES];
  }
}

- (void)dealloc {
  [super dealloc];
}

@end
