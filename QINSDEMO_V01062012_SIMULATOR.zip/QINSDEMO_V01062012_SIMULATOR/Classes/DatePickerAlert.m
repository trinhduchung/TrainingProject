//
//  DatePickerAlert.m
//  EB
//
//  Created by iMac 20 on 12/22/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "DatePickerAlert.h"

@implementation DatePickerAlert

@synthesize picker;
@synthesize pickerDelegate;

- (id)initWithTitle:(NSString *)title 
           delegate:(id < UIActionSheetDelegate >)delegate
  cancelButtonTitle:(NSString *)cancelButtonTitle
destructiveButtonTitle:(NSString *)destructiveButtonTitle
  otherButtonTitles:(NSString *)otherButtonTitles, ... {
	
	self = [super initWithTitle:title delegate:delegate cancelButtonTitle:cancelButtonTitle 
		 destructiveButtonTitle:destructiveButtonTitle otherButtonTitles:otherButtonTitles,nil];
	if (self) {
		UIDatePicker *p = [[UIDatePicker alloc] initWithFrame:CGRectMake(-20, 0, 320, 216)];
		p.datePickerMode = UIDatePickerModeDate;
		
		[self addSubview:p];
		self.picker = p;
		[self.picker addTarget:self action:@selector(dateChanged) forControlEvents:UIControlEventValueChanged];
		[p release];
	}
	return self;
}

/*
 *	Determine maximum y-coordinate of UILabel objects. This method assumes that only
 *	following objects are contained in subview list:
 *	- UILabel
 *	- UITextField
 *	- UIThreePartButton (Private Class)
 */
- (CGFloat)maxLabelYCoordinate {
	// Determine maximum y-coordinate of labels
	CGFloat maxY = 0;
	for( UIView *view in self.subviews ){
		if([view isKindOfClass:[UILabel class]]) {
			CGRect viewFrame = [view frame];
			CGFloat lowerY = viewFrame.origin.y + viewFrame.size.height;
			if(lowerY > maxY)
				maxY = lowerY;
		}
	}
	return maxY;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	if(!layoutDone) {
		CGRect frame = [self frame];
		CGFloat alertWidth = frame.size.width;
		CGFloat pickerHeight = self.picker.frame.size.height + 300.0;
		CGFloat labelMaxY = [self maxLabelYCoordinate];
		
		// Insert UIPickerView below labels and move other fields down accordingly
		for(UIView *view in self.subviews){
      if([view isKindOfClass:[UIDatePicker class]]){
        CGRect viewFrame = CGRectMake(0, labelMaxY, alertWidth, pickerHeight);
        [view setFrame:viewFrame];
      } else if(![view isKindOfClass:[UILabel class]]) {
				CGRect viewFrame = [view frame];
				viewFrame.origin.y += pickerHeight;
				[view setFrame:viewFrame];
			}
		}
		
		// size UIAlertView frame by height of UIPickerView
		frame.size.height += pickerHeight + 2.0;
		frame.origin.y -= pickerHeight + 2.0;
		[self setFrame:frame];
		layoutDone = YES;
	}
}

- (void)dateChanged {
	NSDate *date = [self.picker date];
	if(date != nil) {
		NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
		[dateFormat setDateFormat:@"yyyy-MM-dd"];
		NSString *dateString = [dateFormat stringFromDate:date];
		//[EditTransactionViewController setDateString:[NSString stringWithString: dateString]];
		//[NewExpenseController setDateString:[NSString stringWithString: dateString]];
		[pickerDelegate datePickerAlert:(DatePickerAlert *)self didPickDate:(NSString *)dateString];
		[dateFormat release];
		//NSLog(dateString);
	}
}

- (id)initWithFrame:(CGRect)frame {
  if (self == [super initWithFrame:frame]) {
      // Initialization code
  }
  return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}

@end
