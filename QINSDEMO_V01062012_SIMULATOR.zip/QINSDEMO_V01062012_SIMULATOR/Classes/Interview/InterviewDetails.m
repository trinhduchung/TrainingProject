//
//  InterviewDetails.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 5/3/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import "InterviewDetails.h"
#import "DrawUtils.h"
#import "Utils.h"
#import "HomeScreenViewController.h"
#import "InterviewController.h"
#import "qPeriorMobInsuranceDemo_LocalKeyGenerator.h"
#import "qPeriorMobInsuranceDemo_InterviewResult.h"
#import "CustomerViewController.h"
#import "CustomerDetailsViewController.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"
#import "CustomerDetailInfo.h"
#import "CustomerDetailRelated.h"
#import "CustomerUtils.h"
#import "MGSplitViewController.h"


@implementation InterviewDetails
@synthesize draw;
@synthesize popOver;
@synthesize colorInfo;
@synthesize bpNumber;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
  [super viewDidLoad];
  
  UIBarButtonItem *cancelButton = 
  [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel 
                                               target:self 
                                               action:@selector(cancel:)];
  UIBarButtonItem *saveButton = 
  [[UIBarButtonItem alloc]initWithTitle:@"Save" 
                                  style:UIBarButtonItemStyleDone 
                                 target:self 
                                 action:@selector(saveData:)];
  self.navigationItem.leftBarButtonItem = cancelButton;
  self.navigationItem.rightBarButtonItem = saveButton;
  [cancelButton release];
  [saveButton release];
  self.title = @"Interview";
  colorInfo = [[ColorInfo alloc]init];
  popOver = [[UIPopoverController alloc]initWithContentViewController:colorInfo];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:YES];  
}

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:YES];
  [self loadData];
}

- (IBAction)showColorInfo:(id)sender {
  CGRect frame = CGRectMake(infoButton.frame.origin.x, 
                            infoButton.frame.origin.y, 
                            infoButton.frame.size.width, 
                            infoButton.frame.size.height);
  
  popOver.popoverContentSize = CGSizeMake(450, 168);
  [popOver presentPopoverFromRect:frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
}

- (IBAction)saveData:(id)sender {
    if (APP_IPAD.hasFromCustomerDetail) {
        qPeriorMobInsuranceDemo_CustomerIndividual *customer  = APP_IPAD.customerDetail.customer;
        for (qPeriorMobInsuranceDemo_InterviewResult *result in draw.arrayData) {
            result.bpNumber = [customer bpNumber];
            int64_t generated_ID = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateId];
            NSString *interviewID = [NSString stringWithFormat:@"%ld",generated_ID];
            result.intrvResultId = interviewID;
            [result save];
        }
        
        HomeScreenViewController *homeViewController = APP_IPAD.homeScreenViewController;
        [homeViewController.navigationController popToRootViewControllerAnimated:YES];
    } else {
        
        qPeriorMobInsuranceDemo_CustomerIndividual *customer = [[qPeriorMobInsuranceDemo_CustomerIndividual alloc]init];
        if ([APP_IPAD.interview.txtFirstname.text isEqualToString:@""] 
            || [APP_IPAD.interview.txtLastname.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" 
                                                           message:@"Please enter First Name and Last Name too." 
                                                          delegate:self 
                                                 cancelButtonTitle:@"OK" 
                                                 otherButtonTitles:nil];
            [alert show];
            [alert release];
        } else {
            [customer setBpIndFirstName:APP_IPAD.interview.txtFirstname.text];
            [customer setBpIndLastName:APP_IPAD.interview.txtLastname.text];
            
            [customer setBpComMobile:@""];
            [customer setBpRole:@"PROS01"];
            
            int64_t generatedID = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateId];
            NSString *number = [NSString stringWithFormat:@"%ld",generatedID];
            [customer setBpNumber:number];
            
            [customer setBpAddrStreet:@""];
            [customer setBpAddrHouseNo:@""];
            [customer setBpAddrPostalCode:@""];
            [customer setBpAddrCity:@""];
            [customer setBpAddrCountry:@""]; 
            [customer setBpAddrRegion:@""];
            [customer setBpComTelephone:@""];
            [customer setBpComFax:@""];
            [customer setBpComEmail:@""];
            [customer save];
            
            for (qPeriorMobInsuranceDemo_InterviewResult *result in draw.arrayData) {
                result.bpNumber = number;
                int64_t generated_ID = [qPeriorMobInsuranceDemo_LocalKeyGenerator generateId];
                NSString *interviewID = [NSString stringWithFormat:@"%ld",generated_ID];
                result.intrvResultId = interviewID;
                [result save];
            }
            
            HomeScreenViewController *homeViewController = APP_IPAD.homeScreenViewController;
            [homeViewController.navigationController popToRootViewControllerAnimated:YES];
        }
    }
}

- (IBAction)cancel:(id)sender {
    if (APP_IPAD.hasFromCustomerDetail) {
        
        APP_IPAD.splitView = (MGSplitViewController*)[APP_IPAD.homeScreenViewController createSplitView:APP_IPAD.customerView 
                                                                                                  DetailView:APP_IPAD.customerDetail];
        [APP_IPAD.homeScreenViewController.navigationController pushViewController:APP_IPAD.splitView animated:YES];
    } else {
        HomeScreenViewController *homeViewController = APP_IPAD.homeScreenViewController;
        [homeViewController.navigationController popToRootViewControllerAnimated:YES];
    }
}

  //load data and set bound for chart
- (void)loadData {
    
  int a = self.view.bounds.size.height-100;  
  draw.bounds = CGRectMake(self.view.bounds.size.width/2-a/2-70/2, self.view.bounds.size.height/2-a/2-100/2+24, a, a);
  draw.xPoint = draw.frame.size.width/2;
  draw.yPoint = draw.frame.size.width/2;
  draw.height = a;
  draw.width = a;  
  
  if (draw.arrayData == nil) {
    draw.arrayData = [[NSMutableArray alloc]init];
  } else {
    [draw.arrayData removeAllObjects];
  }
  
  if (![bpNumber isEqualToString:@""]) {
    SUPObjectList *list = [qPeriorMobInsuranceDemo_InterviewResult findAll];
    for (qPeriorMobInsuranceDemo_InterviewResult *result in list) {
      if ([result.bpNumber isEqualToString:bpNumber]) {
        [draw.arrayData addObject:result];
      }
    }
  }
  
  if (draw.arrayData.count == 0) {
    NSMutableArray *arrayProperties = [[NSMutableArray alloc]initWithObjects:@"0002", @"0003", nil];
    [draw getDataByProfileID:@"00001" property:arrayProperties customer:@""];
  } 
  
  if (draw.dictName == nil) {
    draw.dictName = [[NSMutableDictionary alloc]init];
  }  
  draw.dictName = [Utils getProductIDDictionary];
  [draw setNeedsDisplay];

}

  // not use
- (void)reloadData {
  int a = self.view.bounds.size.height-100;  
  draw.bounds = CGRectMake(self.view.bounds.size.width/2-a/2-70/2, self.view.bounds.size.height/2-a/2-100/2+24, a, a);
  draw.xPoint = draw.frame.size.width/2;
  draw.yPoint = draw.frame.size.width/2;
  draw.height = a;
  draw.width = a;
  draw.fillColor = YES;
  [draw setNeedsDisplay];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return NO;
}




@end
