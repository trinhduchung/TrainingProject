//
//  InterviewController.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 5/3/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kCBImages 0
#define kCBValues 1

@interface InterviewController : UIViewController {
  UISlider *slider;
  UILabel *valueSlider;
  NSMutableArray *arrCheckboxs;
  NSMutableArray *arrayProperties;
  IBOutlet UITextField *txtFirstname;
  IBOutlet UITextField *txtLastname;
  
  // Marital Status
  IBOutlet UIImageView *imgSingle;
  IBOutlet UIImageView *imgMarried;
  IBOutlet UIImageView *imgChildren;
  
  IBOutlet UIImageView *cbSingle;
  IBOutlet UIImageView *cbMarried;
  IBOutlet UIImageView *cbChildren;
  
  // Properties
  IBOutlet UIImageView *imgEstates;
  IBOutlet UIImageView *imgVehicles;
  
  IBOutlet UIImageView *cbEstates;
  IBOutlet UIImageView *cbVehicles;
  
  // Employment
  IBOutlet UIImageView *imgEmployed;
  IBOutlet UIImageView *imgSelfEmployed;
  IBOutlet UIImageView *imgUnemployed;
  
  IBOutlet UIImageView *cbEmloyed;
  IBOutlet UIImageView *cbSelfEmployed;
  IBOutlet UIImageView *cbUnemployed;
}
@property (nonatomic, retain) NSMutableArray *arrayProperties;
@property (nonatomic, retain) UISlider *slider;
@property (nonatomic, retain) UILabel *valueSlider;

@property (nonatomic, retain) IBOutlet UITextField *txtFirstname;
@property (nonatomic, retain) IBOutlet UITextField *txtLastname;

@property (nonatomic, retain) IBOutlet UIImageView *imgSingle;
@property (nonatomic, retain) IBOutlet UIImageView *imgMarried;
@property (nonatomic, retain) IBOutlet UIImageView *imgChildren;

@property (nonatomic, retain) IBOutlet UIImageView *cbSingle;
@property (nonatomic, retain) IBOutlet UIImageView *cbMarried;
@property (nonatomic, retain) IBOutlet UIImageView *cbChildren;

@property (nonatomic, retain) IBOutlet UIImageView *imgEstates;
@property (nonatomic, retain) IBOutlet UIImageView *imgVehicles;

@property (nonatomic, retain) IBOutlet UIImageView *cbEstates;
@property (nonatomic, retain) IBOutlet UIImageView *cbVehicles;

@property (nonatomic, retain) IBOutlet UIImageView *imgEmployed;
@property (nonatomic, retain) IBOutlet UIImageView *imgSelfEmployed;
@property (nonatomic, retain) IBOutlet UIImageView *imgUnemployed;

@property (nonatomic, retain) IBOutlet UIImageView *cbEmloyed;
@property (nonatomic, retain) IBOutlet UIImageView *cbSelfEmployed;
@property (nonatomic, retain) IBOutlet UIImageView *cbUnemployed;


- (void)initSlider;
- (float)getXforValueLabel:(UISlider *)aSlider;
- (float)getYforValueLabel:(UISlider *)aSlider;
- (void)initSliderButtons;
- (void)sliderValueChanged:(id)sender;
- (void)initDefaultCheckbox;
- (NSString*)getCustomerProfileID:(int)age marital:(NSString*)marital;
- (void)getProperties;

@end
