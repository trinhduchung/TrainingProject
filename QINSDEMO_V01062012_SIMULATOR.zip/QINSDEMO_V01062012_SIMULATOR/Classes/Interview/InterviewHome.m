//
//  InterviewHome.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 4/25/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import "InterviewHome.h"
#import "DrawUtils.h"
#import "ColorInfo.h"
#import "SUPObjectList.h"
#import "qPeriorMobInsuranceDemo_InterviewResult.h"

@implementation InterviewHome
@synthesize draw;
@synthesize popOver;
@synthesize colorInfo;
@synthesize bpNumber;
@synthesize customerName;
@synthesize visible;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
  [super viewDidLoad];
  colorInfo = [[ColorInfo alloc]init];
  popOver = [[UIPopoverController alloc]initWithContentViewController:colorInfo];
  backButton.transform = CGAffineTransformMakeRotation((180*M_PI)/180);
}

- (IBAction)showColorInfo:(id)sender {
  CGRect frame = CGRectMake(infoButton.frame.origin.x, 
                            infoButton.frame.origin.y, 
                            infoButton.frame.size.width, 
                            infoButton.frame.size.height);
  
  popOver.popoverContentSize = CGSizeMake(450, 168);
  [popOver presentPopoverFromRect:frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
}

- (IBAction)back:(id)sender {
  [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:YES];
  [self loadData];
  if ([bpNumber isEqualToString:@""]) {
    lblName.hidden = YES;
    lblNumber.hidden = YES;
  } else {
    lblNumber.hidden = NO;
    lblName.hidden = NO;
  }
  visible = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
  [super viewWillDisappear:YES];
  visible = NO;
}

  // load data and set bound for chart
- (void)loadData {
  int a = self.view.bounds.size.height-100;  
  draw.bounds = CGRectMake(self.view.bounds.size.width/2-a+150, self.view.bounds.size.height/2-a/2-100/2+24, a, a);
  draw.xPoint = draw.frame.size.width/2;
  draw.yPoint = draw.frame.size.width/2;
  draw.height = a;
  draw.width = a;
  lblNumber.text = bpNumber;
  lblName.text = customerName;

  if (draw.arrayData == nil) {
    draw.arrayData = [[NSMutableArray alloc]init];
  } else {
    [draw.arrayData removeAllObjects];
  }
  
  if (![bpNumber isEqualToString:@""]) {
    draw.fillColor = YES;
    SUPObjectList *list = [qPeriorMobInsuranceDemo_InterviewResult findAll];
    for (qPeriorMobInsuranceDemo_InterviewResult *result in list) {
      if ([result.bpNumber isEqualToString:bpNumber]) {
        [draw.arrayData addObject:result];
      }
    }
  } else {
    draw.fillColor = NO;
  }  
  if (draw.arrayData.count == 0) {
    draw.fillColor = NO;
    NSMutableArray *arrayProperties = [[NSMutableArray alloc]initWithObjects:@"0002", @"0003", nil];
    [draw getDataByProfileID:@"00001" property:arrayProperties customer:@""];
  } 
  [draw setNeedsDisplay];
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	return YES;
}

@end
