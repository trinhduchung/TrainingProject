//
//  InterviewDetails.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 5/3/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrawUtils.h"
#import "ColorInfo.h"


@interface InterviewDetails : UIViewController {
  IBOutlet DrawUtils *draw;
  UIPopoverController *popOver;
  ColorInfo *colorInfo;
  IBOutlet UIButton *infoButton;
  NSString *bpNumber;
}

@property (nonatomic, retain) IBOutlet DrawUtils *draw;
@property (nonatomic, retain) UIPopoverController *popOver;
@property (nonatomic, retain) ColorInfo *colorInfo;
@property (nonatomic, retain) NSString *bpNumber;

- (void)loadData;
- (void)reloadData;
@end
