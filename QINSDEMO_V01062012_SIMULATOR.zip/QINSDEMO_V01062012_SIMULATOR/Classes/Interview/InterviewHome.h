//
//  InterviewHome.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 4/25/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrawUtils.h"
#import "ColorInfo.h"

@interface InterviewHome : UIViewController {
  IBOutlet DrawUtils *draw;
  UIPopoverController *popOver;
  ColorInfo *colorInfo;
  IBOutlet UIButton *infoButton;
  IBOutlet UILabel *lblName;
  IBOutlet UILabel *lblNumber;
  IBOutlet UIButton *backButton;
  NSString *bpNumber;
  NSString *customerName;
  bool visible;
}

@property (nonatomic, retain) IBOutlet DrawUtils *draw;
@property (nonatomic, retain) UIPopoverController *popOver;
@property (nonatomic, retain) ColorInfo *colorInfo;
@property (nonatomic, retain) NSString *bpNumber;
@property (nonatomic, retain) NSString *customerName;
@property (nonatomic) bool visible;

- (void)loadData;




@end
