//
//  InterviewPopup.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 5/8/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InterviewPopup : UIViewController {
  id sender;
  UISlider *slider;
  IBOutlet UIBarButtonItem *done;
  IBOutlet UIBarButtonItem *cancel;
  IBOutlet UIButton *offer;
  int value;
  bool isMotor;
  IBOutlet UILabel *lblName;
  NSString *pdName;
}

@property (nonatomic, retain) id sender;
@property (nonatomic, retain) UISlider *slider;
@property (nonatomic) int value;
@property (nonatomic) bool isMotor;
@property (nonatomic, retain) IBOutlet UIButton *offer;
@property (nonatomic, retain) NSString *pdName;

- (void)initSlider;
- (void)sliderValueChanged:(id)sender;

@end
