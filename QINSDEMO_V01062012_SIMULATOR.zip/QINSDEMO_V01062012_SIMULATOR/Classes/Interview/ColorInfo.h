//
//  ColorInfo.h
//  QINS3
//
//  Created by Phạm Phi Phúc on 5/10/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColorInfo : UIViewController

@end
