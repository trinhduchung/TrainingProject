//
//  InterviewPopup.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 5/8/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import "InterviewPopup.h"
#import "DrawUtils.h"
#import "Utils.h"
#import "HomeScreenViewController.h"

@interface InterviewPopup ()

@end

@implementation InterviewPopup
@synthesize sender;
@synthesize slider;
@synthesize value;
@synthesize isMotor;
@synthesize offer;
@synthesize pdName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  [self initSlider];
  offer.hidden = YES;
  lblName.text = @"";
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:YES];
  slider.value = 1;
  if (isMotor) {
    offer.hidden = NO;
  } else {
    offer.hidden = YES;
  }
  lblName.text = pdName;
//  navbar.title = lblTitle;
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	return YES;
}

- (void)initSlider {
  CGRect frame = CGRectMake(20, 85, 20, 240);
  slider = [[UISlider alloc]init];
  slider.maximumValue = 2;
  slider.minimumValue = 0;
  slider.value = 1;
  [slider addTarget:self 
             action:@selector(sliderValueChanged:) 
   forControlEvents:UIControlEventValueChanged];
  slider.transform = CGAffineTransformRotate(slider.transform,M_PI/-2);
  slider.frame = frame;
  [self.view addSubview:slider];
}

- (void)sliderValueChanged:(id)sender {
  int newValue = round(slider.value/1);
  slider.value = newValue;
}

- (IBAction)cancel:(id)sender {
  [self.sender dismissPopover];
}

- (IBAction)done:(id)sender {
  value = slider.value;
  [self.sender dismissPopover];
  [self.sender getSlider];
}

- (IBAction)showMotor:(id)sender {
  [self.sender dismissPopover];
  HomeScreenViewController *home = APP_IPAD.homeScreenViewController;
  [home.navigationController pushViewController:APP_IPAD.analysisSplit animated:YES];
}

@end
