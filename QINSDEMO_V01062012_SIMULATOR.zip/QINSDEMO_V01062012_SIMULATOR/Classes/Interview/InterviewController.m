//
//  InterviewController.m
//  QINS3
//
//  Created by Phạm Phi Phúc on 5/3/12.
//  Copyright (c) 2012 Orient Software Development. All rights reserved.
//

#import "InterviewController.h"
#import "qPeriorMobInsuranceDemo_CustAnalyseCustomerProfile.h"
#import "Utils.h"
#import "DrawUtils.h"
#import "InterviewDetails.h"
#import "CustomerDetailsViewController.h"
#import "CustomerDetailInfo.h"
#import "CustomerDetailRelated.h"
#import "CustomerUtils.h"
#import "qPeriorMobInsuranceDemo_CustomerIndividual.h"
#import "qPeriorMobInsuranceDemo_CustomerCorporate.h"


@implementation InterviewController

@synthesize txtFirstname;
@synthesize txtLastname;

@synthesize arrayProperties;
@synthesize slider;
@synthesize valueSlider;

@synthesize imgSingle;
@synthesize imgMarried;
@synthesize imgChildren;

@synthesize cbSingle;
@synthesize cbMarried;
@synthesize cbChildren;

@synthesize imgEstates;
@synthesize imgVehicles;

@synthesize cbEstates;
@synthesize cbVehicles;

@synthesize imgEmployed;
@synthesize imgSelfEmployed;
@synthesize imgUnemployed;

@synthesize cbEmloyed;
@synthesize cbSelfEmployed;
@synthesize cbUnemployed;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
  [super viewDidLoad];
  arrayProperties = [[NSMutableArray alloc]init];
  [self initSlider];
  arrCheckboxs = [[NSMutableArray alloc]init];
  [self initButtons];
  [arrCheckboxs addObject:[self initImages]];
  [arrCheckboxs addObject:[self initValues]];
  [self initDefaultCheckbox];
  NSString *profileID = [self getCustomerProfileID:slider.value marital:[self getMaterialStatus]];
  [self getProperties];
  APP_IPAD.interviewDetail.draw.fillColor = YES;
  [APP_IPAD.interviewDetail.draw getDataByProfileID:profileID property:arrayProperties customer:@""];
  self.title = @"Properties";
    // Do any additional setup after loading the view from its nib.
    if (APP_IPAD.hasFromCustomerDetail) {
        self.txtFirstname.text = [APP_IPAD.customerDetail.customer bpIndFirstName];
        self.txtLastname.text = [APP_IPAD.customerDetail.customer bpIndLastName];
    }
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	return YES;
}

#pragma mark - Slider

-(void)initSlider {    
  CGRect frame = CGRectMake(102, 25, 30, 634);
  slider = [[UISlider alloc]init];
  UIImage *stetchLeftTrack = [[UIImage imageNamed:@"Slider.png"] 
                              stretchableImageWithLeftCapWidth:10.0 topCapHeight:0.0];
  UIImage *stetchRightTrack = [[UIImage imageNamed:@"Slider.png"] 
                               stretchableImageWithLeftCapWidth:10.0 topCapHeight:0.0];
  [slider setThumbImage: [UIImage imageNamed:@"Slider_button.png"] forState:UIControlStateNormal];
  [slider setMinimumTrackImage:stetchLeftTrack forState:UIControlStateNormal];
  [slider setMaximumTrackImage:stetchRightTrack forState:UIControlStateNormal];
  slider.maximumValue = 100.0;
  slider.minimumValue = 0.0;
  slider.value = 25.0;
  slider.transform = CGAffineTransformRotate(slider.transform,M_PI/-2);
  slider.frame = frame;
  [slider addTarget:self 
             action:@selector(sliderValueChanged:) 
   forControlEvents:UIControlEventValueChanged];
  
  CGRect valueFrame = CGRectMake([self getXforValueLabel:slider], 
                                 [self getYforValueLabel:slider], 
                                 100, 
                                 25);
  valueSlider = [[UILabel alloc]initWithFrame:valueFrame];
  valueSlider.text = [NSString stringWithFormat:@"%.f", slider.value];
  valueSlider.textAlignment = UITextAlignmentCenter;
  valueSlider.textColor = [UIColor blueColor];
  valueSlider.font = [UIFont systemFontOfSize:20];
  valueSlider.backgroundColor = [UIColor clearColor];
  [self.view addSubview:slider];
  [self.view addSubview:valueSlider];
  [self initSliderButtons];
}

- (void)initSliderButtons {
  CGRect frameMinus = CGRectMake(slider.frame.origin.x-15, 
                                 slider.frame.origin.y + slider.frame.size.height-30,
                                 20, 
                                 20);
  UIImageView *minus = [[UIImageView alloc]initWithFrame:frameMinus];
  [minus setImage:[UIImage imageNamed:@"Minus.png"]];
  [self.view addSubview:minus];
  [minus release];
  
  CGRect framePlus = CGRectMake(slider.frame.origin.x-15, slider.frame.origin.y+3, 20, 20);    
  UIImageView *plus = [[UIImageView alloc]initWithFrame:framePlus];    
  [plus setImage:[UIImage imageNamed:@"Plus.png"]];    
  [self.view addSubview:plus];
  [plus release];
  
  UIButton *btnMinus = [[UIButton alloc]initWithFrame:frameMinus];
  btnMinus.tag = 0;
  [btnMinus addTarget:nil 
               action:@selector(changeSliderValue:) 
     forControlEvents:UIControlEventTouchUpInside];
  [self.view addSubview:btnMinus];
  [btnMinus release];
  
  UIButton *btnPlus = [[UIButton alloc]initWithFrame:framePlus];
  btnPlus.tag = 1;
  [btnPlus addTarget:nil 
              action:@selector(changeSliderValue:) 
    forControlEvents:UIControlEventTouchUpInside];
  [self.view addSubview:btnPlus];
  [btnPlus release];
}

- (IBAction)changeSliderValue:(id)sender {
  int i = [sender tag];
  if (i == 0) {
    [slider setValue:slider.value-1];
  } else {
    [slider setValue:slider.value+1];
  }
  [self sliderValueChanged:slider];
}

- (void)sliderValueChanged:(id)sender {
  UISlider *aSlider = (UISlider*)sender;
  float x = [self getXforValueLabel:aSlider]; 
  float y = [self getYforValueLabel:aSlider];
  CGRect valueFrame = CGRectMake(x, y, 100, 25);
  valueSlider.frame = valueFrame;
  valueSlider.text = [NSString stringWithFormat:@"%.f", slider.value];
  NSString *profileID = [self getCustomerProfileID:aSlider.value marital:[self getMaterialStatus]];
  [self getProperties];
  [APP_IPAD.interviewDetail.draw getDataByProfileID:profileID property:arrayProperties customer:@""]; 
  [APP_IPAD.interviewDetail reloadData];
}

  // don't care about formula inside this
- (float)getXforValueLabel:(UISlider*)aSlider {
  float x = (aSlider.frame.origin.x + aSlider.frame.size.width/2)*0.6;
  return x;
}

  // don't care about formula inside this
- (float)getYforValueLabel:(UISlider*)aSlider {
  float y = aSlider.frame.origin.y 
  + ((100 - aSlider.value) 
     * aSlider.frame.size.height / 100) 
  - (100 - aSlider.value)/3;
  return y;
}

#pragma mark - Checkboxs
- (void)initButtons {
  NSMutableArray *arrButtons = [[NSMutableArray alloc]init];    
  [arrButtons addObject:cbSingle];
  [arrButtons addObject:cbMarried];
  [arrButtons addObject:cbChildren];
  [arrButtons addObject:cbEstates];
  [arrButtons addObject:cbVehicles];
  [arrButtons addObject:cbEmloyed];
  [arrButtons addObject:cbSelfEmployed];
  [arrButtons addObject:cbUnemployed];
  
  for (int i = 0; i < [arrButtons count]; i++) {
    UIImageView *imageView = [arrButtons objectAtIndex:i];
    UIButton *btn = [[UIButton alloc]initWithFrame:imageView.frame]; 
    btn.tag = i;
    [btn addTarget:nil 
            action:@selector(checkboxValueChanged:) 
  forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    [btn release];
  }
  [arrButtons release];
}

- (NSMutableArray *)initImages {
  NSMutableArray *arrImages = [[NSMutableArray alloc]init];    
  [arrImages addObject:imgSingle];
  [arrImages addObject:imgMarried];
  [arrImages addObject:imgChildren];
  [arrImages addObject:imgEstates];
  [arrImages addObject:imgVehicles];
  [arrImages addObject:imgEmployed];
  [arrImages addObject:imgSelfEmployed];
  [arrImages addObject:imgUnemployed];
  return arrImages;
}

- (NSMutableArray *)initValues {
  NSMutableArray *arrayValues = [[NSMutableArray alloc]init];
  for (int i = 0; i < 8; i++) {
    [arrayValues addObject:kUnchecked];
  }
  return arrayValues;
}

// when a checkbox's state changed, may be others checkboxs' state changed. 
- (IBAction)checkboxValueChanged:(id)sender {
  int i = [sender tag];
  BOOL checked = [[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:i] isEqualToString:kChecked] ? YES : NO;
  [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:i withObject:checked?kUnchecked:kChecked];
  [self setCheckboxImage:i withImage:checked?kUncheckedImage:kCheckedImage];
  switch (i) {
    case kSingleCheckBox:
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kMarriedCheckBox withObject:checked?kChecked:kUnchecked];
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kChildrenCheckBox withObject:kUnchecked];
      [self setCheckboxImage:kMarriedCheckBox withImage:checked?kCheckedImage:kUncheckedImage];
      [self setCheckboxImage:kChildrenCheckBox withImage:kUncheckedImage];
      break;
    case kMarriedCheckBox:
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kSingleCheckBox withObject:checked?kChecked:kUnchecked];
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kChildrenCheckBox withObject:kUnchecked];
      [self setCheckboxImage:kSingleCheckBox withImage:checked?kCheckedImage:kUncheckedImage];
      [self setCheckboxImage:kChildrenCheckBox withImage:kUncheckedImage];          
      break;
    case kChildrenCheckBox:
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kSingleCheckBox withObject:kUnchecked];
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kMarriedCheckBox withObject:kChecked];
      [self setCheckboxImage:kSingleCheckBox withImage:kUncheckedImage];
      [self setCheckboxImage:kMarriedCheckBox withImage:kCheckedImage];
      break;
    case kEmployedCheckBox:
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kSelfEmployedCheckBox withObject:kUnchecked];
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kUnemployedCheckBox withObject:checked?kChecked:kUnchecked];
      [self setCheckboxImage:kSelfEmployedCheckBox withImage:kUncheckedImage];
      [self setCheckboxImage:kUnemployedCheckBox withImage:checked?kCheckedImage:kUncheckedImage];
      break;
    case kSelfEmployedCheckBox:
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kEmployedCheckBox withObject:kUnchecked];
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kUnemployedCheckBox withObject:checked?kChecked:kUnchecked];
      [self setCheckboxImage:kEmployedCheckBox withImage:kUncheckedImage];
      [self setCheckboxImage:kUnemployedCheckBox withImage:checked?kCheckedImage:kUncheckedImage];
      break;
    case kUnemployedCheckBox:
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kEmployedCheckBox withObject:checked?kChecked:kUnchecked];
      [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kSelfEmployedCheckBox withObject:kUnchecked];
      [self setCheckboxImage:kEmployedCheckBox withImage:checked?kCheckedImage:kUncheckedImage];
      [self setCheckboxImage:kSelfEmployedCheckBox withImage:kUncheckedImage];
    default:
      break;
  }
  
  NSString *profileID = [self getCustomerProfileID:slider.value marital:[self getMaterialStatus]];
  [self getProperties];
  [APP_IPAD.interviewDetail.draw getDataByProfileID:profileID property:arrayProperties customer:@""];
  [APP_IPAD.interviewDetail reloadData];
}

- (void)setCheckboxImage:(int)checkbox withImage:(NSString *)image {
  UIImageView *imageView = [[arrCheckboxs objectAtIndex:kCBImages] objectAtIndex:checkbox];
  [imageView setImage:[UIImage imageNamed:image]];
}

- (void)initDefaultCheckbox {
  [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kSingleCheckBox withObject:kChecked];
  [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kVehiclesCheckBox withObject:kChecked];
  [[arrCheckboxs objectAtIndex:kCBValues] replaceObjectAtIndex:kEmployedCheckBox withObject:kChecked];
  [self setCheckboxImage:kSingleCheckBox withImage:kCheckedImage];
  [self setCheckboxImage:kVehiclesCheckBox withImage:kCheckedImage];
  [self setCheckboxImage:kEmployedCheckBox withImage:kCheckedImage];
  [arrayProperties addObject:kVehicle];
  [arrayProperties addObject:kEmployed];
}


#pragma mark - Profile
- (NSString*)getCustomerProfileID:(int)age marital:(NSString*)marital {  
  NSString *profileID = @"";
  if (age > 65) {
    profileID =  kReadyToGo;
  } else {
    SUPObjectList *listProfiles = [qPeriorMobInsuranceDemo_CustAnalyseCustomerProfile findAll];
    for (qPeriorMobInsuranceDemo_CustAnalyseCustomerProfile *profile in listProfiles) {
      if (age >= [profile.ageFrom intValue] 
          && age <= [profile.ageTo intValue] 
          && [marital isEqualToString:profile.maritalStatus]) {
        profileID = profile.custProfileId;
      }
    }
  }
  return profileID;
}

- (NSString *)getMaterialStatus {
  if ([[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kSingleCheckBox] isEqualToString:kChecked]) {
    return kStringSingle;
  } else if ([[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kMarriedCheckBox] isEqualToString:kChecked] 
             && [[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kChildrenCheckBox] isEqualToString:kUnchecked]) {
    return kStringMarried;
  } else if ([[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kMarriedCheckBox] isEqualToString:kChecked] 
             && [[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kChildrenCheckBox] isEqualToString:kChecked]) {
    return kStringFamily;
  } else {
    return @"";
  }
}

- (void)getProperties {
//  [arrayProperties removeAllObjects];
  if ([[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kEstatesCheckBox] isEqualToString:kChecked]) {
    if (![arrayProperties containsObject:kEstate]) {
      [arrayProperties addObject:kEstate];
    }
  } else {
    if ([arrayProperties containsObject:kEstate]) {
      [arrayProperties removeObject:kEstate];
    }
  }
  if ([[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kVehiclesCheckBox] isEqualToString:kChecked]) {
    if (![arrayProperties containsObject:kVehicle]) {
      [arrayProperties addObject:kVehicle];
    }    
  } else {
    if ([arrayProperties containsObject:kVehicle]) {
      [arrayProperties removeObject:kVehicle];
    }
  }
  if ([[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kEmployedCheckBox] isEqualToString:kChecked]) {
    if (![arrayProperties containsObject:kEmployed]) {
      [arrayProperties addObject:kEmployed];
    }
    if ([arrayProperties containsObject:kSelfEmployed]) {
      [arrayProperties removeObject:kSelfEmployed];
    }
    if ([arrayProperties containsObject:kUnEmployed]) {
      [arrayProperties removeObject:kUnEmployed];
    }
  } else if ([[[arrCheckboxs objectAtIndex:kCBValues] objectAtIndex:kSelfEmployedCheckBox] isEqualToString:kChecked]) {
    if (![arrayProperties containsObject:kSelfEmployed]) {
      [arrayProperties addObject:kSelfEmployed];
    }
    if ([arrayProperties containsObject:kEmployed]) {
      [arrayProperties removeObject:kEmployed];
    }
    if ([arrayProperties containsObject:kUnEmployed]) {
      [arrayProperties removeObject:kUnEmployed];
    }
  } else {
    if (![arrayProperties containsObject:kUnEmployed]) {
      [arrayProperties addObject:kUnEmployed];
    }
    if ([arrayProperties containsObject:kSelfEmployed]) {
      [arrayProperties removeObject:kSelfEmployed];
    }
    if ([arrayProperties containsObject:kEmployed]) {
      [arrayProperties removeObject:kEmployed];
    }
  }
}




@end
