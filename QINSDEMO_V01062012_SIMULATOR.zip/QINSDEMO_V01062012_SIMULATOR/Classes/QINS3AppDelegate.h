  //
  //  QINS3AppDelegate.h
  //  QINS3
  //
  //  Created by Binh Ho on 8/15/11.
  //  Copyright __MyCompanyName__ 2011. All rights reserved.
  //

#import <UIKit/UIKit.h>

@class HomeScreenViewController;
@class CustomerViewController;
@class CustomerDetailsViewController;
@class CustomDetailsEdit;
@class RelatedPolicies;
@class MGSplitViewController;
@class PoliciesViewController;
@class PolicyDetailsViewController;
@class PoliciesEditViewController;
@class CountryUtils;
@class CustomerUtils;
@class ProfilesViewController;
@class ProfilesDetailsViewController;
@class Utils;
@class AnalysisController;
@class AnalysisHome;
@class InterviewHome;
@class InterviewController;
@class InterviewDetails;

@interface QINS3AppDelegate : NSObject <UIApplicationDelegate> {
  UIWindow *window;
  UINavigationController *navigationController;
  
	HomeScreenViewController *homeScreenViewController;
  
  CustomerViewController *customerView;
	CustomerDetailsViewController *customerDetail;
  CustomDetailsEdit *customerEdit;
  RelatedPolicies *relatedPolicies;  
  
	PoliciesViewController *policiesView;
	PolicyDetailsViewController *policiesDetail;
  PoliciesEditViewController *policyEdit;
	
  ProfilesViewController *profilesView;
  ProfilesDetailsViewController *profilesDetailsView;
  AnalysisController *analysis;
  AnalysisHome *analysisHome;
  
  InterviewHome *interviewHome;
  InterviewController *interview;
  InterviewDetails *interviewDetail;
  
	MGSplitViewController *splitView;
	MGSplitViewController *policiesSplit;
  MGSplitViewController *profilesSplit;
  MGSplitViewController *analysisSplit;
  MGSplitViewController *interviewSplit;
  
  CountryUtils *country;
  CustomerUtils *customerUtils;
  Utils *utils;
}

@property (nonatomic, retain) Utils *utils;
@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic, retain) HomeScreenViewController *homeScreenViewController;
@property (nonatomic, assign) CustomerViewController *customerView;
@property (nonatomic, assign) CustomerDetailsViewController *customerDetail;
@property (nonatomic, assign) RelatedPolicies *relatedPolicies;
@property (nonatomic, assign) PoliciesViewController *policiesView;
@property (nonatomic, assign) PolicyDetailsViewController *policiesDetail;
@property (nonatomic, assign) PoliciesEditViewController *policyEdit;
@property (nonatomic, assign) CustomDetailsEdit *customerEdit;
@property (nonatomic, assign) ProfilesViewController *profilesView;
@property (nonatomic, assign) ProfilesDetailsViewController *profilesDetailsView;
@property (nonatomic, assign) InterviewHome *interviewHome;
@property (nonatomic, assign) InterviewController *interview;
@property (nonatomic, assign) InterviewDetails *interviewDetail;
@property (nonatomic, assign) MGSplitViewController *splitView;
@property (nonatomic, assign) MGSplitViewController *policiesSplit;
@property (nonatomic, assign) MGSplitViewController *profilesSplit;
@property (nonatomic, assign) MGSplitViewController *analysisSplit;
@property (nonatomic, assign) MGSplitViewController *interviewSplit;
@property (nonatomic, retain) CountryUtils *country;
@property (nonatomic, retain) CustomerUtils *customerUtils;
@property (nonatomic, assign) AnalysisHome *analysisHome;
@property (nonatomic, assign) AnalysisController *analysis;
@property (nonatomic, assign) BOOL hasFromCustomerDetail;

@end
