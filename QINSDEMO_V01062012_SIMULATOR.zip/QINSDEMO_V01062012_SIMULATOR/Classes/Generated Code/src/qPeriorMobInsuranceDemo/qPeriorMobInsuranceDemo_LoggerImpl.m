#import "qPeriorMobInsuranceDemo_LoggerImpl.h"
#import "qPeriorMobInsuranceDemo_LogRecordImpl.h"
#import "qPeriorMobInsuranceDemo_KeyGenerator.h"
#import "MBODebugSettings.h"

@implementation qPeriorMobInsuranceDemo_LoggerImpl

- (id<SUPLogRecord>)createRealLogRecord
{
	qPeriorMobInsuranceDemo_LogRecordImpl *log = [qPeriorMobInsuranceDemo_LogRecordImpl getInstance];
	log.messageId = [qPeriorMobInsuranceDemo_KeyGenerator generateId];
	log.requestId = [NSString stringWithFormat:@"%ld",log.messageId];
	log.timestamp = [NSDate dateWithTimeIntervalSinceNow:0];
	log.code = CLIENT_DATABASE_CREATED_LOGRECORD_CODE;
	log.component = @"QPeriorMobInsuranceDemoDB";
	return log;
}


@end