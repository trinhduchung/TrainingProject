#import "qPeriorMobInsuranceDemo_SynchronizationGroup.h"

@implementation qPeriorMobInsuranceDemo_SynchronizationGroup

@synthesize entityNames = _entityNames;

+ (qPeriorMobInsuranceDemo_SynchronizationGroup*)getInstance:(NSString*)name
{
	qPeriorMobInsuranceDemo_SynchronizationGroup* inst = [[qPeriorMobInsuranceDemo_SynchronizationGroup alloc] init];
	inst->_name = name;
	return [inst autorelease];		
}

- (NSString*)name
{
	return _name;
}

- (BOOL)adminLock
{
	return NO;
}

- (BOOL)enableSIS
{
	return NO;
}

- (void)setEnableSIS:(BOOL)_enableSIS
{
	// setter is present for API compatibility, but disabled in this version
}

- (int32_t)interval
{
	return 0;
}

- (SUPStringList*)getEntityNames
{
	return [self entityNames];
}

- (void)save
{
}

- (void)synchronize
{
}

- (void)submitPendingOperations
{
}

- (void)cancelPendingOperations
{
}


@end