//
//  ProfileListProductsPopOver.m
//  QINS3
//
//  Created by vinh luu on 11/17/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ProfileListProductsPopOver.h"
#import "qPeriorMobInsuranceDemo_CustomizingProduct.h"
#import "SUPObjectList.h"
#import "ProfileUtils.h"
#import "ProfilesDetailsViewController.h"

@implementation ProfileListProductsPopOver

@synthesize data;
@synthesize table;
@synthesize dictProfiles;
@synthesize button;
@synthesize sender;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
    // Custom initialization
  }
  return self;
}

- (void)didReceiveMemoryWarning {
  // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
  dictProfiles = [ProfileUtils getCustomizingProductDictionary];
  [super viewDidLoad];
}

- (void)viewDidUnload{
  [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations
	return YES;
}

#pragma - Table Methods 

- (void)loadData {
	[table reloadData];
}

- (int) numberOfSectionsInTableView:(UITableView *)tableView {
  return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  return [data size];
}

- (UITableViewCell *)tableView:(UITableView *)tableView 
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  static NSString *CellIdentifier = @"CellIdentifier";
	
	// Dequeue or create a cell of the appropriate type.
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle 
                                   reuseIdentifier:CellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryNone;
	}
    
  cell.textLabel.text = [data item:indexPath.row];
  cell.detailTextLabel.text = [dictProfiles valueForKey:cell.textLabel.text];
    
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

}

//-(IBAction)cancel:(id)sender {
//    [self.sender dismissPopOver];
//}

@end
