//
//  ProfilesDetailsViewController.h
//  QINS3
//
//  Created by vinh luu on 11/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kLabels 0
#define kImages 1
#define kValues 2

@class ProfileListProductsPopOver;
@class SUPObjectList;

@interface ProfilesDetailsViewController : UIViewController {
  NSMutableArray *arrProfiles;
  NSMutableDictionary *dictProfiles;
    
  IBOutlet UIImageView *imgYoungSingle;
  IBOutlet UIImageView *imgYoungFamilyChildren;
  IBOutlet UIImageView *imgCoupleNoChildren;
  IBOutlet UIImageView *imgMatureSingle;
  IBOutlet UIImageView *imgFamilyChildren;
  IBOutlet UIImageView *imgReadyToGo;
  
  IBOutlet UILabel *lbYoungSingle;
  IBOutlet UILabel *lbYoungFamilyChildren;
  IBOutlet UILabel *lbCoupleNoChildren;
  IBOutlet UILabel *lbMatureSingle;
  IBOutlet UILabel *lbFamilyChildren;
  IBOutlet UILabel *lbReadyToGo;
  
  NSMutableDictionary *dictButtonsLabels;
  NSMutableDictionary *dictButtonsValues;
  NSMutableDictionary *dictButtons;
  
  NSMutableDictionary *arrArea1Product;
  NSMutableDictionary *arrArea2Product;
  NSMutableDictionary *arrArea3Product;
  NSMutableDictionary *arrArea4Product;
  
  IBOutlet UILabel *lbArea1Name;
  IBOutlet UILabel *lbArea2Name;
  IBOutlet UILabel *lbArea3Name;
  IBOutlet UILabel *lbArea4Name;
  
  IBOutlet UIButton *btnArea1Product1;
  IBOutlet UIButton *btnArea1Product2;
  IBOutlet UIButton *btnArea1Product3;
  IBOutlet UIButton *btnArea1Product4;
  IBOutlet UIButton *btnArea1Product5;
  IBOutlet UIButton *btnArea1Product6;
  
  IBOutlet UIButton *btnArea2Product1;
  IBOutlet UIButton *btnArea2Product2;
  IBOutlet UIButton *btnArea2Product3;
  IBOutlet UIButton *btnArea2Product4;
  IBOutlet UIButton *btnArea2Product5;
  IBOutlet UIButton *btnArea2Product6;
  
  IBOutlet UIButton *btnArea3Product1;
  IBOutlet UIButton *btnArea3Product2;
  IBOutlet UIButton *btnArea3Product3;
  IBOutlet UIButton *btnArea3Product4;
  IBOutlet UIButton *btnArea3Product5;
  IBOutlet UIButton *btnArea3Product6;
  
  IBOutlet UIButton *btnArea4Product1;
  IBOutlet UIButton *btnArea4Product2;
  IBOutlet UIButton *btnArea4Product3;
  IBOutlet UIButton *btnArea4Product4;
  IBOutlet UIButton *btnArea4Product5;
  IBOutlet UIButton *btnArea4Product6;
  
  IBOutlet UIButton *btnAreaInfo1;
  IBOutlet UIButton *btnAreaInfo2;
  IBOutlet UIButton *btnAreaInfo3;
  IBOutlet UIButton *btnAreaInfo4;  
  
  UIPopoverController *popController;
  ProfileListProductsPopOver *popOver;
  SUPObjectList *listProfileCustomers;
}

@property (nonatomic, retain) SUPObjectList *listProfileCustomers;

@property (nonatomic, retain) IBOutlet UIImageView *imgYoungSingle;
@property (nonatomic, retain) IBOutlet UIImageView *imgYoungFamilyChildren;
@property (nonatomic, retain) IBOutlet UIImageView *imgCoupleNoChildren;
@property (nonatomic, retain) IBOutlet UIImageView *imgMatureSingle;
@property (nonatomic, retain) IBOutlet UIImageView *imgFamilyChildren;
@property (nonatomic, retain) IBOutlet UIImageView *imgReadyToGo;

@property (nonatomic, retain) IBOutlet UILabel *lbYoungSingle;
@property (nonatomic, retain) IBOutlet UILabel *lbYoungFamilyChildren;
@property (nonatomic, retain) IBOutlet UILabel *lbCoupleNoChildren;
@property (nonatomic, retain) IBOutlet UILabel *lbMatureSingle;
@property (nonatomic, retain) IBOutlet UILabel *lbFamilyChildren;
@property (nonatomic, retain) IBOutlet UILabel *lbReadyToGo;

@property (nonatomic, retain) IBOutlet UILabel *lbArea1Name;
@property (nonatomic, retain) IBOutlet UILabel *lbArea2Name;
@property (nonatomic, retain) IBOutlet UILabel *lbArea3Name;
@property (nonatomic, retain) IBOutlet UILabel *lbArea4Name;

@property (nonatomic, retain) IBOutlet UIButton *btnArea1Product1;
@property (nonatomic, retain) IBOutlet UIButton *btnArea1Product2;
@property (nonatomic, retain) IBOutlet UIButton *btnArea1Product3;
@property (nonatomic, retain) IBOutlet UIButton *btnArea1Product4;
@property (nonatomic, retain) IBOutlet UIButton *btnArea1Product5;
@property (nonatomic, retain) IBOutlet UIButton *btnArea1Product6;

@property (nonatomic, retain) IBOutlet UIButton *btnArea2Product1;
@property (nonatomic, retain) IBOutlet UIButton *btnArea2Product2;
@property (nonatomic, retain) IBOutlet UIButton *btnArea2Product3;
@property (nonatomic, retain) IBOutlet UIButton *btnArea2Product4;
@property (nonatomic, retain) IBOutlet UIButton *btnArea2Product5;
@property (nonatomic, retain) IBOutlet UIButton *btnArea2Product6;

@property (nonatomic, retain) IBOutlet UIButton *btnArea3Product1;
@property (nonatomic, retain) IBOutlet UIButton *btnArea3Product2;
@property (nonatomic, retain) IBOutlet UIButton *btnArea3Product3;
@property (nonatomic, retain) IBOutlet UIButton *btnArea3Product4;
@property (nonatomic, retain) IBOutlet UIButton *btnArea3Product5;
@property (nonatomic, retain) IBOutlet UIButton *btnArea3Product6;

@property (nonatomic, retain) IBOutlet UIButton *btnArea4Product1;
@property (nonatomic, retain) IBOutlet UIButton *btnArea4Product2;
@property (nonatomic, retain) IBOutlet UIButton *btnArea4Product3;
@property (nonatomic, retain) IBOutlet UIButton *btnArea4Product4;
@property (nonatomic, retain) IBOutlet UIButton *btnArea4Product5;
@property (nonatomic, retain) IBOutlet UIButton *btnArea4Product6;


@property (nonatomic, retain) IBOutlet UIButton *btnAreaInfo1;
@property (nonatomic, retain) IBOutlet UIButton *btnAreaInfo2;
@property (nonatomic, retain) IBOutlet UIButton *btnAreaInfo3;
@property (nonatomic, retain) IBOutlet UIButton *btnAreaInfo4;

@property (nonatomic, retain) UIPopoverController *popController;
@property (nonatomic, retain) ProfileListProductsPopOver *popOver;

- (NSMutableArray *)initLabels;
- (NSMutableArray *)initImages;
- (NSMutableArray *)initValues;
- (SUPObjectList*)setText;

- (void)disableAllProfile;
- (void)enableProfile:(int)profile;
- (void)filterListProfiles:(SUPObjectList*)listProfiles age:(int)age materialStatus:(NSString *)status;
- (void)setNameforAreaFromArray:(NSArray*)arrAreaName;

- (void)addProductsToAreas;
- (NSMutableDictionary *)initKeysForDictionary:(NSMutableDictionary *)dict 
                                fromArrayNames:(NSArray *)arrAreaName;
- (NSMutableArray *)getAllButtons;
- (NSMutableArray *)unhideButtons:(NSMutableArray *)arrayButtons 
               andSetButtonsLabel:(NSMutableArray *)arrayLabels;
- (NSMutableArray *)initProductValues:(NSArray *)arrAreaProductName;
- (NSMutableArray *)initObjects:(NSArray *)arrAreaProductName;

- (void)filterProfileProductWithEstate:(NSString *)estate 
                           andVehicles:(NSString *)vehicles 
                         andEmployment:(NSString *)emloyment;
- (void)disableAllProduct;
- (void)enableProduct:(NSMutableArray *)arrToEnable 
       inDictProfiles:(NSMutableDictionary *)dict 
          withArrName:(NSArray *)arrAreaName;
- (IBAction)areaInfo:(id)sender;
- (void)presentPopOver:(SUPObjectList *)lstContent frame:(CGRect)frame;
- (void)dismissPopover;

@end
