//
//  ProfileListProductsPopOver.h
//  QINS3
//
//  Created by vinh luu on 11/17/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SUPObjectList.h"

@interface ProfileListProductsPopOver : UIViewController <UITableViewDataSource, UITableViewDelegate>{
  SUPObjectList *data;
  NSMutableDictionary *dictProfiles;
  IBOutlet UITableView *table;
  IBOutlet UIBarButtonItem *button;
  id sender;
}

@property (nonatomic, retain) id sender;
@property (nonatomic, retain) SUPObjectList *data;
@property (nonatomic, retain) NSMutableDictionary *dictProfiles;
@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *button;

-(void)loadData;

@end
