//
//  ProfilesDetailsViewController.m
//  QINS3
//
//  Created by vinh luu on 11/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ProfilesDetailsViewController.h"
#import "qPeriorMobInsuranceDemo_CustAnalyseCustomerProfile.h"
#import "qPeriorMobInsuranceDemo_CustAnalyseProductProfile.h"
#import "Utils.h"
#import "ProfileUtils.h"
#import "ProfileListProductsPopOver.h"
#import "MGSplitViewController.h"
#import "AnalysisController.h"
#import "AnalysisHome.h"
#import "HomeScreenViewController.h"

@implementation ProfilesDetailsViewController

@synthesize imgYoungSingle;
@synthesize imgYoungFamilyChildren;
@synthesize imgCoupleNoChildren;
@synthesize imgMatureSingle;
@synthesize imgFamilyChildren;
@synthesize imgReadyToGo;

@synthesize lbYoungSingle;
@synthesize lbYoungFamilyChildren;
@synthesize lbCoupleNoChildren;
@synthesize lbMatureSingle;
@synthesize lbFamilyChildren;
@synthesize lbReadyToGo;

@synthesize lbArea1Name;
@synthesize lbArea2Name;
@synthesize lbArea3Name;
@synthesize lbArea4Name;

@synthesize btnArea1Product1;
@synthesize btnArea1Product2;
@synthesize btnArea1Product3;
@synthesize btnArea1Product4;
@synthesize btnArea1Product5;
@synthesize btnArea1Product6;

@synthesize btnArea2Product1;
@synthesize btnArea2Product2;
@synthesize btnArea2Product3;
@synthesize btnArea2Product4;
@synthesize btnArea2Product5;
@synthesize btnArea2Product6;

@synthesize btnArea3Product1;
@synthesize btnArea3Product2;
@synthesize btnArea3Product3;
@synthesize btnArea3Product4;
@synthesize btnArea3Product5;
@synthesize btnArea3Product6;

@synthesize btnArea4Product1;
@synthesize btnArea4Product2;
@synthesize btnArea4Product3;
@synthesize btnArea4Product4;
@synthesize btnArea4Product5;
@synthesize btnArea4Product6;


@synthesize btnAreaInfo1;
@synthesize btnAreaInfo2;
@synthesize btnAreaInfo3;
@synthesize btnAreaInfo4;

@synthesize popController;
@synthesize popOver;
@synthesize listProfileCustomers;

#pragma mark - View lifecycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
  // Custom initialization
  }
  return self;
}

- (void)didReceiveMemoryWarning {
  // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];  
  // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidLoad {
  self.title = @"Customer Analyses";
  [super viewDidLoad];
  arrProfiles = [[NSMutableArray alloc]init];
  [arrProfiles addObject:[self initLabels]];
  [arrProfiles addObject:[self initImages]];
  [arrProfiles addObject:[self initValues]];
  [self addProductsToAreas];
  listProfileCustomers = [self setText];
  popOver = [[ProfileListProductsPopOver alloc] initWithNibName:@"ProfileListProductsPopOver" bundle:nil];
  popController = [[UIPopoverController alloc] initWithContentViewController:popOver];
}

- (void)viewDidUnload {
  [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:
  (UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations
	return YES;
}

#pragma mark - Profiles
-( NSMutableArray *)initLabels {
  NSMutableArray *arrLabels = [[NSMutableArray alloc]init];
  [arrLabels addObject:lbYoungSingle];
  [arrLabels addObject:lbYoungFamilyChildren];
  [arrLabels addObject:lbCoupleNoChildren];
  [arrLabels addObject:lbMatureSingle];
  [arrLabels addObject:lbFamilyChildren];
  [arrLabels addObject:lbReadyToGo];
  return arrLabels;
}

- (NSMutableArray *)initImages {
  NSMutableArray *arrImages = [[NSMutableArray alloc]init];
  [arrImages addObject:imgYoungSingle];
  [arrImages addObject:imgYoungFamilyChildren];
  [arrImages addObject:imgCoupleNoChildren];
  [arrImages addObject:imgMatureSingle];
  [arrImages addObject:imgFamilyChildren];
  [arrImages addObject:imgReadyToGo];
  return arrImages;
}

- (NSMutableArray *)initValues {  
  NSMutableArray *arrValues = [[NSMutableArray alloc] init];
  while ([arrValues count] != 6) {
    [arrValues addObject:kDisabled];
  }
  return arrValues;
}

- (SUPObjectList *)setText {
  SUPObjectList *listCustomerProfiles = [[qPeriorMobInsuranceDemo_CustAnalyseCustomerProfile findAll]retain];
  SUPObjectList *returnList = [[SUPObjectList alloc]init];
  NSMutableArray *arrLabelText = [[NSMutableArray alloc]init];
  for (int i = 0; i < [listCustomerProfiles size]; i++) {
    qPeriorMobInsuranceDemo_CustAnalyseCustomerProfile *profile = [listCustomerProfiles item:i];
    [profile retain];
    NSString *description = [NSString stringWithFormat:@"%@", profile.custProfileDescr];
    if (![arrLabelText containsObject:description]) {
      [arrLabelText addObject:description];
      [returnList addObject:profile];
    }
  }
  for (int i = 0; i < 6; i++) {//[listCustomerProfiles size]
    UILabel *label = [[arrProfiles objectAtIndex:kLabels] objectAtIndex:i];
    if (![[arrLabelText objectAtIndex:i] isEqualToString:@" "]) {
      label.text = [arrLabelText objectAtIndex:i];
    } else {
      label.text = @"Ready-To-Go";
    }        
  }
  [listCustomerProfiles release];
  return returnList;
}

- (void)filterListProfiles:(SUPObjectList*)listProfiles age:(int)age materialStatus:(NSString *)status {
  [self disableAllProfile];
  for (int i = 0; i < 6; i++) {
    qPeriorMobInsuranceDemo_CustAnalyseCustomerProfile *customerProfile = [listProfiles item:i];
    if (age >= [customerProfile.ageFrom intValue] 
        && age <= [customerProfile.ageTo intValue] 
        && [status isEqualToString:customerProfile.maritalStatus]) {            
      [self enableProfile:i];
    } else if (age >= 65) {
      [self enableProfile:5];
    }
  }
}

- (void)disableAllProfile {
  for (int i = 0; i < 6; i++) {
    UILabel *label = [[arrProfiles objectAtIndex:kLabels] objectAtIndex:i];
    [label setTextColor:[UIColor blackColor]];
    UIImageView *imageView = [[arrProfiles objectAtIndex:kImages] objectAtIndex:i];
    [imageView setImage:[UIImage imageNamed:kDisabledImage]];
    [[arrProfiles objectAtIndex:kValues] replaceObjectAtIndex:i withObject:kDisabled];
  }
}

- (void)enableProfile:(int)profile {
  UILabel *label = [[arrProfiles objectAtIndex:kLabels] objectAtIndex:profile];
  [label setTextColor:[UIColor lightGrayColor]];
  UIImageView *imageView = [[arrProfiles objectAtIndex:kImages] objectAtIndex:profile];
  [imageView setImage:[UIImage imageNamed:kEnaledImage]];
  [[arrProfiles objectAtIndex:kValues] replaceObjectAtIndex:profile withObject:kEnabled];
}

#pragma mark - Products

- (void)addProductsToAreas {
  NSMutableDictionary *dictProfileProduct = [ProfileUtils getProfileProducts];
  dictProfiles = [[NSMutableDictionary alloc]init];
  NSArray *arrAreaName = [dictProfileProduct allKeys];
  arrAreaName = [arrAreaName sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
  [self setNameforAreaFromArray:arrAreaName];
  NSMutableArray *arrProductName = [[NSMutableArray alloc]init];
  for (int i = 0; i < 4; i++) {
    [arrProductName addObject:[dictProfileProduct objectForKey:[arrAreaName objectAtIndex:i]]];
  }
  NSMutableArray *arrObject = [self initObjects:arrProductName];
  for (int i = 0; i < 4; i++) {
    [dictProfiles setObject:[arrObject objectAtIndex:i]  forKey:[arrAreaName objectAtIndex:i]];
  }
}

- (NSMutableDictionary *)initKeysForDictionary:(NSMutableDictionary*)dict fromArrayNames:(NSArray*)arrAreaName {
  NSMutableDictionary *returnDict = dict;
  for (int i = 0; i < [arrAreaName count]; i++) {
    [returnDict setObject:nil forKey:[arrAreaName objectAtIndex:i]];
  }
  return returnDict;
}

- (NSMutableArray *)initObjects:(NSMutableArray *)arrAreaProductName {
  NSMutableArray *arrObjects = [[NSMutableArray alloc]init];
  NSMutableArray *arrAllButtons = [self getAllButtons];
  NSMutableArray *arrAreaButtons = [self unhideButtons:arrAllButtons andSetButtonsLabel:arrAreaProductName];
  NSMutableArray *arrProductsValues = [self initProductValues:arrAreaProductName];   
  for (int i = 0; i < 4; i ++) {
    NSMutableArray *arrObjectTemp = [[NSMutableArray alloc]init];
    [arrObjectTemp addObject:[arrAreaButtons objectAtIndex:i]];
    [arrObjectTemp addObject:[arrProductsValues objectAtIndex:i]];
    [arrObjects addObject:arrObjectTemp];
  }
  return arrObjects;
}

- (NSMutableArray *)getAllButtons {
  NSMutableArray *arrAllButtons = [[NSMutableArray alloc]init];
    
  NSMutableArray *arrButtons1 = [[NSMutableArray alloc]init];
  [arrButtons1 addObject:btnArea1Product1];
  [arrButtons1 addObject:btnArea1Product2];
  [arrButtons1 addObject:btnArea1Product3];
  [arrButtons1 addObject:btnArea1Product4];
  [arrButtons1 addObject:btnArea1Product5];
  [arrButtons1 addObject:btnArea1Product6];
    
  NSMutableArray *arrButtons2 = [[NSMutableArray alloc]init];
  [arrButtons2 addObject:btnArea2Product1];
  [arrButtons2 addObject:btnArea2Product2];
  [arrButtons2 addObject:btnArea2Product3];
  [arrButtons2 addObject:btnArea2Product4];
  [arrButtons2 addObject:btnArea2Product5];
  [arrButtons2 addObject:btnArea2Product6];
    
  NSMutableArray *arrButtons3 = [[NSMutableArray alloc]init];
  [arrButtons3 addObject:btnArea3Product1];
  [arrButtons3 addObject:btnArea3Product2];
  [arrButtons3 addObject:btnArea3Product3];
  [arrButtons3 addObject:btnArea3Product4];
  [arrButtons3 addObject:btnArea3Product5];
  [arrButtons3 addObject:btnArea3Product6];
    
  NSMutableArray *arrButtons4 = [[NSMutableArray alloc]init];
  [arrButtons4 addObject:btnArea4Product1];
  [arrButtons4 addObject:btnArea4Product2];
  [arrButtons4 addObject:btnArea4Product3];
  [arrButtons4 addObject:btnArea4Product4];
  [arrButtons4 addObject:btnArea4Product5];
  [arrButtons4 addObject:btnArea4Product6];
    
  [arrAllButtons addObject:arrButtons1];
  [arrAllButtons addObject:arrButtons2];
  [arrAllButtons addObject:arrButtons3];
  [arrAllButtons addObject:arrButtons4];
    
  return arrAllButtons;
}

- (NSMutableArray *)unhideButtons:(NSMutableArray *)arrayButtons 
               andSetButtonsLabel:(NSMutableArray *)arrayLabels {
  NSMutableArray *arrButtons = [[NSMutableArray alloc]init];
  for (int i = 0; i < [arrayLabels count]; i++) {
    NSMutableArray *arrButtonsTemp = [[NSMutableArray alloc]init];
    NSMutableArray *arrTemp = [arrayLabels objectAtIndex:i];
    for (int j = 0; j < [arrTemp count]; j++) {
      UIButton *button = [[arrayButtons objectAtIndex:i]objectAtIndex:j];
      [button setTitle:[[arrayLabels objectAtIndex:i]objectAtIndex:j] forState:UIControlStateNormal];
      [button setTitle:[[arrayLabels objectAtIndex:i]objectAtIndex:j] forState:UIControlStateDisabled];
      [button setAlpha:1.0];
      [arrButtonsTemp addObject:button];
      
      if ([button.currentTitle isEqualToString:@"KVK"]) {
        [button addTarget:self action:@selector(showAnalysis:) forControlEvents:UIControlEventTouchUpInside];
      }
      
    }
    [arrButtons addObject:arrButtonsTemp];
  }
  return arrButtons;
}

- (void) showAnalysis:(id) sender {
  HomeScreenViewController *homeViewController = APP_IPAD.homeScreenViewController;
  [homeViewController.navigationController pushViewController:APP_IPAD.analysisSplit animated:YES];  
}

- (NSMutableArray *)initProductValues:(NSMutableArray *)arrAreaProductName {
  NSMutableArray *arrValues = [[NSMutableArray alloc]init];
  for (int i = 0; i < [arrAreaProductName count]; i++) {
    NSMutableArray *arrTemp = [[NSMutableArray alloc]init];
    for (int j = 0; j < [[arrAreaProductName objectAtIndex:i] count]; j++) {
      [arrTemp addObject:kDisabled];
    }
    [arrValues addObject:arrTemp];
  }
  return arrValues;
}

- (void)setNameforAreaFromArray:(NSArray *)arrAreaName {
    lbArea1Name.text = [arrAreaName objectAtIndex:0];
    lbArea2Name.text = [arrAreaName objectAtIndex:1];
    lbArea3Name.text = [arrAreaName objectAtIndex:2];
    lbArea4Name.text = [arrAreaName objectAtIndex:3];
}

- (void)filterProfileProductWithEstate:(NSString*)estate 
                           andVehicles:(NSString*)vehicles 
                         andEmployment:(NSString*)emloyment {
  [self disableAllProduct];    
  NSMutableDictionary *dictProfileProduct = [ProfileUtils getProfileProducts];
  NSArray *arrAreaName = [dictProfileProduct allKeys];
  arrAreaName = [arrAreaName sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
  SUPObjectList *listProducts = [[qPeriorMobInsuranceDemo_CustAnalyseProductProfile findAll]retain];
  NSMutableArray *arrToEnable = [[NSMutableArray alloc]init];
  for (int i = 0; i < [arrAreaName count]; i++) {
    NSMutableArray *arrTemp = [[NSMutableArray alloc]init];
    for (int j = 0; j < [listProducts size]; j++) {
      qPeriorMobInsuranceDemo_CustAnalyseProductProfile *profile = [listProducts item:j];
      if ([profile.realEstateFlag isEqualToString:estate] 
          && [profile.vehicleFlag isEqualToString:vehicles] 
          && [profile.custEmployment isEqualToString:emloyment]
          && [profile.prodCategoryDescr isEqualToString:[arrAreaName objectAtIndex:i]]) {
        [arrTemp addObject:profile.prodId];
      }            
    }
    [arrToEnable addObject:arrTemp];
  }
  [self enableProduct:arrToEnable inDictProfiles:dictProfiles withArrName:arrAreaName];
}

- (void)enableProduct:(NSMutableArray *)arrToEnable 
       inDictProfiles:(NSMutableDictionary *)dict 
          withArrName:(NSArray *)arrAreaName {
  NSMutableDictionary *dictProfile = [ProfileUtils getProfileProducts];
  for (int i = 0; i < 4; i++) {
    NSMutableArray *arrName = [dictProfile objectForKey:[arrAreaName objectAtIndex:i]];
    NSMutableArray *arrButtons = [[dict objectForKey:[arrAreaName objectAtIndex:i]] objectAtIndex:0];
    NSMutableArray *arrValues = [[dict objectForKey:[arrAreaName objectAtIndex:i]] objectAtIndex:1];
    for (int j = 0; j < [[arrToEnable objectAtIndex:i]count]; j++) {
      if ([arrName containsObject:[[arrToEnable objectAtIndex:i]objectAtIndex:j]]) {
        int index = [arrName indexOfObject:[[arrToEnable objectAtIndex:i]objectAtIndex:j]];
        UIButton *button = [arrButtons objectAtIndex:index];
        button.enabled = YES;
        [arrValues replaceObjectAtIndex:index withObject:kEnabled];
      }
    }
  }
}

- (void)disableAllProduct {
  for (int i = 0; i < 4; i++) {
    NSMutableArray *arrButtons = [[[dictProfiles allValues]objectAtIndex:i] objectAtIndex:0];
    NSMutableArray *arrValues = [[[dictProfiles allValues]objectAtIndex:i] objectAtIndex:1];
    for (int j = 0; j < [arrButtons count]; j++) {
      UIButton *button = [arrButtons objectAtIndex:j];
      button.enabled = NO;
      [arrValues replaceObjectAtIndex:j withObject:kDisabled];
    }
  }
}

#pragma Info Action
- (IBAction)areaInfo:(id)sender {
  NSDictionary *profileProducts = [ProfileUtils getProfileProducts];
  CGRect frame;            
  NSMutableArray * productIds;
  SUPObjectList *lstContent = [[SUPObjectList alloc]init];    
  if (sender == btnAreaInfo1) {
    frame = CGRectMake(btnAreaInfo1.frame.origin.x, btnAreaInfo1.frame.origin.y,
                       btnAreaInfo1.frame.size.width, btnAreaInfo1.frame.size.height);            
    productIds = [profileProducts objectForKey:@"Asset"];
  } else if (sender == btnAreaInfo2) {
    frame = CGRectMake(btnAreaInfo2.frame.origin.x, btnAreaInfo2.frame.origin.y,
                       btnAreaInfo2.frame.size.width, btnAreaInfo2.frame.size.height);            
    productIds = [profileProducts objectForKey:@"Future"];        
  } else if (sender == btnAreaInfo3) {
    frame = CGRectMake(btnAreaInfo3.frame.origin.x, btnAreaInfo3.frame.origin.y,
                       btnAreaInfo3.frame.size.width, btnAreaInfo3.frame.size.height);            
    productIds = [profileProducts objectForKey:@"Property"];        
  } else if (sender == btnAreaInfo4) {
    frame = CGRectMake(btnAreaInfo4.frame.origin.x, btnAreaInfo4.frame.origin.y,
                       btnAreaInfo4.frame.size.width, btnAreaInfo4.frame.size.height);            
    productIds = [profileProducts objectForKey:@"Risk"];        
  }
  for (int i = 0; i < [productIds count]; i++) {
    [lstContent add:[NSString stringWithFormat:@"%@", [productIds objectAtIndex:i]]];
  }
  [self presentPopOver:lstContent frame:frame]; 
}

// present popOver
- (void)presentPopOver:(SUPObjectList *)lstContent frame:(CGRect)frame  {
  popOver.data = lstContent;
  popOver.sender = self;
  int size = [popOver.data size];
  int height = 350;
  if (size <= 10) {
    height = size*45;
  }
  [popOver loadData];
  popController.popoverContentSize = CGSizeMake(300,height);
  [self.popController presentPopoverFromRect:frame 
                                      inView:self.view 
                    permittedArrowDirections:UIPopoverArrowDirectionRight 
                                    animated:YES]; 
}

- (void)dismissPopover {
    [self.popController dismissPopoverAnimated:YES];
}

@end
