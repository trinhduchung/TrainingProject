//
//  ProfilesViewController.h
//  QINS3
//
//  Created by vinh luu on 11/7/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kCBImages 0
#define kCBValues 1

@class ProfilesDetailsViewController;

@interface ProfilesViewController :  UIViewController {
  UISlider *slider;
  UILabel *valueSlider;
  NSMutableArray *arrCheckboxs;
  
  // Marital Status
  IBOutlet UIImageView *imgSingle;
  IBOutlet UIImageView *imgMarried;
  IBOutlet UIImageView *imgChildren;
  
  IBOutlet UIImageView *cbSingle;
  IBOutlet UIImageView *cbMarried;
  IBOutlet UIImageView *cbChildren;
  
  // Properties
  IBOutlet UIImageView *imgEstates;
  IBOutlet UIImageView *imgVehicles;
  
  IBOutlet UIImageView *cbEstates;
  IBOutlet UIImageView *cbVehicles;
  
  // Employment
  IBOutlet UIImageView *imgEmployed;
  IBOutlet UIImageView *imgSelfEmployed;
  IBOutlet UIImageView *imgUnemployed;
  
  IBOutlet UIImageView *cbEmloyed;
  IBOutlet UIImageView *cbSelfEmployed;
  IBOutlet UIImageView *cbUnemployed;
  
  ProfilesDetailsViewController *profileDetails;
}

@property (nonatomic, retain) UISlider *slider;
@property (nonatomic, retain) UILabel *valueSlider;

@property (nonatomic, retain) IBOutlet UIImageView *imgSingle;
@property (nonatomic, retain) IBOutlet UIImageView *imgMarried;
@property (nonatomic, retain) IBOutlet UIImageView *imgChildren;

@property (nonatomic, retain) IBOutlet UIImageView *cbSingle;
@property (nonatomic, retain) IBOutlet UIImageView *cbMarried;
@property (nonatomic, retain) IBOutlet UIImageView *cbChildren;

@property (nonatomic, retain) IBOutlet UIImageView *imgEstates;
@property (nonatomic, retain) IBOutlet UIImageView *imgVehicles;

@property (nonatomic, retain) IBOutlet UIImageView *cbEstates;
@property (nonatomic, retain) IBOutlet UIImageView *cbVehicles;

@property (nonatomic, retain) IBOutlet UIImageView *imgEmployed;
@property (nonatomic, retain) IBOutlet UIImageView *imgSelfEmployed;
@property (nonatomic, retain) IBOutlet UIImageView *imgUnemployed;

@property (nonatomic, retain) IBOutlet UIImageView *cbEmloyed;
@property (nonatomic, retain) IBOutlet UIImageView *cbSelfEmployed;
@property (nonatomic, retain) IBOutlet UIImageView *cbUnemployed;

- (void)initSlider;
- (float)getXforValueLabel:(UISlider *)aSlider;
- (float)getYforValueLabel:(UISlider *)aSlider;
- (void)initSliderButtons;
- (void)sliderValueChanged:(id)sender;

- (void)initButtons;
- (NSMutableArray *)initImages;
- (NSMutableArray *)initValues;

- (IBAction)checkboxValueChanged:(id)sender;
- (void)setCheckboxImage:(int)checkbox withImage:(NSString *)image;
- (NSString *)getMaterialStatus;
- (void)filterProduct;

@end
