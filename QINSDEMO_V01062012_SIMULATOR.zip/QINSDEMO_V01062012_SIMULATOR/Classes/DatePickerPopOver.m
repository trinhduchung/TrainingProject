  //
  //  DatePickerPopOver.m
  //  QINS3
  //
  //  Created by mac osd on 9/27/11.
  //  Copyright 2011 __MyCompanyName__. All rights reserved.
  //

#import "DatePickerPopOver.h"
#import "PoliciesEditViewController.h"

@implementation DatePickerPopOver
@synthesize datePicker;
@synthesize doneButton;
@synthesize sender;
@synthesize returnData;
@synthesize toolbar;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
      // Custom initialization
  }
  return self;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
  
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
  [super viewDidLoad];
  toolbar.frame = CGRectMake(0, 5, 320, 50);    
}

- (void)viewDidUnload {
  [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
  return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#define kDatePickerTag 100
- (IBAction)dateSelected:(id)sender {
    //set Date formatter
  NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
  [formatter setDateFormat:@"dd.MM.yyyy"];
  
    //Gets our picker
  
  
  NSDate *selectedDate = [datePicker date];
  
  NSString *msg = [[NSString alloc] initWithFormat:@"%@", 
                      [formatter stringFromDate:selectedDate]];
  self.returnData = msg;
  
  [self.sender getDataFromPopOver:self];
  [self.sender dismissPopover];
  
}

- (IBAction)dateCancel:(id)sender {
  [self.sender dismissPopover];
}

@end
